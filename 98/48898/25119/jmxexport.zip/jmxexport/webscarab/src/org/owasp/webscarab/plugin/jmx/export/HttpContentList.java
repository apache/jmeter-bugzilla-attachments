/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.owasp.webscarab.plugin.jmx.export;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.owasp.webscarab.model.NamedValue;
import org.owasp.webscarab.util.Encoding;

public class HttpContentList {
    private String _data = null;
    
    private List _values = new ArrayList();
    
    public String[] getContentTypes() {
        return new String[] { "application/x-www-form-urlencoded" };
    }
    
    public HttpContentList(String contentType, byte[] bytes) {
        _values.clear();
        if (bytes == null) {
            _data = null;
        } else {
            try {
                _data = new String(bytes, "UTF-8");
            } catch (UnsupportedEncodingException e) {}
            NamedValue[] values = NamedValue.splitNamedValues(_data, "&", "=");
            String name, value;
            for (int i=0; i<values.length; i++) {
                name = Encoding.urlDecode(values[i].getName());
                value = Encoding.urlDecode(values[i].getValue());
                values[i] = new NamedValue(name, value);
                _values.add(values[i]);
            }
        }
    }
    
    public int getNumParams() {
    	return _values.size();
    }
    
    public Object getPrameter(int par) {
    	return _values.get(par);
    }

}
