/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.owasp.webscarab.plugin.jmx.export;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.OutputStream;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.logging.Level;

import java.nio.charset.Charset;

import org.owasp.webscarab.plugin.jmx.elements.TestElement;
import org.owasp.webscarab.plugin.jmx.elements.property.AbstractProperty;
import org.apache.jorphan.collections.HashTree;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.mapper.CannotResolveClassException;
import com.thoughtworks.xstream.mapper.Mapper;
import com.thoughtworks.xstream.mapper.MapperWrapper;
import com.thoughtworks.xstream.converters.ConversionException;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.DataHolder;
import com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider;
import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;

/**
 * Handles setting up XStream serialisation.
 * The class reads alias definitions from saveservice.properties.
 *
 */
public class SaveService {

	protected final static Logger LOGGER = Logger.getLogger(AbstractProperty.class .getName());

    // Names of DataHolder entries
    public static final String SAMPLE_EVENT_OBJECT = "SampleEvent"; // $NON-NLS-1$
    public static final String RESULTCOLLECTOR_HELPER_OBJECT = "ResultCollectorHelper"; // $NON-NLS-1$

    private static final class XStreamWrapper extends XStream {
        private XStreamWrapper(ReflectionProvider reflectionProvider) {
            super(reflectionProvider, new DomDriver());
        }

        // Override wrapMapper in order to insert the Wrapper in the chain
        protected MapperWrapper wrapMapper(MapperWrapper next) {
            // Provide our own aliasing using strings rather than classes
            return new MapperWrapper(next){
            // Translate alias to classname and then delegate to wrapped class
            public Class realClass(String alias) {
                String fullName = aliasToClass(alias);
                return super.realClass(fullName == null ? alias : fullName);
            }
            // Translate to alias and then delegate to wrapped class
            public String serializedClass(Class type) {
                if (type == null) {
                    return super.serializedClass(null); // was type, but that caused FindBugs warning
                }
                String alias = classToAlias(type.getName());
                return alias == null ? super.serializedClass(type) : alias ;
                }
            };
        }
    }

    private static final XStream JMXSAVER = new XStreamWrapper(new PureJavaReflectionProvider());
    
    // The XML header, with placeholder for encoding, since that is controlled by property
    private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"<ph>\"?>"; // $NON-NLS-1$

    // Property name used to define file name
    private static final String SAVESERVICE_PROPERTIES = "saveservice.properties"; // $NON-NLS-1$

    // Define file format property names
    private static final String FILE_FORMAT = "file_format"; // $NON-NLS-1$
    private static final String FILE_FORMAT_TESTPLAN = "file_format.testplan"; // $NON-NLS-1$

    // Define file format versions
    private static final String VERSION_2_1 = "2.1";  // $NON-NLS-1$

    // Default to overall format, and then to version 2.2
    public static final String TESTPLAN_FORMAT = VERSION_2_1;

    private static final boolean IS_TESTPLAN_FORMAT_21 = VERSION_2_1.equals(TESTPLAN_FORMAT);

    // Holds the mappings from the saveservice properties file
    private static final Properties aliasToClass = new Properties();

    // Holds the reverse mappings
    private static final Properties classToAlias = new Properties();

    // Version information for test plan header
    // This is written to JMX files by ScriptWrapperConverter
    // Also to JTL files by ResultCollector
    private static final String VERSION = "1.2"; // $NON-NLS-1$

    // This is written to JMX files by ScriptWrapperConverter
    private static String propertiesVersion = "";// read from properties file; written to JMX files
    private static final String PROPVERSION = "2.1";// Expected version $NON-NLS-1$

    // Internal information only
    private static String fileVersion = ""; // read from properties file// $NON-NLS-1$
    private static final String FILEVERSION = "697317"; // Expected value $NON-NLS-1$
    private static String fileEncoding = ""; // read from properties file// $NON-NLS-1$

    static {
    	LOGGER.log(Level.INFO,"Testplan (JMX) version: "+TESTPLAN_FORMAT);
        initProps();
        checkVersions();
    }

    // Helper method to simplify alias creation from properties
    private static void makeAlias(String alias, String clazz) {
        aliasToClass.setProperty(alias,clazz);
        Object oldval=classToAlias.setProperty(clazz,alias);
        if (oldval != null) {
        	LOGGER.log(Level.SEVERE,"Duplicate alias detected for "+clazz+": "+alias+" & "+oldval);
        }
    }

    public static Properties loadProperties() throws IOException{
        Properties nameMap = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(SAVESERVICE_PROPERTIES);
            nameMap.load(fis);
        } finally {
        	try {
                if (fis != null) {
                	fis.close();
                }
            } catch (IOException ignored) {
            }
        }
        return nameMap;
    }
    
    private static void initProps() {
        // Load the alias properties
        try {
            Properties nameMap = loadProperties();
            // now create the aliases
            Iterator it = nameMap.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry me = (Map.Entry) it.next();
                String key = (String) me.getKey();
                String val = (String) me.getValue();
                if (!key.startsWith("_")) {
                    makeAlias(key, val);
                } else {
                    // process special keys
                    if (key.equalsIgnoreCase("_version")) { // $NON-NLS-1$
                        propertiesVersion = val;
                        LOGGER.log(Level.INFO,"Using SaveService properties version " + propertiesVersion);
                    } else if (key.equalsIgnoreCase("_file_version")) { // $NON-NLS-1$
                            fileVersion = extractVersion(val);
                            LOGGER.log(Level.INFO,"Using SaveService properties file version " + fileVersion);
                    } else if (key.equalsIgnoreCase("_file_encoding")) { // $NON-NLS-1$
                        fileEncoding = val;
                        LOGGER.log(Level.INFO,"Using SaveService properties file encoding " + fileEncoding);
                    } else {
                        key = key.substring(1);// Remove the leading "_"
                        try {
                            final String trimmedValue = val.trim();
                            if (trimmedValue.equals("collection") // $NON-NLS-1$
                             || trimmedValue.equals("mapping")) { // $NON-NLS-1$
                                registerConverter(key, JMXSAVER, true);
                            } else {
                                registerConverter(key, JMXSAVER, false);
                            }
                        } catch (IllegalAccessException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (InstantiationException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (ClassNotFoundException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (IllegalArgumentException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (SecurityException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (InvocationTargetException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        } catch (NoSuchMethodException e1) {
                        	LOGGER.log(Level.WARNING,"Can't register a converter: " + key, e1);
                        }
                    }
                }
            }
        } catch (IOException e) {
        	LOGGER.log(Level.SEVERE,"Bad saveservice properties file", e);
        }
    }

    /**
     * Register converter.
     * @param key
     * @param jmxsaver
     * @param useMapper
     *  
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws InvocationTargetException
     * @throws NoSuchMethodException
     * @throws ClassNotFoundException
     */
    private static void registerConverter(String key, XStream jmxsaver, boolean useMapper)
            throws InstantiationException, IllegalAccessException,
            InvocationTargetException, NoSuchMethodException,
            ClassNotFoundException {
        if (useMapper){
            jmxsaver.registerConverter((Converter) Class.forName(key).getConstructor(
                    new Class[] { Mapper.class }).newInstance(
                            new Object[] { jmxsaver.getMapper() }));
        } else {
            jmxsaver.registerConverter((Converter) Class.forName(key).newInstance());            
        }
    }

    // For converters to use
    public static String aliasToClass(String s){
        String r = aliasToClass.getProperty(s);
        return r == null ? s : r;
    }

    // For converters to use
    public static String classToAlias(String s){
        String r = classToAlias.getProperty(s);
        return r == null ? s : r;
    }

    // Called by Save function
    public static void saveTree(HashTree tree, OutputStream out) throws IOException {
        // Get the OutputWriter to use
        OutputStreamWriter outputStreamWriter = getOutputStreamWriter(out);
        writeXmlHeader(outputStreamWriter);
        // Use deprecated method, to avoid duplicating code
        ScriptWrapper wrapper = new ScriptWrapper();
        wrapper.testPlan = tree;
        JMXSAVER.toXML(wrapper, outputStreamWriter);
        outputStreamWriter.write('\n');// Ensure terminated properly
        outputStreamWriter.close();
    }

    // Used by Test code
    public static void saveElement(Object el, OutputStream out) throws IOException {
        // Get the OutputWriter to use
        OutputStreamWriter outputStreamWriter = getOutputStreamWriter(out);
        writeXmlHeader(outputStreamWriter);
        // Use deprecated method, to avoid duplicating code
        JMXSAVER.toXML(el, outputStreamWriter);
        outputStreamWriter.close();
    }

    // Used by Test code
    public static Object loadElement(InputStream in) throws IOException {
        // Get the InputReader to use
        InputStreamReader inputStreamReader = getInputStreamReader(in);
        // Use deprecated method, to avoid duplicating code
        Object element = JMXSAVER.fromXML(inputStreamReader);
        inputStreamReader.close();
        return element;
    }

    /**
     * @param elem test element
     * @param writer output stream which must be created using {@link #getFileEncoding(String)}
     */
    // Used by ResultCollector#recordStats()
    public synchronized static void saveTestElement(TestElement elem, Writer writer) throws IOException {
        JMXSAVER.toXML(elem, writer); // TODO should this be JTLSAVER? Only seems to be called by MonitorHealthVisualzer
        writer.write('\n');
    }

    private static boolean versionsOK = true;

    // Extract version digits from String of the form #Revision: n.mm #
    // (where # is actually $ above)
    private static final String REVPFX = "$Revision: ";
    private static final String REVSFX = " $"; // $NON-NLS-1$

    private static String extractVersion(String rev) {
        if (rev.length() > REVPFX.length() + REVSFX.length()) {
            return rev.substring(REVPFX.length(), rev.length() - REVSFX.length());
        }
        return rev;
    }

    // Routines for TestSaveService
    static boolean checkPropertyVersion(){
        return SaveService.PROPVERSION.equals(SaveService.propertiesVersion);
    }

    static boolean checkFileVersion(){
        return SaveService.FILEVERSION.equals(SaveService.fileVersion);
    }

    static boolean checkVersions() {
        versionsOK = true;

        if (!PROPVERSION.equalsIgnoreCase(propertiesVersion)) {
        	LOGGER.log(Level.WARNING,"Bad _version - expected " + PROPVERSION + ", found " + propertiesVersion + ".");
        }
        if (!FILEVERSION.equalsIgnoreCase(fileVersion)) {
        	LOGGER.log(Level.WARNING,"Bad _file_version - expected " + FILEVERSION + ", found " + fileVersion +".");
        }
        if (versionsOK) {
        	LOGGER.log(Level.INFO,"All converter versions present and correct");
        }
        return versionsOK;
    }

    /**
     * Load a Test tree (JMX file)
     * @param reader on the JMX file
     * @return the loaded tree
     * @throws Exception if there is a problem reading the file or processing it
     */
    public static HashTree loadTree(InputStream reader) throws Exception {
        if (!reader.markSupported()) {
            reader = new BufferedInputStream(reader);
        }
        reader.mark(Integer.MAX_VALUE);
        ScriptWrapper wrapper = null;
        try {
            // Get the InputReader to use
            InputStreamReader inputStreamReader = getInputStreamReader(reader);
            wrapper = (ScriptWrapper) JMXSAVER.fromXML(inputStreamReader);
            inputStreamReader.close();
            if (wrapper == null){
            	LOGGER.log(Level.SEVERE,"Problem loading new style: see above.");
                return null;
            }
            return wrapper.testPlan;
        } catch (CannotResolveClassException e) {
        	LOGGER.log(Level.SEVERE,"Problem loading new style: " + e.getLocalizedMessage());
            return null;
        } catch (NoClassDefFoundError e) {
        	LOGGER.log(Level.SEVERE,"Missing class "+e);
            return null;
        } catch (ConversionException e) {
        	LOGGER.log(Level.SEVERE,"Conversion error "+e);
            return null;
        }
    }

    private static InputStreamReader getInputStreamReader(InputStream inStream) {
        // Check if we have a encoding to use from properties
        Charset charset = getFileEncodingCharset();
        if(charset != null) {
            return new InputStreamReader(inStream, charset);
        }
        else {
            // We use the default character set encoding of the JRE
            return new InputStreamReader(inStream);
        }
    }

    private static OutputStreamWriter getOutputStreamWriter(OutputStream outStream) {
        // Check if we have a encoding to use from properties
        Charset charset = getFileEncodingCharset();
        if(charset != null) {
            return new OutputStreamWriter(outStream, charset);
        }
        else {
            // We use the default character set encoding of the JRE
            return new OutputStreamWriter(outStream);
        }
    }

    /**
     * Returns the file Encoding specified in saveservice.properties or the default
     * @param dflt value to return if file encoding was not provided
     *
     * @return file encoding or default
     */
    // Used by ResultCollector when creating output files
    public static String getFileEncoding(String dflt){
        if(fileEncoding != null && fileEncoding.length() > 0) {
            return fileEncoding;
        }
        else {
            return dflt;
        }
    }

    private static Charset getFileEncodingCharset() {
        // Check if we have a encoding to use from properties
        if(fileEncoding != null && fileEncoding.length() > 0) {
            return Charset.forName(fileEncoding);
        }
        else {
            // We use the default character set encoding of the JRE
            return null;
        }
    }

    private static void writeXmlHeader(OutputStreamWriter writer) throws IOException {
        // Write XML header if we have the charset to use for encoding
        Charset charset = getFileEncodingCharset();
        if(charset != null) {
            // We do not use getEncoding method of Writer, since that returns
            // the historical name
            String header = XML_HEADER.replaceAll("<ph>", charset.name());
            writer.write(header);
            writer.write('\n');
        }
    }

    // New test format - more compressed class names
    public static boolean isSaveTestPlanFormat22() {
        return IS_TESTPLAN_FORMAT_21;
    }

    /**
     * Simplify getMessage() output from XStream ConversionException
     * @param ce - ConversionException to analyse
     * @return string with details of error
     */
    public static String CEtoString(ConversionException ce){
        String msg =
            "XStream ConversionException at line: " + ce.get("line number")
            + "\n" + ce.get("message")
            + "\nPerhaps a missing jar? See log file.";
        return msg;
    }

    public static String getPropertiesVersion() {
        return propertiesVersion;
    }

    public static String getVERSION() {
        return VERSION;
    }
}