/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.owasp.webscarab.plugin.jmx.export;

import java.io.*;
import java.util.LinkedList;

import org.apache.jorphan.collections.HashTree;
import org.apache.jorphan.collections.HashTreeTraverser;
import org.owasp.webscarab.plugin.jmx.protocol.http.HTTPSampler;
import org.owasp.webscarab.plugin.jmx.elements.TestPlan;
import org.owasp.webscarab.plugin.jmx.elements.ThreadGroup;
import org.owasp.webscarab.plugin.jmx.elements.HeaderManager;

public class TestSaveService {
    private static final String FILE = "SimpleTestPlan.jmx";
    private static final File file = new File(FILE);
    private static String outName = "D:/temp/myTestPlan.jmx"; 
    private static int len=0;
    private static HashTree tree = null;
    private static int depth = 0;
    private static HTTPSampler myTemplate = null;
    private static HashTree myThreadGroup = null;
    private static HTTPSampler myClonedRequest = null;
    private static HeaderManager myHeaderTemplate = null;
    private static HeaderManager myClonedHeader = null;
    private static LinkedList currentPath = new LinkedList();

    private void printNodes() {
    	PrintKeys visitor = this.new PrintKeys();
    	tree.traverse(visitor);
    }
  
	PrintKeys visitor = this.new PrintKeys();

    private class PrintKeys implements HashTreeTraverser {
    	public void addNode(Object key, HashTree subTree) {
        	depth += 1;
          	 if ( key instanceof TestPlan  && myTemplate == null) {
          		currentPath.addLast(key);
         	} else if ( key instanceof ThreadGroup && myTemplate == null) {
         		currentPath.addLast(key);
     		    myThreadGroup = subTree;
         	} else if (key instanceof HTTPSampler && myTemplate == null) {
         		myTemplate = (HTTPSampler)((HTTPSampler) key).clone();
           	} else if ( key instanceof HeaderManager && myHeaderTemplate == null) {
           		myHeaderTemplate = (HeaderManager)((HeaderManager) key).clone();
           	}
        	System.out.println("Show Node:" + key + " Depth:" + depth);
        }
 
        public void subtractNode() {
            depth -= 1;
        }
        
        public void processPath() {
        }
    }
    
	public static void main(String[] args) throws Exception {
        byte[] original = new byte[1000000];
    	InputStream in;
        
        try {
            in = new FileInputStream(file);          
            len = in.read(original);
            in.close();
        }    catch(FileNotFoundException e)    {
        	System.out.println("File " + file.getAbsolutePath() +
                                      " could not be found on filesystem");
        }    catch(IOException ioe)    {
        	System.out.println("Exception while reading the file" + ioe);
        }

        in = new ByteArrayInputStream(original, 0, len);
        try {
        	 tree = SaveService.loadTree(in);
        } catch(Exception e)    {
        	System.out.println("Exception while parsing xml" + e);
        }
        
        try {
        	in.close();
        }    catch(IOException ioe)    {
        	System.out.println("Exception while closing stream" + ioe);
        }

		
        if (tree != null) {
        	TestSaveService ts = new TestSaveService();
        	ts.printNodes();
        	myThreadGroup.remove(myTemplate);
        	ts.printNodes();
        	System.out.println("Initialized");
        	
	        myClonedRequest = (HTTPSampler)((HTTPSampler) myTemplate).clone();
        	myThreadGroup.add(myClonedRequest);
      		currentPath.addLast(myClonedRequest);
      		myClonedHeader = (HeaderManager)((HeaderManager) myHeaderTemplate).clone();
      		tree.add(currentPath, myClonedHeader);
        	ts.printNodes();
/*
        	currentPath.removeLast();
	        myClonedRequest = (HTTPSampler)((HTTPSampler) myTemplate).clone();
      		currentPath.addLast(myClonedRequest);
            myClonedRequest.setName("homeShop2");
            myClonedRequest.setPath("/shop2");
        	myThreadGroup.add(myClonedRequest);
      		myClonedHeader = (HeaderManager)((HeaderManager) myHeaderTemplate).clone();
      		tree.add(currentPath, myClonedHeader);
        	ts.printNodes();
            
        	currentPath.removeLast();
        	myClonedRequest = (HTTPSampler)((HTTPSampler) myTemplate).clone();;
      		currentPath.addLast(myClonedRequest);
            myClonedRequest.setName("homeShop3");
            myClonedRequest.setPath("/shop3");
        	myThreadGroup.add(myClonedRequest);
      		myClonedHeader = (HeaderManager)((HeaderManager) myHeaderTemplate).clone();
      		tree.add(currentPath, myClonedHeader);
*/
        	ts.printNodes();

        	ByteArrayOutputStream out = new ByteArrayOutputStream(1000000);
 
	        try {
	        	SaveService.saveTree(tree, out);
	        }    catch(IOException ioe)    {
	        	System.out.println("Exception while saving tree" + ioe);
	        }
	        
	        try {
	        	out.close(); // Make sure all the data is flushed out
	        }    catch(IOException ioe)    {
	        	System.out.println("Exception while output stream" + ioe);
	        }
 
	        // We only check the length of the result. Comparing the
	        // actual result (out.toByteArray==original) will usually
	        // fail, because the order of the properties within each
	        // test element may change. Comparing the lengths should be
	        // enough to detect most problem cases...
	        int outsz=out.size();
	        // Allow for input in CRLF and output in LF only
	        int lines=0;
	        byte ba[]=out.toByteArray();
	        for(int j=0;j<ba.length;j++) {
	            if (ba[j] == '\n'){
	                lines++;
	            }
	        }
	        System.out.println("Ready! new length: " + outsz + " Original: " + len);
	        
        	FileOutputStream fout = new FileOutputStream(outName);
            try {
            	out.writeTo(fout);
            	out.flush();
            } finally {
              fout.close();
            }
        }
    }
}
