/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.owasp.webscarab.plugin.jmx.export;

import java.io.*;
import java.util.LinkedList;

import org.apache.jorphan.collections.HashTree;
import org.apache.jorphan.collections.HashTreeTraverser;
import org.owasp.webscarab.plugin.jmx.protocol.http.HTTPSampler;
import org.owasp.webscarab.plugin.jmx.elements.HeaderManager;
import org.owasp.webscarab.plugin.jmx.elements.TestPlan;
import org.owasp.webscarab.plugin.jmx.elements.ThreadGroup;

public class JmxExportService {
    private static final String FILE = "SimpleTestPlan.jmx";

    private String outName = "D:/temp/myTestPlan.jmx"; 
    
    private HashTree jmxTree = null;
    private HashTree subTreeThreadGroup = null;
    
    private HTTPSampler httpSamplerTemplate = null;
    private HTTPSampler clonedHttpRequest = null;
    private boolean templateLoaded = false;

    private HeaderManager headerManagerTemplate = null;
    private HeaderManager clonedHeaderManager = null;
    private LinkedList currentPath = new LinkedList();

    private class PrepareTemplates implements HashTreeTraverser {
    	public void addNode(Object key, HashTree subTree) {
         	 if ( key instanceof TestPlan && httpSamplerTemplate == null) {
           		currentPath.addLast(key);
         	} else if ( key instanceof ThreadGroup  && httpSamplerTemplate == null) {
           		currentPath.addLast(key);
        		subTreeThreadGroup = subTree;
          	} else if (key instanceof HTTPSampler && httpSamplerTemplate == null) {
        		httpSamplerTemplate = (HTTPSampler)((HTTPSampler) key).clone();
        	} else if ( key instanceof HeaderManager && headerManagerTemplate == null) {
        		headerManagerTemplate = (HeaderManager)((HeaderManager) key).clone();
            }
        }
 
        public void subtractNode() {
        }
        
        public void processPath() {
        }
    }

	public JmxExportService() throws Exception {
		loadTemplate();
	}

	private void loadTemplate() throws Exception  {
	       File templateFile = new File(FILE);
	       byte[] original = new byte[1000000];
	    	InputStream in;
	    	int len = 0;
	        
	        try {
	            in = new FileInputStream(templateFile);          
	            len = in.read(original);
	            in.close();
	        }    catch(FileNotFoundException e)    {
	        	System.out.println("template File " + templateFile.getAbsolutePath() +
	                                      " could not be found on filesystem");
	        }    catch(IOException ioe)    {
	        	System.out.println("Exception while reading the template file" + ioe);
	        }

	        in = new ByteArrayInputStream(original, 0, len);
	        try {
	        	 jmxTree = SaveService.loadTree(in);
	        } catch(Exception e)    {
	        	System.out.println("Exception while parsing xml" + e);
	        }
	        
	        try {
	        	in.close();
	        }    catch(IOException ioe)    {
	        	System.out.println("Exception while closing stream" + ioe);
	        }
	        
	        if (jmxTree != null) {
	        	PrepareTemplates visitor = this.new PrepareTemplates();
	        	jmxTree.traverse(visitor);
	            templateLoaded = true;
	        }
	        subTreeThreadGroup.remove(httpSamplerTemplate);
	        return;	
	}
	
	public HTTPSampler jmxCreateHttpRequest(){
		if ( templateLoaded == true ) {
			clonedHttpRequest = (HTTPSampler)((HTTPSampler) httpSamplerTemplate).clone();
			return clonedHttpRequest;
		}
		return null;
	}
	
	public HTTPSampler getClonedHttpRequest() {
		return clonedHttpRequest;
    }

	public void appendHttpRequest(HTTPSampler newHttpRequest) {
		subTreeThreadGroup.add(newHttpRequest);
        if (clonedHeaderManager != null) {
        	currentPath.addLast(newHttpRequest);
        	jmxTree.add(currentPath, clonedHeaderManager);
        	currentPath.removeLast();
        	clonedHeaderManager = null;
        }
		clonedHttpRequest = null;
		return;
    }
	
	public HeaderManager jmxCreateHeaderManager(){
		if ( templateLoaded == true) {
			clonedHeaderManager = (HeaderManager)((HeaderManager) headerManagerTemplate).clone();
			return clonedHeaderManager;
		}
		return null;
	}

	public HeaderManager getClonedHeaderManager() {
		return clonedHeaderManager;
    }

	public void setOutName( String fileName ) {
		outName = fileName;
	}

	public String getOutName( ) {
		return outName;
	}

	public boolean getTemplateLoaded( ) {
		return templateLoaded;
	}
	
	public void jmxExportTestplan() throws Exception {
    	ByteArrayOutputStream out = new ByteArrayOutputStream(1000000);
    	 
        try {
        	SaveService.saveTree(jmxTree, out);
        }    catch(IOException ioe)    {
        	System.out.println("Exception while saving tree" + ioe);
        }
        
        try {
        	out.close(); // Make sure all the data is flushed out
        }    catch(IOException ioe)    {
        	System.out.println("Exception while output stream" + ioe);
        }

        FileOutputStream outFile = new FileOutputStream(outName);
        try {
        	out.writeTo(outFile);
        	out.flush();
        } finally {
        	outFile.close();
        }
        templateLoaded = false;
        jmxTree = null;
        subTreeThreadGroup = null;
        clonedHttpRequest = null;

		loadTemplate();		
	}
}
