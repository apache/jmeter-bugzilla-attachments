/*
 * Created on 25-Sep-2003
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
package org.apache.jmeter.protocol.tcp;

import org.apache.jmeter.util.JMeterUtils;

/**
 * @author
 * @version $revision$ $date$
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class TCPUtils
{

    /**
     * 
     */
    public TCPUtils()
    {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/*
	 * Utility method to get a resource, with suitable default if it does not exist
	 * [Useful for development!]
	 */
	public static String getResourceString(String resource){
		String s = JMeterUtils.getResString(resource);
		if (s == null || s.length()==0) {
			s="[resource:"+resource+"]";
		}
		return s;
	}

}
