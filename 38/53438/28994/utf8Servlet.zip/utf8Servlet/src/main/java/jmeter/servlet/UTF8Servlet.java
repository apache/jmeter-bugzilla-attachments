/**
 * 
 */
package jmeter.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author ddigma
 * 
 */
public class UTF8Servlet extends HttpServlet {

    /**
     * Testing a GET request that puts UTF-8 chars in the response to show if
     * JMeter is displaying them properly.
     */
    @Override
    protected void doGet(final HttpServletRequest req, final HttpServletResponse resp) throws ServletException,
            IOException {
        resp.setContentType("text/xml; charset=UTF-8");
        resp.getWriter().println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        resp.getWriter().println(this.buildXMLBody());
    }

    private String buildXMLBody() {
        return new StringBuilder().append("<TestClass>").append("<utf8>漢字汉字Äöß</utf8>").append("</TestClass>")
                .toString();
    }
}