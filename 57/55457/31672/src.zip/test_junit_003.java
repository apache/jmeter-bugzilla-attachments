
public class test_junit_003 {

	public static void main(String[] args) {
		
		test_junit_002.testLab("5");
		test_junit_004.testLab(5);

	}

}
