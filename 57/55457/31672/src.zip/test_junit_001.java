import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;



public class test_junit_001 {
	
	public int x = 1;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {}

	@Before
	public void setUp() throws Exception {}

	@Test
	public final void testLab () {
		
		for (int i = 1; i<10; i++){
			System.out.println("Counter number is " + i);
		}
		System.out.println("Test Executed " + x + " number of times.");
		x++;
	}

	@After
	public void tearDown() throws Exception {}
}
