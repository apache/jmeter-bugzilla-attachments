import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class test_junit_002 {
	
	public static int x = 1;
	
		@BeforeClass
		public static void setUpBeforeClass() throws Exception {}

		@AfterClass
		public static void tearDownAfterClass() throws Exception {}

		@Before
		public void setUp() throws Exception {}

		@Test
		public static void testLab (String j) {
			//String str = j;
			System.out.println("Reference Variable value received from Jmeter is " + j);
			int i = Integer.parseInt(j);
			for (; i<10; i++){
				System.out.println("Internal Counter number is " + i);
				System.out.println("Reference Received from Jmeter is " + j);
			}
			
			System.out.println("Test Execution done " + x + " number of times.");
			x++;
		}

		@After
		public void tearDown() throws Exception {}

}
