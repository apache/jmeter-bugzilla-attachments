/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.mail.sampler;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.io.UnsupportedEncodingException;
import java.security.KeyStore;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;

import org.apache.jmeter.protocol.mail.sampler.tools.UnexpectedSuccessException;

import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.property.BooleanProperty;
import org.apache.jmeter.testelement.property.IntegerProperty;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.apache.jmeter.protocol.mail.sampler.tools.*;

/**
 * @author Thad Smith, modified by Michael Tschannen
 */
public class MailReaderSampler extends AbstractSampler {
	private static final Logger log = LoggingManager.getLoggerForClass();

	private final static String SERVER_TYPE = "host_type"; // $NON-NLS-1$
	private final static String SERVER = "host"; // $NON-NLS-1$
	private final static String USERNAME = "username"; // $NON-NLS-1$
	private final static String PASSWORD = "password"; // $NON-NLS-1$
	private final static String FOLDER = "folder"; // $NON-NLS-1$
	private final static String DELETE = "delete"; // $NON-NLS-1$
	private final static String NUM_MESSAGES = "num_messages"; // $NON-NLS-1$
	private static final String NEW_LINE = "\n"; // $NON-NLS-1$
	
	// Needed by GUI
	public final static String TYPE_POP3 = "pop3"; // $NON-NLS-1$
	public final static String TYPE_IMAP = "imap"; // $NON-NLS-1$
	
	public final static String SECURITY_SSL = "useSSL";
	public final static String SECURITY_STARTTLS = "useStartTLS";
	public final static String TRUST_ALL_CERTS = "trustAllCerts";
	public final static String USE_LOCAL_TRUSTSTORE = "installTrustStore";
	public final static String INSTALL_TRUSTSTORE = "useLocalTrustStore";
	public final static String TRUSTSTORE_TO_USE = "trustStoreToUse";
	public final static String TRUSTSTORE_TO_INSTALL = "trustStoreToInstall";
	public final static String CHECK_FOR_FAILURE = "CheckForFailure";
	
	public static final int ALL_MESSAGES = -1;
	
	public static final String TRUST_ALL_SOCKET_FACTORY = "org.apache.jmeter.protocol.mail.sampler.tools.TrustAllSSLSocketFactory";
	
	private Message message;

	public MailReaderSampler() {
		setServerType(TYPE_POP3);
		setFolder("INBOX");
		setNumMessages(ALL_MESSAGES);
		setDeleteMessages(false);
	}

	/*
	 * (non-Javadoc) Performs the sample, and returns the result
	 * 
	 * @see org.apache.jmeter.samplers.Sampler#sample(org.apache.jmeter.samplers.Entry)
	 */
	public SampleResult sample(Entry e) {
		SampleResult res = new SampleResult();
		boolean isOK = false; // Did sample succeed?
		boolean deleteMessages = getDeleteMessages();

		res.setSampleLabel(getName());
        res.setSamplerData(getServerType() + "://" + getUserName() + "@" + getServer());
		/*
		 * Perform the sampling
		 */
		res.sampleStart(); // Start timing
		StringBuffer data = new StringBuffer();
		
		try {
			// Create empty properties
			Properties props = new Properties();
			//props.put("mail.debug","true");
			if(getUseSSL() && getServerType().equalsIgnoreCase("POP3")) {
				props.setProperty( "mail.pop3.port", "995" );
				if(getTrustAllCerts()) {
					props.setProperty("mail.pop3.socketFactory.class", TRUST_ALL_SOCKET_FACTORY );
					props.setProperty("mail.pop3.socketFactory.fallback", "false");
					props.setProperty("mail.pop3.socketFactory.port","995");
				}
			} else if(getUseSSL() && getServerType().equalsIgnoreCase("IMAP")) {
				props.setProperty( "mail.imap.port", "993" );
				if(getTrustAllCerts()) {
					props.setProperty("mail.imap.socketFactory.class", TRUST_ALL_SOCKET_FACTORY );
					props.setProperty("mail.imap.socketFactory.fallback", "false");
					props.setProperty("mail.imap.socketFactory.port","995");
				}
			} 
			
			/* else if(getUseStartTLS()  && getServerType().equalsIgnoreCase("POP3")) {
				// TODO doesn't work with java mail 1.4 obviously...
				
				props.put("mail.debug", "true");
				props.put("mail.pop3.starttls.enable", "true");
				// props.setProperty("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				// props.put("mail.pop3.port", 110);
                // props.put("mail.pop3.starttls.enable","true");
                // props.put("mail.pop3.socketFactory.port", 110);
                // props.put("mail.pop3.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
                // props.put("mail.pop3.socketFactory.fallback", "false"); 
			} */
			else if(getUseStartTLS()  && getServerType().equalsIgnoreCase("IMAP")) {
				props.put("mail.imap.starttls.enable", "true");
			}
			
			// build a local truststore with server certificate
			if(getInstallTrustStore()) {
				String trustStoreFilename = "jmeterTrustStore";
				String pw = new String ("changeit");
				InstallCert installCert = new InstallCert(getTrustStoreToInstall(), trustStoreFilename, pw); 
				if(!installCert.buildCertStore()) {
					throw new Exception("Failed to build truststore");
				}
				char[] keyStorePassword = pw.toCharArray();
				KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
				java.io.FileInputStream fis = null;
			    try {
			        fis = new java.io.FileInputStream(trustStoreFilename);
			        ks.load(fis, keyStorePassword);
			    } 
			    finally {
			        if (fis != null) {
			            fis.close();
			        }
			    }
			    System.setProperty("javax.net.ssl.trustStore", trustStoreFilename);
			}
			
			// use a pre-built local truststore with server certificate
			if(getUseLocalTrustStore()) {
				System.setProperty("javax.net.ssl.trustStore", getTrustStoreToUse());
			}			
			
			// Get session
			Session session = Session.getDefaultInstance(props, null);

			// Get the store
			Store store = session.getStore(getServerType());
			
			if (getCheckForFailure()) {
				try {
					store.connect(getServer(), getUserName(), getPassword());
					throw new UnexpectedSuccessException("Expected failure but got success...");
				} 
				// I don't care which exception is thrown, just want the sampler to be unsuccessful...
				catch(Exception ex) {
					/*
					 * Set up the sample result details
					 */
					
					res.setDataType(SampleResult.TEXT);
					res.setResponseMessage("Retrieving message failed - as you expected");
					res.setResponseCodeOK();
					isOK = true;
					res.sampleEnd();
					res.setSuccessful(isOK);
					return res;
				}
			} else {
				store.connect(getServer(), getUserName(), getPassword());
			}
			
			// Get folder
			Folder folder = store.getFolder(getFolder());
			if (deleteMessages) {
			    folder.open(Folder.READ_WRITE);
			} else {
			    folder.open(Folder.READ_ONLY);
			}

			// Get directory
			Message messages[] = folder.getMessages();
			/* StringBuffer data = new StringBuffer(); */
			data.append(messages.length);
			data.append(" messages found\n");

			int n = getNumMessages();
			if (n == ALL_MESSAGES || n > messages.length)
				n = messages.length;

			// TODO - create a sample result for each message?
			for (int i = 0; i < n; i++) {
				message = messages[i];

				if (i == 0) { // Assumes all the messaged have the same type ...
					res.setContentType(message.getContentType());
				}
				data.append("Message "); // $NON-NLS-1$
				data.append(message.getMessageNumber());
				data.append(":\n"); // $NON-NLS-1$
				
				data.append("Size: "); // $NON-NLS-1$
				data.append(message.getSize());
				data.append(":\n"); // $NON-NLS-1$
				
				data.append("Date: "); // $NON-NLS-1$
				data.append(message.getSentDate());
				data.append(NEW_LINE);

				data.append("To: "); // $NON-NLS-1$
				Address[] recips = message.getAllRecipients();
				for (int j = 0; j < recips.length; j++) {
					data.append(recips[j].toString());
					if (j < recips.length - 1)
						data.append("; "); // $NON-NLS-1$
				}
				data.append(NEW_LINE);

				data.append("From: "); // $NON-NLS-1$
				Address[] from = message.getFrom();
				for (int j = 0; j < from.length; j++) {
					data.append(from[j].toString());
					if (j < from.length - 1)
						data.append("; "); // $NON-NLS-1$
				}
				data.append(NEW_LINE);

				Object content = message.getContent();
				
				if (content instanceof MimeMultipart) {
					MimeMultipart mmp = (MimeMultipart) content;
					
					/* TODO hier klepfts... */
					int count = mmp.getCount();
					data.append("Multipart. Count: ");
					data.append(count);
					data.append(NEW_LINE);
					for (int j=0; j<count;j++){
						BodyPart bodyPart = mmp.getBodyPart(j);
						data.append("Type: ");
						data.append(bodyPart.getContentType());
						data.append(NEW_LINE);
						try {
							data.append(bodyPart.getContent());
						} catch (UnsupportedEncodingException ex){
							data.append(ex.getLocalizedMessage());
						}
						data.append(NEW_LINE);
					} 
				} else {
				    data.append(content);
					data.append(NEW_LINE);
				} 
				data.append(NEW_LINE);

				if (deleteMessages) {
					message.setFlag(Flags.Flag.DELETED, true);
				}
			}

			// Close connection
			folder.close(true);
			store.close();

			/*
			 * Set up the sample result details
			 */
			res.setBytes(res.getBytes() + message.getSize());
			res.setResponseData(data.toString().getBytes());
			res.setDataType(SampleResult.TEXT);
			res.setResponseMessage("Mail retrieved - subject: " + message.getSubject());
			res.setResponseCodeOK();
			isOK = true;
        } catch (NoClassDefFoundError ex) {
            log.debug("",ex);// No need to log normally, as we set the status
            res.setResponseCode("500"); 
            res.setResponseMessage(ex.toString());
            
		} catch (NullPointerException nex) { // no mails found on server
			log.debug("", nex);
			res.setResponseCode("500");
			
			StringWriter stringWriter = new StringWriter();
			PrintWriter printWriter = new PrintWriter(stringWriter, true);
			nex.printStackTrace(printWriter);
			printWriter.flush();
			stringWriter.flush(); 
			res.setResponseMessage(stringWriter.toString());
			nex.printStackTrace();
		}
        catch (Exception ex) {
			log.debug("", ex);// No need to log normally, as we set the status
			res.setResponseCode("500");

			StringWriter stringWriter = new StringWriter();
			PrintWriter printWriter = new PrintWriter(stringWriter, true);
			ex.printStackTrace(printWriter);
			printWriter.flush();
			stringWriter.flush(); 
			res.setResponseMessage(stringWriter.toString());
			ex.printStackTrace();
			
		}

		res.sampleEnd();
		res.setSuccessful(isOK);
		return res;
	}

	/**
	 * Sets the type of protocol to use when talking with the remote mail
	 * server. Either MailReaderSampler.TYPE_IMAP or
	 * MailReaderSampler.TYPE_POP3. Default is MailReaderSampler.TYPE_POP3.
	 * 
	 * @param serverType
	 */
	public void setServerType(String serverType) {
		setProperty(SERVER_TYPE, serverType);
	}

	/**
	 * Returns if SSL is used to secure the communication channel
	 * 
	 * @return true if SSL is used
	 */
	public boolean getUseSSL() {
		return getPropertyAsBoolean(SECURITY_SSL);
	}
	
	/**
	 * Sets SSL to be used to secure the communication channel
	 * 
	 * @param useSSL
	 */
	public void setUseSSL(boolean useSSL) {
		setProperty(SECURITY_SSL, useSSL);
	}
	
	/**
	 * Returns if all certificates (SSL) are trusted
	 * 
	 * @return true if all certificates are trusted
	 */
	public boolean getTrustAllCerts() {
		return getPropertyAsBoolean(TRUST_ALL_CERTS);
	}
	
	/**
	 * Sets SSL-property "trust all certificates" (TrustAllSSLSocketFactory)
	 * 
	 * @param trustAllCerts
	 */
	public void setTrustAllCerts(boolean trustAllCerts) {
		setProperty(TRUST_ALL_CERTS, trustAllCerts);
	}
	
	/**
	 * Returns if SSL is used to secure the communication channel
	 * 
	 * @return true if StartTLS is used
	 */
	public boolean getUseStartTLS() {
		return getPropertyAsBoolean(SECURITY_STARTTLS);
	}
	
	/**
	 * Sets StartTLs to be used to secure the communication channel
	 * 
	 * @param useStartTLS
	 */
	public void setUseStartTLS(boolean useStartTLS) {
		setProperty(SECURITY_STARTTLS, useStartTLS);
	}
	
	/**
	 * Returns if server certificate is installed prior to send message to avoid certificate-trust-exceptions
	 * 
	 * @return True if server certificate is installed 
	 */
	public boolean getInstallTrustStore() {
		return getPropertyAsBoolean(INSTALL_TRUSTSTORE);
	}
	
	/**
	 * Set server certificate to be installed prior to send message
	 * 
	 * @param installTrustStore
	 */
	public void setInstallTrustStore(boolean installTrustStore) {
		setProperty(INSTALL_TRUSTSTORE, installTrustStore);
	}
	
	/**
	 * Returns if local truststore should be used to avoid certificate-trust-exceptions
	 * 
	 * @return True if local truststore is used
	 */
	public boolean getUseLocalTrustStore() {
		return getPropertyAsBoolean(USE_LOCAL_TRUSTSTORE);
	}
	
	/**
	 * Sets local truststore to be used to avoid certificate-trust-exceptions
	 * 
	 * @param useLocalTrustStore
	 */
	public void setUseLocalTrustStore(boolean useLocalTrustStore) {
		setProperty(USE_LOCAL_TRUSTSTORE, useLocalTrustStore);
	}
	
	/**
	 * Returns path to truststore to be installed to avoid certificate-trust-exceptions
	 * 
	 * @return Path to truststore
	 */
	public String getTrustStoreToInstall() {
		return getPropertyAsString(TRUSTSTORE_TO_INSTALL);
	}
	
	/**
	 * Sets path to truststore to be installed
	 * 
	 * @param trustStoreToInstall
	 */
	public void setTrustStoreToInstall(String trustStoreToInstall) {
		setProperty(TRUSTSTORE_TO_INSTALL, trustStoreToInstall);
	}
	
	/**
	 * Returns path to local (prior-installed) truststore to be used to avoid certificate-trust-exceptions
	 * 
	 * @return Path to local truststore
	 */
	public String getTrustStoreToUse() {
		return getPropertyAsString(TRUSTSTORE_TO_USE);
	}
	
	/**
	 * Sets path to local truststore to be used to avoid certificate-trust-exceptions
	 * 
	 * @param trustStoreToUse Path to local truststore
	 */
	public void setTrustStoreToUse(String trustStoreToUse) {
		setProperty(TRUSTSTORE_TO_USE, trustStoreToUse);
	}

	/**
	 * Returns the type of the protocol set to use when talking with the remote
	 * server. Either MailReaderSampler.TYPE_IMAP or
	 * MailReaderSampler.TYPE_POP3.
	 * 
	 * @return Server Type
	 */
	public String getServerType() {
		return getProperty(SERVER_TYPE).toString();
	}

	/**
	 * @param server -
	 *            The name or address of the remote server.
	 */
	public void setServer(String server) {
		setProperty(SERVER, server);
	}

	/**
	 * @return The name or address of the remote server.
	 */
	public String getServer() {
		return getProperty(SERVER).toString();
	}

	/**
	 * @param username -
	 *            The username of the mail account.
	 */
	public void setUserName(String username) {
		setProperty(USERNAME, username);
	}

	/**
	 * @return The username of the mail account.
	 */
	public String getUserName() {
		return getProperty(USERNAME).toString();
	}

	/**
	 * @param password
	 */
	public void setPassword(String password) {
		setProperty(PASSWORD, password);
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return getProperty(PASSWORD).toString();
	}

	/**
	 * @param folder -
	 *            Name of the folder to read emails from. "INBOX" is the only
	 *            acceptable value if the server type is POP3.
	 */
	public void setFolder(String folder) {
		setProperty(FOLDER, folder);
	}

	/**
	 * @return folder
	 */
	public String getFolder() {
		return getProperty(FOLDER).toString();
	}

	/**
	 * @param num_messages -
	 *            The number of messages to retrieve from the mail server. Set
	 *            this value to -1 to retrieve all messages.
	 */
	public void setNumMessages(int num_messages) {
		setProperty(new IntegerProperty(NUM_MESSAGES, num_messages));
	}

	/**
	 * @param num_messages -
	 *            The number of messages to retrieve from the mail server. Set
	 *            this value to -1 to retrieve all messages.
	 */
	public void setNumMessages(String num_messages) {
		setProperty(new StringProperty(NUM_MESSAGES, num_messages));
	}

	/**
	 * @return The number of messages to retrieve from the mail server.
	 *         -1 denotes get all messages.
	 */
	public int getNumMessages() {
		return getPropertyAsInt(NUM_MESSAGES);
	}

	/**
	 * @return The number of messages to retrieve from the mail server.
	 *         -1 denotes get all messages.
	 */
	public String getNumMessagesString() {
		return getPropertyAsString(NUM_MESSAGES);
	}

	/**
	 * @param delete -
	 *            Whether or not to delete the read messages from the folder.
	 */
	public void setDeleteMessages(boolean delete) {
		setProperty(new BooleanProperty(DELETE, delete));
	}

	/**
	 * @return Whether or not to delete the read messages from the folder.
	 */
	public boolean getDeleteMessages() {
		return getPropertyAsBoolean(DELETE);
	}
	
	/**
	 * Returns if status Code 200 is set if sampler wasn't successful  
	 * @return True if failure should be expected
	 */
	public boolean getCheckForFailure() {
		return getPropertyAsBoolean(CHECK_FOR_FAILURE);
	}

	/**
	 * Assigns sampler to set return code 200 (successful) if sending the message failed 
	 * @param val Schould failure be expected?
	 */
	public void setCheckForFailure(boolean checkForFailure) {
		setProperty(new BooleanProperty(CHECK_FOR_FAILURE, checkForFailure));
	}
}
