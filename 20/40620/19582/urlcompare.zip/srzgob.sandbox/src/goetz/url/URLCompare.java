/*
 * Created on Feb 13, 2007
 *
 */
package goetz.url;

import java.net.URL;

/**
 * This class provides a method to compare two URLs.
 * 
 * @author Bernd G�tz
 */
public class URLCompare {
	
	/**
	 * Verifies whether url1 is equal or less than url2.
	 * 
	 * @param url1 first URL to check whether same or less than url2.
	 * @param url2 second URL the check url1 against.
	 * @return true if url1 is equal or "less" than url2.
	 */
	public static boolean isIncluded(URL url1, URL url2) {
		
		if ((url1 == null) || (url2 == null)) {
			// if any of the urls should be null, compare is false
			return false;
		}
		
		// protocol compare:
		if (!url1.getProtocol().equals(url2.getProtocol())) {
			return false;
		}
		
		// port compare:
		int url1Port = calculatePort(url1);
		int url2Port = calculatePort(url2);
		if (url1Port != url2Port) {
			return false;
		}
		
		// host compare:
		if (!url1.getHost().equals(url2.getHost())) {
			return false;
		}
		
		// path compare:
		if (url2.getPath().indexOf(url1.getPath()) != 0) {
			return false;
		}
		
		return true;
	}

	/**
	 * Returns the "real" port for default ports (-1).
	 * 
	 * We only care about http and https as protocols here.
	 * 
	 * @param url url to calculate port on.
	 * @return "real" port.
	 */
	public static int calculatePort(URL url) {
		int port = url.getPort();
		if (port == -1) {
			if (url.getProtocol().equals("http")) {
				port = 80;
			} else if (url.getProtocol().equals("https")) {
				port = 443;
			}
			// anything else we don't care about at this moment
		}
		return port;
	}
	
}
