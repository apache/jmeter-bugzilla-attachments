/*
 * Created on Feb 13, 2007
 *
 */
package goetz.url;

import java.net.URL;

import junit.framework.TestCase;

/**
 * Test cases for URL comparison.
 * 
 * @author Bernd G�tz
 */
public class URLCompareTest extends TestCase {

	public void testNull() throws Exception {
		URL url1 = null;
		URL url2 = null;

		assertFalse("Compare should be false", URLCompare
				.isIncluded(url1, url2));

		url1 = new URL("http", "myhost", 80, "/a/b");
		url2 = null;

		assertFalse("Compare should be false", URLCompare
				.isIncluded(url1, url2));

		url1 = null;
		url2 = new URL("http", "myhost", 80, "/a/b");

		assertFalse("Compare should be false", URLCompare
				.isIncluded(url1, url2));

	}

	/**
	 * Tests the method a first time with all information given.
	 * 
	 * @throws Exception
	 */
	public void testSimpleUrls() throws Exception {
		URL url1 = new URL("http", "myhost", 80, "/a");
		URL url2 = new URL("http", "myhost", 80, "/a/b");

		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));
	}

	/**
	 * Checks inclusion on path level.
	 * 
	 * @throws Exception
	 */
	public void testPaths() throws Exception {
		URL url1 = new URL("http://www.urbanophile.com/");
		URL url2 = new URL("http://www.urbanophile.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// path of first url is longer:
		url1 = new URL("http://www.urbanophile.com/arenn/bubu");
		url2 = new URL("http://www.urbanophile.com/arenn/");
		assertFalse("url2 should not include url1", URLCompare.isIncluded(url1,
				url2));

		// no paths
		url1 = new URL("http://www.urbanophile.com");
		url2 = new URL("http://www.urbanophile.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// no paths
		url1 = new URL("http://www.urbanophile.com");
		url2 = new URL("http://www.urbanophile.com");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// with file
		url1 = new URL("http://www.urbanophile.com/arenn");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// with file
		url1 = new URL("http://www.urbanophile.com/arenn/index.jsp");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// with file and parameters
		url1 = new URL("http://www.urbanophile.com/arenn");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=one");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		url1 = new URL("http://www.urbanophile.com/arenn/index.jsp");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=one");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		url1 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=one");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=one");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// with file and different parameters
		// TODO: should url2 really include url1
		url1 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=two");
		url2 = new URL("http://www.urbanophile.com/arenn/index.jsp?role=one");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

	}

	/**
	 * Checks equality on ports.
	 * 
	 * @throws Exception
	 */
	public void testPorts() throws Exception {
		URL url1 = new URL("http://www.urbanophile.com:80/");
		URL url2 = new URL("http://www.urbanophile.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// first url with non-standard port:
		url1 = new URL("http://www.urbanophile.com:81/");
		url2 = new URL("http://www.urbanophile.com/arenn/");
		assertFalse("url2 should not include url1", URLCompare.isIncluded(url1,
				url2));

		// both non-standard port:
		url1 = new URL("http://www.urbanophile.com:81/");
		url2 = new URL("http://www.urbanophile.com:81/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// https:
		url1 = new URL("https://www.urbanophile.com/");
		url2 = new URL("https://www.urbanophile.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// https:
		url1 = new URL("https://www.urbanophile.com:443/");
		url2 = new URL("https://www.urbanophile.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// https:
		url1 = new URL("https://www.urbanophile.com:444/");
		url2 = new URL("https://www.urbanophile.com:444/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// https:
		url1 = new URL("https://www.urbanophile.com/");
		url2 = new URL("https://www.urbanophile.com:444/arenn/");
		assertFalse("Port is not the same", URLCompare.isIncluded(url1, url2));

	}

	/**
	 * Checks for host equality. This contains most ambiguities, I guess.
	 * 
	 * TODO: check RfC on how Browser should provide basic auth headers to
	 * servers
	 * 
	 * @throws Exception
	 */
	public void testHosts() throws Exception {
		URL url1 = new URL("http://chrs3175.zrh.swissre.com/");
		URL url2 = new URL("http://chrs3175.zrh.swissre.com/arenn/");
		assertTrue("url2 should include url1", URLCompare
				.isIncluded(url1, url2));

		// TODO: host name ambiguity, could be another host, if there
		// are several chrs3175 servers in different domains.
		url1 = new URL("http://chrs3175/");
		url2 = new URL("http://chrs3175.zrh.swissre.com/arenn/");
		assertFalse("Host is not the same", URLCompare.isIncluded(url1, url2));

		// no hosts given:
		url1 = new URL("http://");
		url2 = new URL("http://");
		assertTrue("urls are the same", URLCompare.isIncluded(url1, url2));

		// no host given:
		url1 = new URL("http://");
		url2 = new URL("http://chrs3175.zrh.swissre.com/arenn/");
		assertFalse("Hosts are not the same", URLCompare.isIncluded(url1, url2));

	}

}
