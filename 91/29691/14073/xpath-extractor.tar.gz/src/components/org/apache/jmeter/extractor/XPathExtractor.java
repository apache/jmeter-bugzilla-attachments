/*
 * Copyright 2003-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
*/

package org.apache.jmeter.extractor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Serializable;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import junit.framework.TestCase;
import junit.textui.TestRunner;

import org.apache.jmeter.processor.PostProcessor;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.property.BooleanProperty;
import org.apache.jmeter.testelement.property.IntegerProperty;
import org.apache.jmeter.threads.JMeterContext;
import org.apache.jmeter.threads.JMeterContextService;
import org.apache.jmeter.threads.JMeterVariables;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.util.XPathUtil;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 * @version $Revision: 1.17 $
 */
public class XPathExtractor
    extends AbstractTestElement
    implements PostProcessor, Serializable
{
    transient private static Logger log = LoggingManager.getLoggerForClass();
    public static final String XPATH		= "XPathExtractor.xpath";
    public static final String REFNAME		= "XPathExtractor.refname";
    public static final String MATCH_NUMBER = "XPathExtractor.match_number";
    public static final String DEFAULT		= "XPathExtractor.default";
    public static final String TOLERANT		= "XPathExtractor.tolerant";
    public static final String WHITESPACE   = "XPathExtractor.whitespace";
    public static final String NAMESPACE    = "XPathExtractor.namespace";
    public static final String VALIDATE     = "XPathExtractor.validate";
    
    /**
     * Parses the response data using regular expressions and saving the results
     * into variables for use later in the test.
     * @see org.apache.jmeter.processor.PostProcessor#process()
     */
    public void process()
    {
        JMeterContext context = getThreadContext();
        if (context.getPreviousResult() == null
            || context.getPreviousResult().getResponseData() == null)
        {
            return;
        }
        log.debug("XPathExtractor processing result");

        // Fetch some variables
		JMeterVariables vars = context.getVariables();
		String refName = getRefName();
		int matchNumber = getMatchNumber();
	//	log.debug("got "+refName+" for matchNumber "+matchNumber);
        
	        Document doc =null;
	        NodeList nodeList = null;
		    Node match;
			try {
				
				doc = XPathUtil.makeDocument(
						new ByteArrayInputStream(context.getPreviousResult().getResponseData()), 
							isWhitespace(),
								isValidate(),
									isNamespace(), 
										isTolerant() );
				nodeList = XPathAPI.selectNodeList(doc, getXPath());
			} catch (ParserConfigurationException e) {
				log.warn(e.getLocalizedMessage());
			} catch (SAXException e) {
				log.warn(e.getLocalizedMessage());
			} catch (IOException e) {
				log.warn(e.getLocalizedMessage());
			} catch (TransformerException e) {
				log.warn(e.getLocalizedMessage());
			}
	
			if (nodeList == null || nodeList.getLength() < 1 ) {
				vars.put(refName, getDefaultValue());
				return;
			}
			
			log.debug("match number "+matchNumber);
			if (matchNumber >= 0 ) {
				int listSize = nodeList.getLength();

				for (int i=0;i<listSize;i++) {
					match = getCorrectNode(nodeList, i);
					if (match != null) {
						if (matchNumber == i) vars.put(refName, generateResult(match));
						vars.put(refName+"_"+i, generateResult(match));
					}
				}

			}else {
				match = getCorrectNode(nodeList, matchNumber );
				    if (match != null)
				    {
				    	log.debug("match here "+matchNumber);
				        vars.put(refName, generateResult(match));
				    }
			}
    }

    public Object clone()
    {
        XPathExtractor cloned = (XPathExtractor) super.clone();
        return cloned;
    }

    private String generateResult(Node match)
    {
    	if (match == null) {
    		log.warn("Node is null");
    		return "";
    	}

		String result = null;
    	try {
    		result = match.getTextContent();
    	}catch(AbstractMethodError abe) {
    	  	log.debug(match.toString());
    	    result = match.getNodeValue();
    	}
  //      log.debug(new StringBuffer("XPath Extractor result = ").append( result).toString());
        return result;
    }

    /**
     * Grab the appropriate result from the list.
     * @param matches list of matches
     * @param entry the entry number in the list
     * @return MatchResult
     */
    private Node getCorrectNode(NodeList matches, int entry)
    {
        int matchSize = matches.getLength();

        if ( matchSize < 1 || entry > matchSize) return null;
        
		if (entry == -1) // Random match
		{
			log.debug("random match");
			entry =	JMeterUtils.getRandomInt(matchSize);
		}
    
        return (Node) matches.item(entry);
    }
    /**
     * Sets the xpath to use.
     * @param xpath
     */
    public void setXpath(String xpath)
    {
        setProperty(XPATH, xpath);
    }
    /**
     * The xpath to use for this extractor.
     * @return
     */
    public String getXPath()
    {
        return getPropertyAsString(XPATH);
    }
    /**
     * Set the name to reference this by.
     * By default it will be xpath
     * @param refName
     */
    public void setRefName(String refName)
    {
        setProperty(REFNAME, refName);
    }
    /**
     * Name of variable to reference variable.  If match number is -1 or 
     * they are assigned to the $refName_X and a random element is assigned
     * to $refName
     * @return
     */
    public String getRefName()
    {
        return getDefaultPropertyAsString(REFNAME,"xpath");
    }
    /**
     * Returns weather it is using XML namespaces.
     * @return
     */
    public boolean isNamespace() {
    	return getPropertyAsBoolean(NAMESPACE, false);
    }
    /**
     * Set weather to use XML namespaces.
     * @param namespace
     */
    public void setNamespace(boolean namespace) {
    	setProperty(new BooleanProperty(NAMESPACE, namespace));
    }
    /**
     * Returns the status of whitespace
     * @return
     */
    public boolean isWhitespace() {
    	return getPropertyAsBoolean(WHITESPACE, false);
    }
    /**
     * Ignore element whitespce
     * @param whitespace
     */
    public void setWhitespace(boolean whitespace) {
    	setProperty(new BooleanProperty(WHITESPACE, whitespace));
    }
    /**
     * Should this document be validated. Currently only DTD validation
     * @return
     */
    public boolean isValidate() {
    	return getPropertyAsBoolean(VALIDATE, false);
    }
    /**
     * Set weather this document needs to be valid. Not just well formed.
     * @param validate
     */
    public void setValidate(boolean validate) {
     	setProperty(new BooleanProperty(VALIDATE, validate));
         	
    }
    /**
     * Returns if it is tolerant of poorly formed xml.  By default false;
     * @return
     */
    public boolean isTolerant() {
    	return getPropertyAsBoolean(TOLERANT, false);
    }
    /**
     * Sets weather the parser is tolerant of poorly formed html/xml
     * if true namespace, whitespace and validating is ignored.
     * @param tolerant
     */
    public void setTolerant(boolean tolerant) {
    	setProperty(new BooleanProperty(TOLERANT, tolerant));
    }
    /**
     * Set which Match to use.  This can be any positive number, indicating the
     * exact match to use, or 0, which is interpreted as meaning random.
     * @param matchNumber
     */
    public void setMatchNumber(int matchNumber)
    {
        setProperty(new IntegerProperty(MATCH_NUMBER, matchNumber));
    }
    /**
     * Return the match Number;
     * @return
     */
    public int getMatchNumber()
    {
        return getPropertyAsInt(MATCH_NUMBER);
    }

    /**
     * Sets the value of the variable if no matches are found
     * @param defaultValue
     */
    public void setDefaultValue(String defaultValue)
    {
        setProperty(DEFAULT, defaultValue);
    }
    /**
     * Returns the default value that will be assigned to matching nodes
     * @return
     */
    public String getDefaultValue()
    {
    	return getDefaultPropertyAsString(DEFAULT, "default");
    }
    /**
     * Helper to return the default property if it is null, or of zero length
     * @param key property Key
     * @param defValue Default value if property key is not found
     * @return
     */
    public String getDefaultPropertyAsString(String key, String defValue) {
    	String reg = getPropertyAsString(key);
        if (reg == null || reg.length() == 0) return defValue;
        return reg;
    }
    public static class XPathExtractorTest extends TestCase
    {
        XPathExtractor extractor;
        SampleResult result;
        JMeterVariables vars;

        public XPathExtractorTest(String name)
        {
            super(name);
        }

        private JMeterContext jmctx = null;

        public void setUp()
        {
        	jmctx = JMeterContextService.getContext();
            extractor = new XPathExtractor();
            extractor.setThreadContext(jmctx);// This would be done by the run command
            extractor.setRefName("regVal");
          
            result = new SampleResult();
            String data =
                "<company-xmlext-query-ret>" +                  "<row>" +                    "<value field=\"RetCode\">LIS_OK</value>" +                    "<value field=\"RetCodeExtension\"></value>" +                    "<value field=\"alias\"></value>" +                    "<value field=\"positioncount\"></value>" +                    "<value field=\"invalidpincount\">0</value>" +                    "<value field=\"pinposition1\">1</value>" +                    "<value field=\"pinpositionvalue1\"></value>" +                    "<value field=\"pinposition2\">5</value>" +                    "<value field=\"pinpositionvalue2\"></value>" +                    "<value field=\"pinposition3\">6</value>" +                    "<value field=\"pinpositionvalue3\"></value>" +                  "</row>" +                "</company-xmlext-query-ret>";
            result.setResponseData(data.getBytes());
            vars = new JMeterVariables();
            jmctx.setVariables(vars);
            jmctx.setPreviousResult(result);
        }

        public void testVariableExtraction() throws Exception
        {
          //  extractor.setTemplate("$2$");
        	extractor.setXpath("//row/value/@field");
        	extractor.setMatchNumber(2);
        	extractor.process();
            System.out.println(extractor.getRefName()+" "+vars.get("regVal"));
            assertEquals("alias", vars.get(extractor.getRefName()));
//			assertEquals("pinposition2", vars.get("regVal_g1"));
////			assertEquals("5", vars.get("regVal_g2"));
//			assertEquals("<value field=\"pinposition2\">5</value>", vars.get("regVal_g0"));
        }
        public void testDefaultValue() throws Exception
        {
          //  extractor.setTemplate("$2$");
        	extractor.setXpath("//row/novalue/@field");
        	extractor.setDefaultValue("test");
            extractor.process();
            assertEquals("test", vars.get("regVal"));
            System.out.println(vars.get("regVal"));
      }
        public void testVarNumValue() throws Exception
        {
          //  extractor.setTemplate("$2$");
        	extractor.setXpath("//row/value/@field");
        	extractor.setDefaultValue("test");
            extractor.process();
            assertEquals("alias", vars.get("regVal_2"));
            System.out.println(vars.get("regVal_2"));
      }
        
        public void testNamedVarNumValue() throws Exception
        {
          //  extractor.setTemplate("$2$");
        	extractor.setXpath("//row/value/@field");
        	extractor.setDefaultValue("test");
        	extractor.setRefName("xpath");
        	extractor.process();
            assertEquals("RetCode", vars.get("xpath_0"));
            System.out.println(vars.get("xpath_2"));
      }
        public void testHtmlExtractor() throws Exception 
		{
            result = new SampleResult();
            String data =
                "<html><head><title>testtitle</title></head>"+
				"<body><i><b>bad tag alignment</i></b><br><hr>"+
				"</body></html>";
            result.setResponseData(data.getBytes());
            vars = new JMeterVariables();
            jmctx.setVariables(vars);
            jmctx.setPreviousResult(result);
        	extractor.setXpath("/html/head/title");
        	extractor.setRefName("html");
        	extractor.setTolerant(true);
        	extractor.process();
            assertEquals("testtitle", vars.get("html"));
        
		}

        public static void main(String[] args) {
        	TestRunner.run(XPathExtractorTest.class);
        }
    }
}
