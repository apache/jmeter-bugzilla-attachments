/*
 * Copyright 2003-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
*/

package org.apache.jmeter.extractor.gui;

import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.jmeter.extractor.XPathExtractor;
import org.apache.jmeter.processor.gui.AbstractPostProcessorGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.util.XPathUtil;
import org.apache.jmeter.util.gui.XMLConfPanel;
import org.apache.jmeter.util.gui.XPathPanel;
import org.apache.jorphan.gui.JLabeledTextField;
import org.apache.jorphan.gui.layout.VerticalLayout;

/**
 */
public class XPathExtractorGui extends AbstractPostProcessorGui
{
	private static final Log log = LogFactory.getLog(XPathExtractorGui.class);
	private IntegerDocument  intDoc = new IntegerDocument();
	
	private JLabeledTextField defaultField;
    private JLabeledTextField matchNumberField;
    private JLabeledTextField refNameField;
    
  
	private XPathPanel xPathPanel;
	private XMLConfPanel xmlConfPanel;
    public XPathExtractorGui()
    {
        super();
        init();
    }

    public String getLabelResource()
    {
        return "xpath_extractor_title";
    }
    
    public void configure(TestElement el)
    {
        super.configure(el);
        if (el instanceof XPathExtractor) {
        	XPathExtractor xp = (XPathExtractor)el;
        	getXPathPanel().setXPath(xp.getXPath());
        	getXmlConfPanel().setWhitespace(xp.isWhitespace());
        	getXmlConfPanel().setNamespace(xp.isNamespace());
        	getXmlConfPanel().setTolerant(xp.isTolerant());
        	getDefaultField().setText(xp.getDefaultValue());
        	getRefNameField().setText(xp.getRefName());
        	setMatchNumber(xp.getMatchNumber());
        }
    }

    /**
     * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
     */
    public TestElement createTestElement()
    {
        XPathExtractor extractor = new XPathExtractor();
        modifyTestElement(extractor);
        return extractor;
    }

    /**
     * Modifies a given TestElement to mirror the data in the gui components.
     * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
     */
    public void modifyTestElement(TestElement extractor)
    {
    	super.configureTestElement(extractor);

        if(extractor instanceof XPathExtractor)
        {
        	XPathExtractor xe = (XPathExtractor)extractor;
            xe.setRefName(getRefNameField().getText());
            xe.setMatchNumber(getMatchNumber());
            xe.setValidate(getXmlConfPanel().isValidate());
            xe.setWhitespace(getXmlConfPanel().isWhitespace());
            xe.setTolerant(getXmlConfPanel().isTolerant());
            xe.setDefaultValue(getDefaultField().getText());
        }
    }
    public JLabeledTextField getMatchNumberField() {
    	if (matchNumberField == null) {
    		matchNumberField =  new JLabeledTextField(JMeterUtils.getResString("xpath_match_num_field"));
    		matchNumberField.setText(String.valueOf("-1"));
    		((JTextField) matchNumberField.getComponent(1)).setDocument(intDoc);
    		matchNumberField.setSize(1,2);
    	}
    	return matchNumberField;
    }
    
    public int getMatchNumber() {
    	try {
    		return new Integer(getMatchNumberField().getText()).intValue();
    	}catch(NumberFormatException nfe) {
    		log.debug(nfe.getLocalizedMessage());
    		return -1;
    	}
    }
    
    public void setMatchNumber(int matchNumber) {
    	getMatchNumberField().setText(String.valueOf(matchNumber));
    }

    private void init()
    {
    	  setLayout(
    	        new VerticalLayout(5, VerticalLayout.LEFT, VerticalLayout.TOP));
    	  setBorder(makeBorder());
/*   	add(makeTitlePanel());
    	JPanel sizePanel = new JPanel(new BorderLayout());
	    sizePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
	    sizePanel.setBorder(
	        BorderFactory.createTitledBorder(
	            BorderFactory.createEtchedBorder(),
	            getLabelResource()));
        */
	    Box box = Box.createVerticalBox();
	    box.add(makeTitlePanel());
	    box.add(Box.createVerticalGlue());
	    
	    box.add(getXPathPanel());
	    box.add(Box.createVerticalGlue());
	    box.add(getXmlConfPanel());
	    box.add(Box.createVerticalGlue());
	    box.add(makeParameterPanel());
        add(box);
//	    add(makeTitlePanel());
//        sizePanel.add(getXPathPanel(), BorderLayout.NORTH);
 //       sizePanel.add(getXmlConfPanel(), BorderLayout.SOUTH);
//	    add(getXPathPanel(), BorderLayout.NORTH);
//	    add(getXmlConfPanel(),BorderLayout.SOUTH);
//	    add(sizePanel);
//        add(makeParameterPanel(), BorderLayout.CENTER);

    }
    


	private JPanel makeParameterPanel()
    {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(
	            BorderFactory.createEtchedBorder(),
	            JMeterUtils.getResString("xpath_extraction_parameters")));
        GridBagConstraints gbc = new GridBagConstraints();
        initConstraints(gbc);
        addField(panel,getRefNameField(),gbc);
        resetContraints(gbc);
        addField(panel,getMatchNumberField(),gbc);
        resetContraints(gbc);
        gbc.weighty = 1;
        addField(panel,getDefaultField(),gbc);
        return panel;
    }
    
    private void addField(
        JPanel panel,
        JLabeledTextField field,
        GridBagConstraints gbc)
    {
        List item = field.getComponentList();
        if (item.size() > 1) {
        panel.add((Component)item.get(0),gbc.clone());
        gbc.gridx++;
        gbc.weightx = 1;;
        panel.add((Component)item.get(1),gbc.clone());
        }
    }
    
    private void resetContraints(GridBagConstraints gbc)
    {
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
    }
    private void initConstraints(GridBagConstraints gbc)
    {
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.NONE;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.weighty = 0;
    }
	/**
	 * @return Returns the defaultField.
	 */
	public JLabeledTextField getDefaultField() {
		if (defaultField == null) {
			defaultField =  new JLabeledTextField(JMeterUtils.getResString("xpath_default_field")); 
		}
		return defaultField;
	}
	/**
	 * @return Returns the refNameField.
	 */
	public JLabeledTextField getRefNameField() {
		if (refNameField == null) {
			refNameField =  new JLabeledTextField(JMeterUtils.getResString("xpath_refname_field")); 
					
		}
		return refNameField;
	}
	/**
	 * @return Returns the xmlConfPanel.
	 */
	public XMLConfPanel getXmlConfPanel() {
		if (xmlConfPanel == null) {
			xmlConfPanel = new XMLConfPanel();
			xmlConfPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
			xmlConfPanel.setBorder(
		        BorderFactory.createTitledBorder(
		            BorderFactory.createEtchedBorder(),
		            JMeterUtils.getResString("xml_conf_border")));
		}
		return xmlConfPanel;
	}
	/**
	 * @return Returns the xpathPanel.
	 */
	public XPathPanel getXPathPanel() {
		if (xPathPanel == null) {
			xPathPanel = new XPathPanel();
			xPathPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
			xPathPanel.setBorder(
		        BorderFactory.createTitledBorder(
		            BorderFactory.createEtchedBorder(),
		            JMeterUtils.getResString("xpath_border")));
			xPathPanel.setShowNegated(false);
		}
		
		return xPathPanel;
	}
  
	static class IntegerDocument
    extends PlainDocument {

  public void insertString(int offset,
      String string, AttributeSet attributes)
      throws BadLocationException {

    if (string == null) {
      return;
    } else {
      String newValue;
      int length = getLength();
      if (length == 0) {
        newValue = string;
      } else {
        String currentContent =
          getText(0, length);
        StringBuffer currentBuffer =
          new StringBuffer(currentContent);
        currentBuffer.insert(offset, string);
        newValue = currentBuffer.toString();
      }
      try {
      	log.debug("length "+length+" "+string.charAt(0));
      	if (!(newValue.charAt(0) == '-' && newValue.length() == 1)) {
        Integer.parseInt(newValue);
      	}
        super.insertString(offset, string,
          attributes);
      } catch (NumberFormatException exception) {
      	 JOptionPane.showMessageDialog(
                null,
				new StringBuffer(XPathUtil.getResString("xml_match_num_field_invalid", "Not a number")).append(' ').append(string).toString(),
				new StringBuffer(XPathUtil.getResString("xml_match_num_field_invalid", "Not a number")).append(' ').append(string).toString(),
				JOptionPane.ERROR_MESSAGE 
				);
		   }
      }
    }
  }
 
	
}
