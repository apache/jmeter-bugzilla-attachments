package org.apache.jmeter.gui;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.text.JTextComponent;

/**
 * This class implements a JPanel consisting of a static label (in the default
 * Locale named "Comments:") and a JTextArea with a height of three rows and
 * word wrapping behavior.
 */
public class CommentPanel extends BasicPanel {

  /**
   * Create a new CommentPanel with the default name.
   */
  public CommentPanel() {
    super();
  }

  protected String getTypeCode() {
    return "testplan_comments";
  }

  protected JTextComponent initTextComponent() {
    JTextArea textArea = new JTextArea(3, 0);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    return textArea;
  }

  protected void addElements(JLabel label, JTextComponent component) {
    add(label, BorderLayout.NORTH);
    JScrollPane scrollPane = new JScrollPane(component,
                                             JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    add(scrollPane, BorderLayout.CENTER);
  }

  public String getStaticLabel() {
    return "";
  }

  /**
   * Called when the name changes. The tree node which this component names
   * will be notified of the change.
   *
   */
  protected void updateTextValue() {
  }

}
