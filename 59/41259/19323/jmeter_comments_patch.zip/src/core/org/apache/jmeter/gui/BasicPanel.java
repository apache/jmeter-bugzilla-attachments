package org.apache.jmeter.gui;

import java.awt.BorderLayout;
import java.util.Collection;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;
import javax.swing.text.JTextComponent;
import javax.swing.tree.TreeNode;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;

import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.util.LocaleChangeEvent;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.WorkBench;
import org.apache.jmeter.testelement.property.StringProperty;

/**
 * This class is used as a base class for <code>JPanel</code>s containing one
 * label and one text component.
 */
public abstract class BasicPanel extends JPanel implements JMeterGUIComponent {

  /**
   * A text component containing the text value.
   */
  private JTextComponent textComponent;
  /**
   * The label for the text field.
   */
  private JLabel textLabel;
  /**
   * The node which this component is providing the name for.
   */
  private TreeNode node;

  protected BasicPanel() {
    init();
    setName(getStaticLabel());
  }

  /**
   * Initialize the GUI components and layout.
   */
  private void init() {
    setLayout(new BorderLayout(5, 0));

    textComponent = initTextComponent();

    String type = getTypeCode();
    textLabel = new JLabel(JMeterUtils.getResString(type));
    textLabel.setName(type);
    textLabel.setLabelFor(textComponent);

    textComponent.getDocument().addDocumentListener(new DocumentListener() {
      public void insertUpdate(DocumentEvent e) {
        updateTextValue();
      }

      public void removeUpdate(DocumentEvent e) {
        updateTextValue();
      }

      public void changedUpdate(DocumentEvent e) {
        // not for text fields
      }
    });

    addElements(textLabel, textComponent);
  }

  /**
   * This method is used to construct the text component for this
   * <code>BasicPanel</code>.
   *
   * @return A suitable instance  of <code>JTextComponent</code>
   */
  protected abstract JTextComponent initTextComponent();

  protected abstract String getTypeCode();

  /**
   * This method positions the two components of this <code>BasicPanel</code>
   * in a suitable way.
   *
   * @param label This <code>BasicPanel</code>'s label
   * @param component This <code>BasicPanel</code>'s text componentc
   */
  protected abstract void addElements(JLabel label, JTextComponent component);

  public void clear() {
    setName(getStaticLabel());
  }

  /**
   * Get the currently displayed name.
   *
   * @return the current name
   */
  public String getName() {
    if (textComponent != null) {
      return textComponent.getText();
    }
    else {
      return "";
    }
  }

  /**
   * Set the name displayed in this component.
   *
   * @param name the name to display
   */
  public void setName(String name) {
    super.setName(name);
    textComponent.setText(name);
    textComponent.setToolTipText(name);
  }

  /**
   * Get the tree node which this component provides the name for.
   *
   * @return the tree node corresponding to this component
   */
  protected TreeNode getNode() {
    return node;
  }

  /**
   * Set the tree node which this component provides the name for.
   *
   * @param node the tree node corresponding to this component
   */
  public void setNode(TreeNode node) {
    this.node = node;
  }

  /* Implements JMeterGUIComponent.configure(TestElement) */
  public void configure(TestElement testElement) {
    setName(testElement.getPropertyAsString(TestElement.NAME));
  }

  /* Implements JMeterGUIComponent.createPopupMenu() */
  public JPopupMenu createPopupMenu() {
    return null;
  }

  /* Implements JMeterGUIComponent.getStaticLabel() */
  public String getStaticLabel() {
    return JMeterUtils.getResString(getLabelResource());
  }

  /*
	 * (non-Javadoc)
	 *
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getLabelResource()
	 */
  public String getLabelResource() {
    return "root";
  }

  /* Implements JMeterGUIComponent.getMenuCategories() */
  public Collection getMenuCategories() {
    return null;
  }

  /* Implements JMeterGUIComponent.createTestElement() */
  public TestElement createTestElement() {
    WorkBench wb = new WorkBench();
    modifyTestElement(wb);
    return wb;
  }

  /* Implements JMeterGUIComponent.modifyTestElement(TestElement) */
  public void modifyTestElement(TestElement wb) {
    wb.setProperty(new StringProperty(TestElement.NAME, getName()));
    wb.setProperty(new StringProperty(TestElement.GUI_CLASS,
                                      this.getClass().getName()));
    wb.setProperty(new StringProperty(TestElement.TEST_CLASS,
                                      WorkBench.class.getName()));
  }

  protected abstract void updateTextValue();

  /**
   * Called when the locale is changed so that the label can be updated. This
   * method is not currently used.
   *
   * @param event the event to be handled
   */
  public void localeChanged(LocaleChangeEvent event) {
    textLabel.setText(JMeterUtils.getResString(textLabel.getName()));
  }

  /*
	 * (non-Javadoc)
	 *
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getDocAnchor()
	 */
  public String getDocAnchor() {
    // TODO Auto-generated method stub
    return null;
  }
}
