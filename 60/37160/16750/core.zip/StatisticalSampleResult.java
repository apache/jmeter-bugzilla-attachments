package org.apache.jmeter.samplers;

import java.io.Serializable;


/**
 * @author Lars Krog-Jensen
 *         Created: 2005-okt-04
 */
public class StatisticalSampleResult
  extends SampleResult
  implements Serializable
{

  // Redefine these parameters as the super class
  // has private access to those...
  // TODO: Should relax the acess modifiers in the superclass
  protected long startTime = Long.MAX_VALUE;
  protected long endTime = Long.MIN_VALUE;
  protected long idleTime = 0;

  protected int errorCount;

  public StatisticalSampleResult(SampleResult res)
  {
    setSampleLabel(res.getSampleLabel());
  }

  public void add(SampleResult res)
  {
    // Add Sample Counter
    setSampleCount(getSampleCount() + res.getSampleCount());

    // Add bytes
    int bytesLength = 0;
    // in case the sampler doesn't return the contents
    // we see if the bytes was set
    if (res.getResponseData() == null || res.getResponseData().length == 0) {
      bytesLength = res.getBytes();
    } else {
      bytesLength = res.getResponseData().length;
    }
    setBytes(getBytes() + bytesLength);

    // Add Error Counter
    if (!res.isSuccessful()) {
      errorCount++;
    }

    // Set start/end times
    startTime = Math.min(startTime, res.getStartTime());
    endTime = Math.max(endTime, res.getEndTime());
  }

  public long getTime()
  {
    return endTime - startTime - idleTime;
  }

  public long getEndTime()
  {
    return endTime;
  }

  public long getStartTime()
  {
    return startTime;
  }

  public long getTimeStamp()
  {
    return getEndTime();
  }

  public int getErrorCount()
  {
    return errorCount;
  }

  public static String getKey(SampleEvent event)
  {
    String key = event.getResult().getSampleLabel() + "-" + event.getThreadGroup();

    return key;
  }
}
