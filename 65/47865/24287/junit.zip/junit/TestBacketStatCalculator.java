/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jorphan.math;

import java.util.Random;

import junit.framework.TestCase;

public class TestBacketStatCalculator extends TestCase {

 private BacketStatCalculator calculator;
 
 private StatCalculator defaultCalculator;
    
    protected void setUp() throws Exception {
        super.setUp();
        calculator = new BacketStatCalculator();
        defaultCalculator = new StatCalculator();
    }
    
    public void test() {
        Random random = new Random();
        int iteriation = 20;
        int value;
        for (int i = 0; i < iteriation; i++) {
            for (int j = 0; j < BacketStatCalculator.REFRESH_RATE; j++) {
                value = random.nextInt(50000);
                calculator.addValue(value);
                calculator.addBytes(value);
                defaultCalculator.addValue(value);
                defaultCalculator.addBytes(value);
            }
            assertEquals(defaultCalculator.getCount(), calculator.getCount());
            assertEquals(defaultCalculator.getTotalBytes(), calculator.getTotalBytes());
            assertEquals(defaultCalculator.getMean(), calculator.getMean());
            assertEquals(defaultCalculator.getStandardDeviation(), calculator.getStandardDeviation());
            assertEquals(defaultCalculator.getMin().doubleValue(), calculator.getMin().doubleValue());
            assertEquals(defaultCalculator.getMax().doubleValue(), calculator.getMax().doubleValue());
            assertEquals(defaultCalculator.getPercentPoint(0.5), calculator.getPercentPoint(0.5));
            assertEquals(defaultCalculator.getPercentPoint(0.9), calculator.getPercentPoint(0.9));
            assertEquals(defaultCalculator.getPercentPoint(0.99), calculator.getPercentPoint(0.99));
            assertEquals(defaultCalculator.getPercentPoint(0.999), calculator.getPercentPoint(0.999));
        }
    }
    
}
