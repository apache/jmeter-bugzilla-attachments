/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jorphan.math;

import junit.framework.TestCase;

public class TestUpgradedStatCalculator extends TestCase {

    private UpgradedStatCalculator calculator;
    
    protected void setUp() throws Exception {
        super.setUp();
        int clearLimit = 10;
        calculator = new UpgradedStatCalculator(clearLimit);
    }

    public void testStandardOperation() throws Exception {     
        calculator.addValue(8);
        calculator.addValue(9);
        calculator.addValue(5);
        calculator.addValue(6);
        calculator.addValue(4);
        assertEquals(5, calculator.getCount());
        // number of values is below clearLimit so lines (90, 99, 99.9%) are not calculated
        assertEquals(0, calculator.getPercentPoint(0.9).intValue());
        assertEquals(0, calculator.getPercentPoint(0.99).intValue());
        assertEquals(0, calculator.getPercentPoint(0.999).intValue());
        assertEquals(6.4, calculator.getMean());
        assertEquals(9, calculator.getMax().intValue());
        assertEquals(4, calculator.getMin().intValue());
        
        calculator.addValue(3);
        calculator.addValue(10);
        calculator.addValue(2);
        calculator.addValue(1);
        calculator.addValue(7);
        assertEquals(10, calculator.getCount());
        assertEquals(5.5, calculator.getMean());
        assertEquals(10, calculator.getMax().intValue());
        assertEquals(1, calculator.getMin().intValue());
        System.out.println("ClearLimit:" + System.getProperty("clearLimit") + "|" + calculator.getFulfilment());
        assertEquals(2.8722813232690143299253057341095, calculator.getStandardDeviation());
    }
    
    public void testData() throws Exception { 
        int count = 1000;
        calculator = new UpgradedStatCalculator(count);
        for (int i = 1; i <= count/3; i++) {
            calculator.addValue(i);
            calculator.addValue(i + count/3);
            calculator.addValue(2 * (count/3) + i);   
            assertEquals(2 * (count/3) + i, calculator.getMax().intValue());
            assertEquals(1, calculator.getMin().intValue());
            assertEquals(3 * i, calculator.getCount());
        }
        calculator.addValue(count);
        
        assertEquals(count, calculator.getCount());
        assertEquals(count, calculator.getMax().intValue());
        assertEquals(1, calculator.getMin().intValue());
        
        assertEquals(500.5, calculator.getMean());
        assertEquals((int)(count * 0.9 + 1), calculator.getPercentPoint(0.9).intValue());
        assertEquals((int)(count * 0.99 + 1), calculator.getPercentPoint(0.99).intValue());
        assertEquals((int)(count * 0.999 + 1), calculator.getPercentPoint(0.999).intValue());
    }
}
