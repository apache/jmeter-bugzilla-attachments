/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jmeter.visualizers;

import java.text.DecimalFormat;
import java.text.Format;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.jmeter.samplers.SampleResult;
import org.apache.jorphan.io.ResultLogger;
import org.apache.jorphan.math.UpgradedStatCalculator;

/**
 * Similar to {@link SamplingStatCalculator} but uses
 * {@link UpgradedStatCalculator} instead of {@link StatCalculator}. Due to
 * performance problem in {@link SamplingStatCalculator} this class uses
 * ReentrantLocks instead of synchronized keyword. Can log partial result to
 * given {@link ResultLogger} in case of system/machine failure/restart those
 * result can be used to calculate overall statistics.
 */
public class UpgradedSamplingStatCalculator extends SamplingStatCalculator {

    private Sample lastSample = new Sample();

    private long count = 0;

    private ReentrantLock calculatorLock = new ReentrantLock();

    private ReentrantLock firstTimeLock = new ReentrantLock();

    private ReentrantLock lastSampleLock = new ReentrantLock();

    {
        calculator = new UpgradedStatCalculator();
    }

    public UpgradedSamplingStatCalculator(String label,
            final ResultLogger resultLogger) {
        super(label);
        // wraps given result logger to log extra data like error count, error
        // percentage, rate and KB/Sec.
        ((UpgradedStatCalculator) calculator)
                .setResultLogger(new ResultLogger() {

                    private Format numberFormat = new DecimalFormat("#0.00");

                    private ResultLogger wrapped = resultLogger;

                    @Override
                    public boolean isEnabled() {
                        return wrapped.isEnabled();
                    }

                    @Override
                    public void log(String... values) {
                        List<String> valuesList = new ArrayList<String>(Arrays
                                .<String> asList(values));
                        valuesList.add(numberFormat
                                .format(UpgradedSamplingStatCalculator.super
                                        .getErrorPercentage()));
                        valuesList.add(Long
                                .toString(UpgradedSamplingStatCalculator.super
                                        .getErrorCount()));
                        valuesList.add(numberFormat
                                .format(UpgradedSamplingStatCalculator.super
                                        .getRate()));
                        valuesList.add(numberFormat
                                .format(UpgradedSamplingStatCalculator.super
                                        .getKBPerSecond()));
                        wrapped.log(valuesList.toArray(new String[0]));
                    }

                    @Override
                    public void setHeader(String... header) {
                        String[] newHeader = new String[header.length + 4];
                        System
                                .arraycopy(header, 0, newHeader, 0,
                                        header.length);
                        newHeader[header.length] = "Error %";
                        newHeader[header.length + 1] = "Error Count";
                        newHeader[header.length + 2] = "Rate";
                        newHeader[header.length + 3] = "KB/sec";
                    }
                });
    }

    public Sample addAndGetSample(SampleResult res) {
        long rtime, cmean, cstdv, cmedian, cpercent, eCount, endTime;
        double throughput;
        boolean rbool;
        long byteslength = res.getBytes();

        setStartTime(res);
        endTime = getEndTime(res);
        calculatorLock.lock();
        try {
            // if there was more than 1 loop in the sample, we
            // handle it appropriately
            if (res.getSampleCount() > 1) {
                long time = res.getTime() / res.getSampleCount();
                long resbytes = byteslength / res.getSampleCount();
                for (int idx = 0; idx < res.getSampleCount(); idx++) {
                    calculator.addValue(time);
                    calculator.addBytes(resbytes);
                }
            } else {
                calculator.addValue(res.getTime());
                calculator.addBytes(byteslength);
            }

            eCount = getCurrentSample().getErrorCount();
            if (!res.isSuccessful()) {
                eCount++;
            }

            long howLongRunning = endTime - firstTime;
            throughput = ((double) calculator.getCount() / (double) howLongRunning) * 1000.0;
            if (throughput > maxThroughput) {
                maxThroughput = throughput;
            }

            rtime = res.getTime();
            cmean = (long) calculator.getMean();
            cstdv = (long) calculator.getStandardDeviation();
            cmedian = calculator.getMedian().longValue();
            // TODO cpercent is the same as cmedian here - why? and why pass it
            // to "distributionLine"?
            cpercent = calculator.getMedian().longValue();
            rbool = res.isSuccessful();
        } finally {
            calculatorLock.unlock();
        }

        lastSampleLock.lock();
        try {
            count++;
            Sample s = new Sample(null, rtime, cmean, cstdv, cmedian, cpercent,
                    throughput, eCount, rbool, count, endTime);
            lastSample = s;
            return s;
        } finally {
            lastSampleLock.unlock();
        }
    }

    @SuppressWarnings("unchecked")
    public void addSamples(SamplingStatCalculator ssc) {
        calculator.addAll(ssc.calculator);
        lastSampleLock.lock();
        try {
            Collections.sort(ssc.getSamples());
            ssc.getSamples().get(ssc.getSamples().size() - 1);
        } finally {
            lastSampleLock.unlock();
        }
        setStartTime(ssc.firstTime);
    }

    /**
     * Clear the counters (useful for differential stats)
     */
    public synchronized void clear() {
        super.clear();
        firstTime = Long.MAX_VALUE;
        lastSample = new Sample();
        count = 0;
    }

    public Sample getCurrentSample() {
        lastSampleLock.lock();
        try {
            return lastSample;
        } finally {
            lastSampleLock.unlock();
        }
    }

    public Sample getSample(int index) {
        throw new UnsupportedOperationException();
    }

    public List<Sample> getSamples() {
        return Arrays.asList(new Sample[] { lastSample });
    }

    protected void setStartTime(long startTime) {
        if (firstTime > startTime) {
            firstTimeLock.lock();
            try {
                if (firstTime > startTime) {
                    firstTime = startTime;
                }
            } finally {
                firstTimeLock.unlock();
            }
        }
    }

    /**
     * @param res
     */
    protected void setStartTime(SampleResult res) {
        long startTime = res.getStartTime();
        if (firstTime > startTime) {
            firstTimeLock.lock();
            try {
                if (firstTime > startTime) {
                    firstTime = startTime;
                }
            } finally {
                firstTimeLock.unlock();
            }
        }
    }
}
