/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jorphan.math;

import java.util.HashMap;
import java.util.Map;

/**
 * Another statistics calculator designed to work with huge amount of samples
 * with high throughput. Rather not use if the maximum value of the samples is
 * high (more than 1 min if it time).Much faster than default
 * {@link StatCalculator}, can be a little slower than
 * {@link UpgradedStatCalculator} but instead of {@link UpgradedStatCalculator}
 * gives exactly value of median, 90% line, 99% line and 99.9% line (not some
 * approximation), due to performance those value are refreshed every
 * REFRESH_RATE samples. Work perfectly with {@link DistributionGraph}.
 */
public class BacketStatCalculator extends AbstractStatCalculator {

    public static final int REFRESH_RATE = 5000;
    
    private static final int BACKET_DEFAULT_SIZE = 1000;

    private long[] backets;

    private Number line90 = 0;

    private Number line99 = 0;

    private Number line999 = 0;

    private long max = 0;

    private Number median = 0;

    private long min = Long.MAX_VALUE;

    public BacketStatCalculator() {
        backets = new long[BACKET_DEFAULT_SIZE];
    }

    @Override
    public void addAll(AbstractStatCalculator calc) {
        BacketStatCalculator c = (BacketStatCalculator) calc;
        for (int i = 0; i < c.backets.length; i++) {
            if (c.backets[i] != 0) {
                for (int j = 0; j < c.backets[i]; j++) {
                    addValue(i);
                }
            }
        }

    }

    public void addValue(Number val) {
        countValue(val);
        count++;
        double currentVal = val.doubleValue();
        sum += currentVal;
        sumOfSquares += currentVal * currentVal;
        mean = sum / (double) count;

        if (currentVal > max) {
            max = val.longValue();
        } else if (currentVal < min) {
            min = val.longValue();
        }

        if (count % REFRESH_RATE == 0) {
            updateData();
        }
    }

    public void clear() {
        super.clear();
        backets = new long[BACKET_DEFAULT_SIZE];
        median = 0;
        min = Long.MAX_VALUE;
        max = 0;
        line90 = 0;
        line99 = 0;
        line999 = 0;
    }

    /**
     * The method has a limit of 1% as the finest granularity. We do this to
     * make sure we get a whole number for iterating.
     */
    public synchronized Map<Number, Number[]> getDistribution() {
        Map<Number, Number[]> items = new HashMap<Number, Number[]>();

        Number[] dis;
        long count = 0;
        for (int i = 0; i < backets.length; i++) {
            if ((count = backets[i]) != 0) {
                dis = new Number[2];
                dis[0] = i;
                dis[1] = count;
                items.put(i, dis);
            }
        }

        return items;
    }

    /**
     * Optimized version to get distribution.
     * 
     * @return
     */
    public synchronized long[] getDistributionAsTable() {
        return backets;
    }

    public Number getMax() {
        return max;
    }

    @Override
    public Number getMedian() {
        return median;
    }

    public Number getMin() {
        return min;
    }

    /**
     * Get the value which %percent% of the values are less than. This works
     * just like median (where median represents the 50% point). A typical
     * desire is to see the 90% point - the value that 90% of the data points
     * are below, the remaining 10% are above.
     * 
     * @param percent
     * @return number of values less than the percentage
     */
    public Number getPercentPoint(double percent) {
        if (percent == 0.5) {
            return median;
        } else if (percent == 0.9) {
            return line90;
        } else if (percent == 0.99) {
            return line99;
        } else if (percent == 0.999) {
            return line999;
        } else {
            throw new UnsupportedOperationException(
                    "Not available operation with:" + percent);
        }
    }

    /**
     * @param val
     */
    private void countValue(Number val) {
        int backetNumber = val.intValue();
        if (backetNumber >= backets.length) {
            long[] newBackets = new long[val.intValue() + 1];
            System.arraycopy(backets, 0, newBackets, 0, backets.length);
            backets = newBackets;
        }
        backets[backetNumber] = ++backets[backetNumber];
    }

    private void updateData() {
        deviation = Math.sqrt((sumOfSquares / count) - (mean * mean));

        int[] indexes = { (int) (count * 0.5), (int) (count * 0.9),
                (int) (count * 0.99), (int) (count * 0.999) };
        boolean[] calculate = new boolean[indexes.length];

        for (int i = 0; i < calculate.length; i++) {
            calculate[i] = true;
        }

        long index = 0;
        boolean finished = false;
        for (int i = 0; i < backets.length; i++) {
            index += backets[i];
            for (int j = 0; !finished && j < indexes.length; j++) {
                if (index <= indexes[j]) {
                    break;
                }
                if (calculate[j]) {
                    switch (j) {
                    case 0:
                        median = i;
                        break;
                    case 1:
                        line90 = i;
                        break;
                    case 2:
                        line99 = i;
                        break;
                    case 3:
                        line999 = i;
                        break;
                    default:
                        throw new IllegalArgumentException();
                    }
                    calculate[j] = false;
                    if (j == calculate.length - 1) {
                        finished = true;
                    }
                }
            }
        }
    }
}
