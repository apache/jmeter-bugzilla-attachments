package org.apache.jmeter.visualizers;

import java.util.Map;

import org.apache.jmeter.samplers.SampleResult;

/**
 * Interface for all sampling statistics calculators.
 */
public interface SamplingStatContainer {

    /**
     * Works like previous version of addSample method.
     * 
     * @param res
     * @return
     */
    public Sample addAndGetSample(SampleResult res);

    /**
     * Most of the usage of previous version (that returned Sample) of this
     * method didn't care about the returned result (Sample) so due to
     * optimization now Sample is not returned. Use addAndGetSample method if
     * previous behaviour is need.
     * 
     * @param res
     */
    public void addSample(SampleResult res);

    /**
     * Throughput in bytes / second
     * 
     * @return throughput in bytes/second
     */
    public double getBytesPerSecond();

    public void clear();

    public long getCount();

    public Map<Number, Number[]> getDistribution();

    /**
     * @return errorCount
     */
    public long getErrorCount();

    /**
     * Returns the raw double value of the percentage of samples with errors
     * that were recorded. (Between 0.0 and 1.0)
     * 
     * @return the raw double value of the percentage of samples with errors
     *         that were recorded.
     */
    public double getErrorPercentage();

    /**
     * Throughput in kilobytes / second
     * 
     * @return Throughput in kilobytes / second
     */
    public double getKBPerSecond();

    public String getLabel();

    public Number getMax();

    /**
     * @return Returns the maxThroughput.
     */
    public double getMaxThroughput();

    public double getMean();

    public Number getMeanAsNumber();

    public Number getMedian();

    public Number getMin();

    public Number getPercentPoint(double percent);

    public double getRate();

    public double getStandardDeviation();
}
