/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jmeter.visualizers;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;
import org.apache.jmeter.gui.util.FileDialoger;
import org.apache.jmeter.gui.util.HeaderAsPropertyRenderer;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.samplers.Clearable;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.save.CSVSaveService;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.visualizers.gui.AbstractVisualizer;
import org.apache.jorphan.gui.NumberRenderer;
import org.apache.jorphan.gui.ObjectTableModel;
import org.apache.jorphan.gui.RateRenderer;
import org.apache.jorphan.gui.RendererUtils;
import org.apache.jorphan.io.ResultLogger;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.jorphan.reflect.Functor;
import org.apache.jorphan.util.JOrphanUtils;
import org.apache.log.Logger;

/**
 * Similar to {@link StatVisualizer} but as a sampler use
 * {@link UpgradedSamplingStatCounter} that gives better performance. Partial
 * results of the test can be saved in csv files, one file for each sampler. To
 * synchronize threads ReentranstLocks are used instead of synchronized methods
 * and blocks. Visualiser updates (repaints) data in table once for every
 * VIEW_UPGRADE_FREQUENCY sample, this can boost performance when
 * throughput is very high.
 */
public class UpgradedStatVisualizer extends AbstractVisualizer implements
        Clearable, ActionListener {

    private static final long serialVersionUID = -2981538928444907867L;

    private static final Logger log = LoggingManager.getLoggerForClass();

    private static final String USE_GROUP_NAME = "useGroupName"; //$NON-NLS-1$

    private static final String[] COLUMNS = { "sampler_label", //$NON-NLS-1$
            "aggregate_report_count", //$NON-NLS-1$
            "average", //$NON-NLS-1$
            "avg_aggregate_report_90%_line", //$NON-NLS-1$
            "avg_aggregate_report_99%_line", //$NON-NLS-1$
            "avg_aggregate_report_99.9%_line", //$NON-NLS-1$
            "aggregate_report_min", //$NON-NLS-1$
            "aggregate_report_max", //$NON-NLS-1$
            "aggregate_report_stddev", //$NON-NLS-1$
            "aggregate_report_error_count", //$NON-NLS-1$
            "aggregate_report_error%", //$NON-NLS-1$
            "aggregate_report_rate", //$NON-NLS-1$
            "aggregate_report_bandwidth" }; //$NON-NLS-1$

    private static final int VIEW_UPGRADE_FREQUENCY = 80;

    private final String TOTAL_ROW_LABEL = JMeterUtils
            .getResString("aggregate_report_total_label"); //$NON-NLS-1$

    private final JButton saveTable = new JButton(JMeterUtils
            .getResString("aggregate_graph_save_table")); //$NON-NLS-1$

    private final JCheckBox useGroupName = new JCheckBox(JMeterUtils
            .getResString("aggregate_graph_use_group_name")); //$NON-NLS-1$

    private final JCheckBox partialResult = new JCheckBox(JMeterUtils
            .getResString("save_partial_result")); // $NON-NLS-1$

    private JTable myJTable;

    private JScrollPane myScrollPane;

    private HorizontalPanel partialLoggerPanel;

    private JTextField resultFilePrefixField;

    private JTextField savePathField;

    private ObjectTableModel model;

    private int viewUpgradeCounter = 0;

    private final Map<String, SamplingStatContainer> tableRows = Collections
            .synchronizedMap(new HashMap<String, SamplingStatContainer>());

    private ReentrantLock tableLock = new ReentrantLock();

    private ReentrantLock totalRowLock = new ReentrantLock();

    private Map<String, ReentrantLock> rowLocks = new HashMap<String, ReentrantLock>();

    public UpgradedStatVisualizer() {
        super();
        model = new ObjectTableModel(COLUMNS,
                UpgradedSamplingStatCalculator.class, new Functor[] {
                        new Functor("getLabel"), //$NON-NLS-1$
                        new Functor("getCount"), //$NON-NLS-1$
                        new Functor("getMean"), //$NON-NLS-1$
                        new Functor("getPercentPoint", //$NON-NLS-1$
                                new Object[] { new Double(0.900) }),
                        new Functor("getPercentPoint", //$NON-NLS-1$
                                new Object[] { new Double(0.990) }),
                        new Functor("getPercentPoint", //$NON-NLS-1$
                                new Object[] { new Double(0.999) }),
                        new Functor("getMin"), //$NON-NLS-1$
                        new Functor("getMax"), //$NON-NLS-1$
                        new Functor("getStandardDeviation"),
                        new Functor("getErrorCount"), //$NON-NLS-1$
                        new Functor("getErrorPercentage"), //$NON-NLS-1$
                        new Functor("getRate"), //$NON-NLS-1$
                        new Functor("getKBPerSecond") //$NON-NLS-1$
                }, new Functor[] { null, null, null, null, null, null, null,
                        null, null, null, null, null }, new Class[] {
                        String.class, Long.class, Double.class, Double.class,
                        Double.class, Double.class, Long.class, Long.class, Double.class,
                        Long.class, String.class, String.class, String.class });
        clearData();
        init();
    }

    // Column renderers
    private static final TableCellRenderer[] RENDERERS = new TableCellRenderer[] {
            null, // Label
            null, // count
            new NumberRenderer("#0.0"), // Mean
            new NumberRenderer("#0.0"), // 90%
            new NumberRenderer("#0.0"), // 99%
            new NumberRenderer("#0.0"), // 99.9%
            new NumberRenderer("#0"), // Min
            new NumberRenderer("#0"), // Max
            new NumberRenderer("#0.0"), // StdDev
            null, // Error count
            new NumberRenderer("#0.00%"), // Error %age //$NON-NLS-1$
            new RateRenderer("#.0"), // Throughput //$NON-NLS-1$
            new NumberRenderer("#.0"), // pageSize   //$NON-NLS-1$
    };

    /** @deprecated - only for use in testing */
    public static boolean testFunctors() {
        UpgradedStatVisualizer instance = new UpgradedStatVisualizer();
        return instance.model.checkFunctors(null, instance.getClass());
    }

    public String getLabelResource() {
        return "upgraded_aggregate_report"; //$NON-NLS-1$
    }

    public void add(SampleResult res) {
        SamplingStatContainer row = null;
        final String sampleLabel = res
                .getSampleLabel(useGroupName.isSelected());
        row = tableRows.get(sampleLabel);

        if (row == null) {
            tableLock.lock();
            try {
                row = (SamplingStatContainer) tableRows.get(sampleLabel);
                if (row == null) {
                    row = new UpgradedSamplingStatCalculator(sampleLabel,
                            new PartialResultLogger(sampleLabel));
                    tableRows.put(row.getLabel(), row);
                    model.insertRow(row, model.getRowCount() - 1);
                    rowLocks.put(sampleLabel, new ReentrantLock());
                }
            } finally {
                tableLock.unlock();
            }
        }

        /*
         * Synch is needed because multiple threads can update the counts.
         */
        ReentrantLock rowLock = rowLocks.get(sampleLabel);
        rowLock.lock();
        try {
            row.addSample(res);
        } finally {
            rowLock.unlock();
        }

        SamplingStatContainer total = tableRows.get(TOTAL_ROW_LABEL);

        totalRowLock.lock();
        try {
            total.addSample(res);
        } finally {
            totalRowLock.unlock();
        }

        /**
         * OPTIMIZATION
         */
        viewUpgradeCounter++;
        if (viewUpgradeCounter >= VIEW_UPGRADE_FREQUENCY) {
            viewUpgradeCounter = 0;
            model.fireTableDataChanged();
        }
    }

    /**
     * Clears this visualizer and its model, and forces a repaint of the table.
     */
    public void clearData() {
        tableLock.lock();
        try {
            model.clearData();
            tableRows.clear();
            tableRows.put(TOTAL_ROW_LABEL, new UpgradedSamplingStatCalculator(
                    TOTAL_ROW_LABEL, new PartialResultLogger(TOTAL_ROW_LABEL)));
            model.addRow(tableRows.get(TOTAL_ROW_LABEL));
        } finally {
            tableLock.unlock();
        }
    }

    /**
     * Main visualizer setup.
     */
    private void init() {
        this.setLayout(new BorderLayout());

        // MAIN PANEL
        JPanel mainPanel = new JPanel();
        Border margin = new EmptyBorder(10, 10, 5, 10);

        mainPanel.setBorder(margin);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        mainPanel.add(makeTitlePanel());

        myJTable = new JTable(model);
        myJTable.getTableHeader().setDefaultRenderer(
                new HeaderAsPropertyRenderer());
        myJTable.setPreferredScrollableViewportSize(new Dimension(500, 70));
        RendererUtils.applyRenderers(myJTable, RENDERERS);
        myScrollPane = new JScrollPane(myJTable);
        this.add(mainPanel, BorderLayout.NORTH);
        this.add(myScrollPane, BorderLayout.CENTER);
        saveTable.addActionListener(this);
        JPanel opts = new JPanel();
        opts.add(useGroupName, BorderLayout.WEST);
        opts.add(saveTable, BorderLayout.CENTER);
        this.add(opts, BorderLayout.SOUTH);
        enablePartialPanel(false);
    }

    public void modifyTestElement(TestElement c) {
        super.modifyTestElement(c);
        c.setProperty(USE_GROUP_NAME, useGroupName.isSelected(), false);
    }

    public void configure(TestElement el) {
        super.configure(el);
        useGroupName
                .setSelected(el.getPropertyAsBoolean(USE_GROUP_NAME, false));
    }

    public void actionPerformed(ActionEvent ev) {
        if (ev.getSource() == saveTable) {
            JFileChooser chooser = FileDialoger
                    .promptToSaveFile("aggregate.csv");//$NON-NLS-1$
            if (chooser == null) {
                return;
            }
            FileWriter writer = null;
            try {
                writer = new FileWriter(chooser.getSelectedFile());
                CSVSaveService.saveCSVStats(model, writer);
            } catch (FileNotFoundException e) {
                log.warn(e.getMessage());
            } catch (IOException e) {
                log.warn(e.getMessage());
            } finally {
                JOrphanUtils.closeQuietly(writer);
            }
        }
    }

    protected Container makeTitlePanel() {
        Container panel = super.makeTitlePanel();
        panel.add(createPartialResultPanel());
        return panel;
    }
    

    private void enablePartialPanel(boolean enable) {
        savePathField.setEnabled(enable);
        resultFilePrefixField.setEnabled(enable);
    }

    private HorizontalPanel createPartialResultPanel() {
        partialLoggerPanel = new HorizontalPanel();
        partialLoggerPanel.setBorder(BorderFactory.createTitledBorder(JMeterUtils.getResString("write_partial_results_to_file")));
        resultFilePrefixField = new JTextField(15);
        savePathField = new JTextField(20);

        partialResult.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                enablePartialPanel(partialResult.isSelected());
            }
        });

        partialLoggerPanel.add(new JLabel(JMeterUtils
                .getResString("partial_result_save_path")));
        partialLoggerPanel.add(savePathField);
        partialLoggerPanel.add(new JLabel(JMeterUtils
                .getResString("partial_result_file_prefix"))); // $NON-NLS-1$
        partialLoggerPanel.add(resultFilePrefixField);
        partialLoggerPanel.add(partialResult);
        return partialLoggerPanel;
    }

    class PartialResultLogger implements ResultLogger {

        private static final char separator = ';';

        private SimpleDateFormat dateFormatter = new SimpleDateFormat(
                "MM-dd HH:mm");

        private boolean writeHeader = true;

        private BufferedWriter writer;

        private String label;
        
        private String [] header;

        public PartialResultLogger(String label) {
            this.label = label;
        }

        @Override
        public boolean isEnabled() {
            return partialResult.isSelected();
        }

        @Override
        public void log(String... values) {
            if (writeHeader) {
                writeHeader();
            }
            writeData(dateFormatter.format(new Date()), values);
        }

        private void initializeLogger() {
            SimpleDateFormat formater = new SimpleDateFormat(
                    "yyyy-MM-dd_HH_mm_");
            File logFile = null;

            try {
                String prefix = resultFilePrefixField.getText();
                if (prefix == null || prefix.trim().length() == 0) {
                    prefix = formater.format(new Date());
                }

                String path = savePathField.getText();

                if (path == null || path.trim().length() == 0) {
                    logFile = File.createTempFile(prefix, "-"
                            + label.replace(' ', '_') + ".csv");
                } else {
                    logFile = new File(path, prefix + "-"
                            + label.replace(' ', '_') + ".csv");
                }
                writer = new BufferedWriter(new FileWriter(logFile));
            } catch (IOException e) {
                log.error("Cannot open writer to:" + logFile, e);
            }
        }

        private void writeHeader() {
            writeHeader = false;
            writeData("Date", header);
        }

        private void writeData(String date, String... values) {
            try {
                if (writer == null) {
                    initializeLogger();
                }
                StringBuffer buffer = new StringBuffer();
                buffer.append(date);
                buffer.append(separator);
                for (String value : values) {
                    buffer.append(value);
                    buffer.append(separator);
                }

                buffer.delete(buffer.length() - 1, buffer.length());
                writer.write(buffer.toString());
                writer.newLine();
                writer.flush();
            } catch (FileNotFoundException e) {
                log.warn(e.getMessage());
            } catch (IOException e) {
                log.warn(e.getMessage());
            }
        }

        @Override
        public void setHeader(String... header) {
            this.header = header;
        }
    }
}
