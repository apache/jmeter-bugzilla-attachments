/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jorphan.math;

import java.text.DecimalFormat;
import java.text.Format;
import java.util.Collections;

import org.apache.jorphan.io.ResultLogger;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Optimized version of {@link StatCalculator} that doesn't hold all samples but
 * only some part. This class is designed to work with huge amount of samples
 * (even 500 million or more) with high throughput (500 req/s or more). Main
 * goal is to calculate avg, standard deviation, avg 90% line, avg 99% line and
 * avg 99.9% line without holding all data. No more than MAX_COUNT samples are
 * hold. When number of samples are great than MAX_COUNT then 90% line, 99% line
 * and 99.9% are calculated on those samples. Those values are used to update
 * avg 90% line, avg 99% line and avg 99.9% Then samples are removed and
 * collected from beginning. The lower clearLimit the better performance but the
 * higher clearLimit the more accurate avg lines (90%, 99% and 99.9%).
 */
public class UpgradedStatCalculator extends StatCalculator {

    /** system property that can change clear limit - max size of data set */
    public static final String CLEAR_LIMIT_PROPERTY = "clearLimit";

    public static final int DEFAULT_MAX_COUNT = 50000;

    private static final Logger log = LoggingManager.getLoggerForClass();

    private static final int MAX_COUNT;

    private final int current_max_count;

    static {
        int count = DEFAULT_MAX_COUNT;
        if (System.getProperty(CLEAR_LIMIT_PROPERTY) != null) {
            try {
                count = Integer.parseInt(System
                        .getProperty(CLEAR_LIMIT_PROPERTY));
            } catch (NumberFormatException ex) {
                log.warn("Incorrect value of paramater clearLimit: {"
                        + System.getProperty(CLEAR_LIMIT_PROPERTY) + "}", ex);
            }
        }

        MAX_COUNT = count;
    }

    private Format numberFormat = new DecimalFormat("#0.0");

    private Format intNumberFormat = new DecimalFormat("#0");

    double allSum = 0;

    double allSumOfSquares = 0;

    double currentMean = 0;

    double allDeviation = 0;

    int allCount = 0;

    long allBytes = 0;

    long iteration = 0;

    Number min = Long.MAX_VALUE;

    Number max = 0;

    Number line90 = 0;

    Number line99 = 0;

    Number line999 = 0;

    private ResultLogger resultLogger;

    public UpgradedStatCalculator() {
        super(MAX_COUNT);
        current_max_count = MAX_COUNT;
    }

    /* only for tests */
    public UpgradedStatCalculator(int cleanLimit) {
        super(cleanLimit);
        current_max_count = cleanLimit;
    }

    public void addBytes(long newValue) {
        allBytes += newValue;
    }

    public void addValue(Number val) {
        superAddValue(val);
        allSum += val.doubleValue();
        allCount++;
        min = min.longValue() > super.getMin().longValue() ? super.getMin()
                : min;
        max = max.longValue() > super.getMax().longValue() ? max : super
                .getMax();
        currentMean = allSum / allCount;

        if (count == current_max_count) {
            sort();
            updateData();
            logData();
            super.clear();
        }
    }

    public void clear() {
        super.clear();
        allSum = 0;
        allSumOfSquares = 0;
        currentMean = 0;
        allDeviation = 0;
        allCount = 0;
        allBytes = 0;
        iteration = 0;
        min = Long.MAX_VALUE;
        max = 0;
        line90 = 0;
        line99 = 0;
        line999 = 0;
    }

    public int getCount() {
        return allCount;
    }

    public Number getMax() {
        return max;
    }

    public double getMean() {
        return currentMean;
    }

    // return mean as median
    public Number getMedian() {
        return currentMean;
    }

    public Number getMin() {
        return min;
    }

    /**
     * Get the value which %percent% of the values are less than. In this case
     * all %percent% means average from values calculated from subsets of
     * MAX_COUNT samples, where each value is the value which %percent% of the
     * values in this subset were less than. This works with 0.9, 0.99, 0.999.
     * 
     * @param percent
     * @return number of values less than the percentage
     */
    public Number getPercentPoint(double percent) {
        if (percent == 0.9) {
            return line90;
        } else if (percent == 0.99) {
            return line99;
        } else if (percent == 0.999) {
            return line999;
        } else {
            throw new UnsupportedOperationException(
                    "Not available operation with:" + percent);
        }
    }

    /**
     * Get the value which %percent% of the values are less than. In this case
     * all %percent% means average from values calculated from subsets of
     * MAX_COUNT samples, where each value is the value which %percent% of the
     * values in this subset were less than. This is one of the way to make sure
     * that 0.9 float will be parsed to 0.9 double and similar for other value.
     * If cast is used 0.9 float is parsed to 0.8999999761581421.
     * 
     * @param percent
     * @return number of values less than the percentage
     */
    public Number getPercentPoint(float percent) {
        return getPercentPoint(Double.parseDouble(Float.toString(percent)));
    }

    public double getStandardDeviation() {
        return allDeviation;
    }

    public long getTotalBytes() {
        return allBytes;
    }

    public void setResultLogger(ResultLogger resultLogger) {
        this.resultLogger = resultLogger;
        resultLogger.setHeader("Count", "Avg", "Avg 90% Line", "Avg 99% Line",
                "Avg 99.9% Line", "Min", "Max", "StdDev");
    }

    @SuppressWarnings("unchecked")
    protected void addLittleSortedValue(double val) {
        if (count > 0) {
            if (((Number) values.get(0)).doubleValue() >= val) {
                values.add(0, val);
            } else if (((Number) values.get(count - 1)).doubleValue() <= val) {
                values.add(val);
            } else {
                values.add(count - 1, val);
            }
        } else {
            values.add(val);
        }
    }

    protected double getFulfilment() {
        return super.getCount() / (double) MAX_COUNT;
    }

    protected void logData() {
        if (resultLogger != null && resultLogger.isEnabled()) {
            resultLogger.log(Integer.toString(super.getCount()), numberFormat
                    .format(super.getMean()), intNumberFormat.format(super
                    .getPercentPoint(0.9)), intNumberFormat.format(super
                    .getPercentPoint(0.99)), intNumberFormat.format(super
                    .getPercentPoint(0.999)), Long.toString(super.getMin()
                    .longValue()), Long.toString(super.getMax().longValue()),
                    numberFormat.format(super.getStandardDeviation()), Long
                            .toString(super.getTotalBytes()));
        }
    }

    @SuppressWarnings("unchecked")
    protected void sort() {
        Collections.sort(values);
    }

    protected void superAddValue(Number val) {
        double currentVal = val.doubleValue();
        addLittleSortedValue(currentVal);
        count++;
        sum += currentVal;
        sumOfSquares += currentVal * currentVal;
        mean = sum / (double) count;
        deviation = Math.sqrt((sumOfSquares / count) - (mean * mean));
    }

    protected void updateData() {
        line90 = (line90.doubleValue() * iteration + super.getPercentPoint(0.9)
                .doubleValue())
                / (iteration + 1);
        line99 = (line99.doubleValue() * iteration + super
                .getPercentPoint(0.99).doubleValue())
                / (iteration + 1);
        line999 = (line999.doubleValue() * iteration + super.getPercentPoint(
                0.999).doubleValue())
                / (iteration + 1);
        allSumOfSquares += sumOfSquares;
        allDeviation = Math.sqrt((allSumOfSquares / allCount)
                - (currentMean * currentMean));
        iteration++;
    }
}
