/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jorphan.math;

import java.util.Map;

public abstract class AbstractStatCalculator {
    
    protected long bytes = 0;

    protected int count = 0;

    protected double deviation = 0;

    protected double mean = 0;

    protected double sum = 0;

    protected double sumOfSquares = 0;

    public abstract void addAll(AbstractStatCalculator calc);
    
    public void addBytes(long newValue) {
        bytes += newValue;
    }
    
    public abstract void addValue(Number val);

    public void clear() {
        count = 0;
        sum = 0;
        sumOfSquares = 0;
        mean = 0;
        deviation = 0;
        bytes = 0;      
    }

    public int getCount() {
        return count;
    }

    /**
     * The method has a limit of 1% as the finest granularity. We do this to
     * make sure we get a whole number for iterating.
     */
    public abstract Map<Number, Number[]> getDistribution();

    public abstract Number getMax(); 

    public double getMean() {
        return mean;
    }

    public abstract Number getMedian();

    public abstract Number getMin();

    /**
     * Get the value which %percent% of the values are less than.
     * 
     * @param percent
     * @return number of values less than the percentage
     */
    public abstract Number getPercentPoint(double percent);

    public double getStandardDeviation() {
        return deviation;
    }

    public long getTotalBytes() {
        return bytes;
    }
}
