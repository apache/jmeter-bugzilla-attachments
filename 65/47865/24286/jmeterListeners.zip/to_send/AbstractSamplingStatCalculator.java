/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jmeter.visualizers;

import java.util.Map;

import org.apache.jorphan.math.AbstractStatCalculator;

/**
 * Super class for all sampling statistics calculators, implements basic methods that only wrap
 * method from used statistic calculator.
 */
public abstract class AbstractSamplingStatCalculator implements
        SamplingStatContainer {

    protected AbstractStatCalculator calculator;

    protected String label;

    /**
     * @param label
     *            the label of the calculator
     * @param calculator
     *            calculator used to calculate statistics
     */
    public AbstractSamplingStatCalculator(String label,
            AbstractStatCalculator calculator) {
        this.label = label;
        this.calculator = calculator;
    }

    /**
     * Throughput in bytes / second
     * 
     * @return throughput in bytes/second
     */
    public double getBytesPerSecond() {
        // Code duplicated from getPageSize()
        double rate = 0;
        if (getElapsed() > 0 && calculator.getTotalBytes() > 0) {
            rate = calculator.getTotalBytes() / ((double) getElapsed() / 1000);
        }
        if (rate < 0) {
            rate = 0;
        }
        return rate;
    }

    public long getCount() {
        return calculator.getCount();
    }

    public Map<Number, Number[]> getDistribution() {
        return calculator.getDistribution();
    }

    public abstract long getElapsed();

    /**
     * Throughput in kilobytes / second
     * 
     * @return Throughput in kilobytes / second
     */
    public double getKBPerSecond() {
        return getBytesPerSecond() / 1024; // 1024=bytes per kb
    }

    public String getLabel() {
        return label;
    }

    public Number getMax() {
        return calculator.getMax();
    }

    public double getMean() {
        return calculator.getMean();
    }

    public Number getMeanAsNumber() {
        return new Long((long) calculator.getMean());
    }

    public Number getMedian() {
        return calculator.getMedian();
    }

    public Number getMin() {
        if (calculator.getMin().longValue() < 0) {
            return new Long(0);
        }
        return calculator.getMin();
    }

    public Number getPercentPoint(double percent) {
        return calculator.getPercentPoint(percent);
    }

    public double getStandardDeviation() {
        return calculator.getStandardDeviation();
    }
}
