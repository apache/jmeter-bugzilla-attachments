/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.apache.jmeter.visualizers;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.jmeter.samplers.SampleResult;
import org.apache.jorphan.math.BacketStatCalculator;

/**
 * Another sampling statistics calculator optimised to work with
 * {@link DistributionGraphVisualizer} as a data model that calculate distribution with
 * higher efficiency than {@link SamplingStatCalculator} especially when number
 * of samples is huge (millions) and test takes several hours or even days.
 */
public class BacketSamplingStatCalculator extends
        AbstractSamplingStatCalculator implements SamplingStatContainer {

    protected volatile double maxThroughput;

    protected long firstTime;

    private AtomicInteger errorCount;

    private AtomicInteger count;

    private volatile double throughput = 0;

    private volatile long lastTime = 0;

    private ReentrantLock calculatorLock = new ReentrantLock();

    private ReentrantLock firstTimeLock = new ReentrantLock();

    public BacketSamplingStatCalculator(String label) {
        super(label, new BacketStatCalculator());
        clear();
    }

    /**
     * Clear the counters (useful for differential stats)
     */
    public synchronized void clear() {
        errorCount = new AtomicInteger();
        firstTime = Long.MAX_VALUE;
        maxThroughput = Double.MIN_VALUE;
        count = new AtomicInteger();
        throughput = 0;
        calculator.clear();
    }

    public long getCount() {
        return count.intValue();
    }

    /**
     * Optimized version to get distribution.
     * 
     * @return
     */
    public synchronized long[] getDistributionAsTable() {
        return ((BacketStatCalculator)calculator).getDistributionAsTable();
    }
    
    /**
     * Get the elapsed time for the samples
     * 
     * @return how long the samples took
     */
    public long getElapsed() {
        if (lastTime == 0) {
            return 0;// No samples collected ...
        }
        return lastTime - firstTime;

    }

    public long getErrorCount() {
        return errorCount.intValue();
    }

    public double getErrorPercentage() {
        double rval = 0.0;

        if (count.intValue() == 0) {
            return rval;
        }

        return errorCount.intValue() / count.intValue();
    }

    public double getMaxThroughput() {
        return maxThroughput;
    }

    public double getRate() {
        if (count.intValue() == 0) {
            return 0.0; // Better behaviour when howLong=0 or lastTime=0
        }

        return throughput;
    }

    public void addSample(SampleResult res) {
        long byteslength = res.getBytes();

        setStartTime(res);

        if (!res.isSuccessful()) {
            errorCount.incrementAndGet();
        }

        // if there was more than 1 loop in the sample, we
        // handle it appropriately
        if (res.getSampleCount() > 1) {
            long time = res.getTime() / res.getSampleCount();
            long resbytes = byteslength / res.getSampleCount();

            calculatorLock.lock();
            try {
                for (int idx = 0; idx < res.getSampleCount(); idx++) {
                    calculator.addValue(time);
                    calculator.addBytes(resbytes);
                }
            } finally {
                calculatorLock.unlock();
            }
        } else {
            calculatorLock.lock();
            try {
                calculator.addValue(res.getTime());
                calculator.addBytes(byteslength);
            } finally {
                calculatorLock.unlock();
            }
        }

        long endTime = getEndTime(res);
        long howLongRunning = endTime - firstTime;
        if (howLongRunning == 0) {
            howLongRunning = 1;
        }
        throughput = ((double) calculator.getCount() / (double) howLongRunning) * 1000.0;
        lastTime = endTime;

        if (throughput > maxThroughput) {
            maxThroughput = throughput;
        }

        count.incrementAndGet();
    }

    public Sample addAndGetSample(SampleResult res) {
        addSample(res);

        return new Sample(null, res.getTime(), (long) calculator.getMean(),
                (long) calculator.getStandardDeviation(), calculator
                        .getMedian().longValue(), calculator.getPercentPoint(
                        0.5).longValue(), (long) throughput, errorCount
                        .intValue(), res.isSuccessful(), count.intValue(),
                getEndTime(res));
    }

    /**
     * @param res
     */
    protected void setStartTime(SampleResult res) {
        long startTime = res.getStartTime();
        if (firstTime > startTime) {
            firstTimeLock.lock();
            try {
                if (firstTime > startTime) {
                    firstTime = startTime;
                }
            } finally {
                firstTimeLock.unlock();
            }
        }
    }

    protected void setStartTime(long startTime) {
        if (firstTime > startTime) {
            firstTimeLock.lock();
            try {
                if (firstTime > startTime) {
                    firstTime = startTime;
                }
            } finally {
                firstTimeLock.unlock();
            }
        }
    }

    protected long getEndTime(SampleResult res) {
        long endTime = res.getEndTime();

        if (endTime > lastTime) {
            return endTime;
        } else {
            return lastTime;
        }
    }
}
