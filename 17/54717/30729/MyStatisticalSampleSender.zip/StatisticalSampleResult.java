package net.bigpoint.jmeter.samplers;

import org.apache.jmeter.samplers.SampleResult;

/**
 * This wrapper is necessary to overwrite the time measures and the error count.
 */
public class StatisticalSampleResult extends SampleResult {

    private static final long serialVersionUID = 4893672361135573389L;

    private int errorCount;

    private final long elapsed;

    public StatisticalSampleResult(long startTime, long elapsed) {
        super();

        setStartTime(startTime); // call protected method to set start time
        this.elapsed = elapsed;
    }

    @Override
    public long getTime() {
        return elapsed;
    }

    @Override
    public long getTimeStamp() {
        return getEndTime();
    }

    @Override
    public int getErrorCount() {
        return errorCount;
    }

    @Override
    public void setErrorCount(int e) {
        errorCount = e;
    }

    @Override
    public boolean isSuccessful() {
        return (errorCount == 0);
    }
}
