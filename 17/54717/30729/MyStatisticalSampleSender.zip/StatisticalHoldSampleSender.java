package net.bigpoint.jmeter.samplers;

import static com.google.common.base.Objects.toStringHelper;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Strings.nullToEmpty;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.apache.jmeter.samplers.AbstractSampleSender;
import org.apache.jmeter.samplers.RemoteSampleListener;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import com.google.common.collect.HashMultiset;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multiset;
import com.google.common.collect.Queues;

public class StatisticalHoldSampleSender extends AbstractSampleSender implements Serializable {

    private static final long serialVersionUID = 1167910624585715712L;

    private static final Logger log = LoggingManager.getLoggerForClass();

    private static final String MARKER_NAME = "cash.markerSamplerName";

    private static final String serverConfiguredMarkerName = JMeterUtils.getProperty(MARKER_NAME); // $NON-NLS-1$

    // instance fields are copied from the client instance
    private final String clientConfiguredMarkerName = JMeterUtils.getProperty(MARKER_NAME); // $NON-NLS-1$

    private final RemoteSampleListener listener;

    private transient ThreadLocal<Map<StatisticalResult, StatisticalResult>> statisticalMapSelector;

    private transient ThreadLocal<String> threadMarker;

    private transient Queue<Map<StatisticalResult, StatisticalResult>> statisticalMaps;

    private transient String markerName;

    /**
     * Constructor, only called by client code.
     * 
     * @param listener that the List of sample events will be sent to.
     */
    public StatisticalHoldSampleSender(RemoteSampleListener listener) {
        this.listener = listener;
    }

    final void init() {
        this.statisticalMaps = Queues.newConcurrentLinkedQueue();
        this.statisticalMapSelector = new ThreadLocal<Map<StatisticalResult, StatisticalResult>>() {
            @Override
            protected java.util.Map<StatisticalResult, StatisticalResult> initialValue() {
                final Map<StatisticalResult, StatisticalResult> statisticalMap = Maps.newHashMap();

                statisticalMaps.offer(statisticalMap);
                return statisticalMap;
            };
        };
        this.threadMarker = new ThreadLocal<String>() {
            @Override
            protected String initialValue() {
                return cacheString("");
            }
        };
        this.markerName = serverConfiguredMarkerName;
        if (isClientConfigured()) {
            this.markerName = clientConfiguredMarkerName;
        }
    }

    @Override
    public void sampleOccurred(SampleEvent event) {
        checkNotNull(event);
        checkNotNull(event.getResult());

        String marker = getAndUpdateMarker(event);
        StatisticalResult key = new StatisticalResult(event, marker);
        StatisticalResult result = putIfAbsent(statisticalMapSelector.get(), key, key);
        result.update(event);
        // additional logging in case of exceptions
        if (result.responseCode.startsWith("Non HTTP")) {
            log.error(result.toString());
            log.error("URL: " + event.getResult().getUrlAsString());
            log.error("RequestHeaders:\n" + event.getResult().getRequestHeaders() + "\n---");
            log.error(event.getResult().getResponseDataAsString());
        }
    }

    /**
     * Checks if any sample events are still present in the sampleStore and
     * sends them to the listener. Informs the listener of the testended.
     * 
     * @param host the hostname that the test has ended on.
     */
    @Override
    public void testEnded(String host) {
        log.info(toStringHelper("Test Ended ").add("id", System.identityHashCode(this)).add("host", host).toString());

        List<SampleEvent> sampleEvents = Lists.newArrayList();
        Multiset<String> markers = HashMultiset.create();
        try {
            for (Map<StatisticalResult, StatisticalResult> statisticalResultMap : statisticalMaps) {
                for (StatisticalResult statisticalResult : statisticalResultMap.values()) {
                    if (log.isDebugEnabled()) {
                        log.debug("# " + Thread.currentThread().getName() + " - Add event for: " + statisticalResult);
                    }
                    sampleEvents.add(statisticalResult.createSampleEvent());
                    markers.add(statisticalResult.marker);
                }
                statisticalResultMap.clear();
            }
            listener.processBatch(sampleEvents);
            listener.testEnded(host);
            statisticalMaps.clear();
        } catch (RemoteException ex) {
            log.error("testEnded(hostname)", ex);
        }
        for (String marker : markers.elementSet()) {
            log.info("Sent " + markers.count(marker) + " events for marker '" + marker + "'");
        }
    }

    final Queue<Map<StatisticalResult, StatisticalResult>> getStatisticalMaps() {
        return statisticalMaps;
    }

    final String getMarkerName() {
        return markerName;
    }

    final String getCurrentMarker() {
        return threadMarker.get();
    }

    private static <K, V> V putIfAbsent(Map<K, V> map, K key, V value) {
        V originalValue = map.get(key);
        if (originalValue == null) {
            map.put(key, value);
            originalValue = value;
            if (log.isDebugEnabled()) {
                log.debug("# Add object to map: " + value);
            }
        }
        return originalValue;
    }

    private static String cacheString(String str) {
        return nullToEmpty(str).intern();
    }

    private String getAndUpdateMarker(SampleEvent event) {
        String label = cacheString(event.getResult().getSampleLabel());
        if (label.equals(markerName)) {
            // guarantee each thread has the same String set
            String newMarker = cacheString(event.getResult().getResponseDataAsString());
            if (log.isDebugEnabled()) {
                log.debug("# " + Thread.currentThread().getName() + " - set marker: " + newMarker);
            }
            threadMarker.set(newMarker);
        }
        return threadMarker.get();
    }

    /**
     * Processed by the RMI server code; acts as testStarted().
     * 
     * @throws ObjectStreamException
     */
    private Object readResolve() throws ObjectStreamException {
        init();

        log.info(toStringHelper("Test Started ").add("id", System.identityHashCode(this)).add("restartMarker", markerName).toString());
        return this;
    }
}
