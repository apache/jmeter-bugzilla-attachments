package net.bigpoint.jmeter.samplers;

import static com.google.common.base.Objects.firstNonNull;
import static com.google.common.base.Objects.toStringHelper;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Strings.emptyToNull;

import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.threads.JMeterVariables;

import com.google.common.base.Objects;

class StatisticalResult {

    private static final String MARKER_VARIABLE = "marker";

    final String threadGroup;

    final String threadName;

    final String label;

    final String responseCode;

    final String sampleType;

    final String marker;

    int sampleCount = 0;

    int errorCount = 0;

    int requestSize = 0;

    long startTime = Long.MAX_VALUE; // guarantee it is set with the first update()

    long endTime = 0;

    long latency = 0;

    long elapsed = 0;

    /**
     * Create a statistical sample result.
     */
    StatisticalResult(SampleEvent event, String marker) {
        checkNotNull(event);
        checkNotNull(marker);
        SampleResult result = checkNotNull(event.getResult());

        // using of intern string pool guarantees less memory usage and precalculated hashes
        this.threadGroup = cacheStringOrDefault(event.getThreadGroup(), "<unknown group>");
        this.threadName = cacheStringOrDefault(result.getThreadName(), "<unknown thread>");
        this.label = cacheStringOrDefault(result.getSampleLabel(), "<unknown label>");
        this.responseCode = cacheStringOrDefault(result.getResponseCode(), "<unknown response code>");
        this.sampleType = SaveService.classToAlias(result.getClass().getName());
        this.marker = marker.intern();
    }

    void update(SampleEvent event) {
        checkNotNull(event);
        SampleResult result = checkNotNull(event.getResult());
        if (!result.isSuccessful()) {
            errorCount++;
        }
        sampleCount += result.getSampleCount();
        requestSize += result.getBytes();
        startTime = Math.min(startTime, result.getStartTime());
        endTime = Math.max(endTime, result.getEndTime());
        latency += result.getLatency();
        elapsed += result.getTime();
    }

    SampleEvent createSampleEvent() {
        JMeterVariables variables = new JMeterVariables();
        variables.put(MARKER_VARIABLE, marker);

        SampleResult sampleResult = new StatisticalSampleResult(startTime, elapsed);

        sampleResult.setThreadName(threadName);
        sampleResult.setSampleLabel(label);
        sampleResult.setSampleCount(sampleCount);
        sampleResult.setDataType(sampleType);
        sampleResult.setBytes(requestSize);
        sampleResult.setErrorCount(errorCount);
        sampleResult.setResponseCode(responseCode);
        sampleResult.setLatency(latency);
        sampleResult.setEndTime(endTime);

        return new SampleEvent(sampleResult, threadGroup, variables);
    }

    private static String cacheStringOrDefault(String str, String defaultStr) {
        return firstNonNull(emptyToNull(str), defaultStr).intern();
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(responseCode, label, threadGroup, sampleType, marker);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }
        final StatisticalResult other = (StatisticalResult) obj;
        return Objects.equal(this.responseCode, other.responseCode) && Objects.equal(this.label, other.label)
                && Objects.equal(this.threadGroup, other.threadGroup) && Objects.equal(this.sampleType, other.sampleType)
                && Objects.equal(this.marker, other.marker);
    }

    @Override
    public String toString() {
        return toStringHelper(this).add("sampleType", sampleType).add("threadGroup", threadGroup).add("threadName", threadName).add("label", label)
                .add("marker", marker).add("responseCode", responseCode).add("sampleCount", sampleCount).add("errorCount", errorCount)
                .add("requestSize", requestSize).add("startTime", startTime).add("endTime", endTime).add("latency", latency).add("elapsedTime", elapsed)
                .toString();
    }
}