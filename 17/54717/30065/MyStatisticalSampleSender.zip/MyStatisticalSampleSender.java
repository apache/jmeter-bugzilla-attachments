package jmeter.samplers;

import static com.google.common.base.Objects.firstNonNull;
import static com.google.common.base.Objects.toStringHelper;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Strings.emptyToNull;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.jmeter.samplers.AbstractSampleSender;
import org.apache.jmeter.samplers.RemoteSampleListener;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.save.SaveService;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import com.google.common.base.Objects;
import com.google.common.collect.Lists;

public class MyStatisticalSampleSender extends AbstractSampleSender implements Serializable {

    private static final long serialVersionUID = 1167910624585715712L;

    private static final Logger log = LoggingManager.getLoggerForClass();

    private final RemoteSampleListener listener;

    private final List<SampleEvent> events;

    private transient ConcurrentHashMap<String, Map<StatisticalResult, StatisticalResult>> threadMap;

    /**
     * Constructor, only called by client code.
     * 
     * @param listener that the List of sample events will be sent to.
     */
    public MyStatisticalSampleSender(RemoteSampleListener listener) {
        this.listener = listener;
        this.events = Lists.newArrayList();
    }

    /**
     * @param event a Sample Event
     */
    @Override
    public void sampleOccurred(SampleEvent event) {
        // no synchronization necessary then using a map bound to the current thread
        StatisticalResult key = new StatisticalResult(event);
        StatisticalResult result = putIfAbsent(getStatisticalMapForThread(), key, key);
        result.update(event);
    }

    /**
     * Checks if any sample events are still present in the sampleStore and
     * sends them to the listener. Informs the listener of the testended.
     * 
     * @param host the hostname that the test has ended on.
     */
    @Override
    public void testEnded(String host) {
        final String threadName = Thread.currentThread().getName();
        log.info("Test Ended on host: " + host);
        try {
            for (Map<StatisticalResult, StatisticalResult> statisticalResultMap : getThreadMap().values()) {
                for (StatisticalResult statisticalResult : statisticalResultMap.values()) {
                    if (log.isDebugEnabled()) {
                        log.debug("# " + threadName + " - Add event for: " + statisticalResult);
                    }
                    events.add(createSampleEvent(statisticalResult));
                }
                statisticalResultMap.clear();
            }
            log.info("Process " + events.size() + " events");
            listener.processBatch(events);
            listener.testEnded(host);
        } catch (RemoteException err) {
            log.error("testEnded(hostname)", err);
        }
    }

    private Map<StatisticalResult, StatisticalResult> getStatisticalMapForThread() {
        final String threadName = Thread.currentThread().getName();
        Map<StatisticalResult, StatisticalResult> statisticalMap = getThreadMap().get(threadName);
        if (statisticalMap == null) {
            if (log.isDebugEnabled()) {
                log.debug("# " + threadName + " - Add map for thread");
            }
            final Map<StatisticalResult, StatisticalResult> value = new HashMap<StatisticalResult, StatisticalResult>();
            statisticalMap = getThreadMap().putIfAbsent(threadName, value);
            if (statisticalMap == null) {
                statisticalMap = value;
            }
        }
        return statisticalMap;
    }

    private static <K, V> V putIfAbsent(Map<K, V> map, K key, V value) {
        V originalValue = map.get(key);
        if (originalValue == null) {
            map.put(key, value);
            originalValue = value;
            if (log.isDebugEnabled()) {
                log.debug("# Add object to map: " + value);
            }
        }
        return originalValue;
    }

    static SampleEvent createSampleEvent(StatisticalResult statResult) {
        SampleResult sampleResult = new StatisticalSampleResult(statResult.startTime, statResult.elapsed);

        sampleResult.setThreadName(statResult.threadName);
        sampleResult.setSampleLabel(statResult.label);
        sampleResult.setSampleCount(statResult.sampleCount);
        sampleResult.setDataType(statResult.sampleType);
        sampleResult.setBytes(statResult.requestSize);
        sampleResult.setErrorCount(statResult.errorCount);
        sampleResult.setResponseCode(statResult.responseCode);
        sampleResult.setLatency(statResult.latency);
        sampleResult.setEndTime(statResult.endTime);

        return new SampleEvent(sampleResult, statResult.threadGroup);
    }

    private ConcurrentHashMap<String, Map<StatisticalResult, StatisticalResult>> getThreadMap() {
        if (threadMap == null) {
            synchronized (this) {
                ConcurrentHashMap<String, Map<StatisticalResult, StatisticalResult>> localMap = new ConcurrentHashMap<String, Map<StatisticalResult, StatisticalResult>>();
                // atomical
                threadMap = localMap;
            }
        }
        return threadMap;
    }

    /**
     * Processed by the RMI server code; acts as testStarted().
     * 
     * @throws ObjectStreamException
     */
    private Object readResolve() throws ObjectStreamException {
        log.info("Using " + getClass().getSimpleName() + " for this run.");
        return this;
    }

    static class StatisticalResult {

        final String threadGroup;

        final String threadName;

        final String label;

        final String responseCode;

        final String sampleType;

        int sampleCount = 0;

        int errorCount = 0;

        int requestSize = 0;

        long startTime = Long.MAX_VALUE; // guarantee it is set with the first update()

        long endTime = 0;

        long latency = 0;

        long elapsed = 0;

        /**
         * Create a statistical sample result.
         */
        StatisticalResult(SampleEvent event) {
            // using of intern string pool guarantees precalculated hashes and less memory usage
            checkNotNull(event);
            SampleResult result = checkNotNull(event.getResult());
            this.threadGroup = firstNonNull(emptyToNull(event.getThreadGroup()), "<unknown group>").intern();
            this.threadName = firstNonNull(emptyToNull(result.getThreadName()), "<unknown thread>").intern();
            this.label = firstNonNull(emptyToNull(result.getSampleLabel()), "<unknown label>").intern();
            this.responseCode = firstNonNull(emptyToNull(result.getResponseCode()), "<unknown response code>").intern();
            this.sampleType = SaveService.classToAlias(result.getClass().getName());
        }

        void update(SampleEvent event) {
            checkNotNull(event);
            SampleResult result = checkNotNull(event.getResult());
            if (!result.isSuccessful()) {
                errorCount++;
            }
            sampleCount += result.getSampleCount();
            requestSize += result.getBytes();
            startTime = Math.min(startTime, result.getStartTime());
            endTime = Math.max(endTime, result.getEndTime());
            latency += result.getLatency();
            elapsed += result.getTime();
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(responseCode, label, sampleType);
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == null || this.getClass() != obj.getClass()) {
                return false;
            }
            final StatisticalResult other = (StatisticalResult) obj;
            return Objects.equal(this.responseCode, other.responseCode) && Objects.equal(this.label, other.label)
                    && Objects.equal(this.sampleType, other.sampleType);
        }

        @Override
        public String toString() {
            return toStringHelper(this).add("sampleType", sampleType).add("threadGroup", threadGroup).add("threadName", threadName).add("label", label)
                    .add("responseCode", responseCode).add("sampleCount", sampleCount).add("errorCount", errorCount).add("requestSize", requestSize)
                    .add("startTime", startTime).add("endTime", endTime).add("latency", latency).add("elapsedTime", elapsed).toString();
        }
    }
}
