/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.control.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.protocol.java.sampler.TestNGSampler;
import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.gui.JLabeledTextField;
import org.apache.jorphan.util.JOrphanUtils;
import org.testng.annotations.Test;


/**
 * The <code>TestNGSamplerGui</code> class provides the user interface
 * for the {@link TestNGSampler}.
 * 
 */
public class TestNGSamplerGui extends AbstractSamplerGui 
implements ChangeListener, ActionListener
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger log = Logger.getLogger(TestNGSamplerGui.class.getName());

    /** The name of the classnameCombo JComboBox */
    private static final String CLASSNAMECOMBO = "classnamecombo"; //$NON-NLS-1$
    private static final String METHODCOMBO = "methodcombo"; //$NON-NLS-1$
    
    private static final String[] SPATHS = new String[] {
            JMeterUtils.getJMeterHome() + "/lib/testng/", //$NON-NLS-1$
    };

    private JLabel methodLabel =
        new JLabel(
            JMeterUtils.getResString("testng_test_method")); //$NON-NLS-1$

    private JLabeledTextField successMsg =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_success_msg")); //$NON-NLS-1$

    private JLabeledTextField failureMsg =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_failure_msg")); //$NON-NLS-1$
    
    private JLabeledTextField errorMsg =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_error_msg")); //$NON-NLS-1$

    private JLabeledTextField successCode =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_success_code")); //$NON-NLS-1$

    private JLabeledTextField failureCode =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_failure_code")); //$NON-NLS-1$

    private JLabeledTextField errorCode =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_error_code")); //$NON-NLS-1$

    private JLabeledTextField filterpkg =
        new JLabeledTextField(
            JMeterUtils.getResString("testng_pkg_filter")); //$NON-NLS-1$

    
    /** A combo box allowing the user to choose a test class. */
    private JComboBox classnameCombo;
    private JComboBox methodName;
    
    private transient ClassFilter classFilter = new ClassFilter();
    private List<String> methodList = null;
    private List<String> classList = null;
    private transient Class<?> testClass = null;
    
    
    
    /**
     * Constructor for TestNGSamplerGui
     */
    public TestNGSamplerGui()
    {
        super();
        init();
    }

    public String getLabelResource()
    {
        return "testng_request"; //$NON-NLS-1$
    }

    /**
     * Initialize the GUI components and layout.
     */
    private void init()
    {
        setLayout(new BorderLayout(0, 5));
        setBorder(makeBorder());
        
        add(makeTitlePanel(), BorderLayout.NORTH);


        add(createClassPanel(), BorderLayout.CENTER);
    }
    
    private JPanel createClassPanel()
    {
        methodList = new java.util.ArrayList<String>();

        try
        {
            classList =
                ClassFinder.findAnnotatedClasses(
                    SPATHS,
                    Test.class );
        }
        catch (IOException e)
        {
            log.log(Level.SEVERE, "Exception getting interfaces.", e);
        } 

        JLabel label =
            new JLabel(JMeterUtils.getResString("protocol_java_classname")); //$NON-NLS-1$

        classnameCombo = new JComboBox(classList.toArray());
        classnameCombo.addActionListener(this);
        classnameCombo.setName(CLASSNAMECOMBO);
        classnameCombo.setEditable(false);
        label.setLabelFor(classnameCombo);
        
        if (classFilter != null && classFilter.size() > 0) {
            methodName = new JComboBox(classFilter.filterClasses(methodList));
        } else {
            methodName = new JComboBox(methodList.toArray());
        }
        methodName.addActionListener(this);
        methodName.setName(METHODCOMBO);
        methodLabel.setLabelFor(methodName);
        
        VerticalPanel panel = new VerticalPanel();
        panel.add(filterpkg);
        panel.add(label);
        filterpkg.addChangeListener(this);

        if (classnameCombo != null){
            panel.add(classnameCombo);
        }
        panel.add(methodLabel);
        if (methodName != null){
            panel.add(methodName);
        }
        panel.add(successMsg);
        panel.add(successCode);
        panel.add(failureMsg);
        panel.add(failureCode);
        panel.add(errorMsg);
        panel.add(errorCode);
        return panel;
    }

    private void initGui(){ // TODO - unfinished?
     	filterpkg.setText(""); //$NON-NLS-1$
        successCode.setText(JMeterUtils.getResString("testng_success_default_code")); //$NON-NLS-1$
        successMsg.setText(JMeterUtils.getResString("testng_success_default_msg")); //$NON-NLS-1$
        failureCode.setText(JMeterUtils.getResString("testng_failure_default_code")); //$NON-NLS-1$
        failureMsg.setText(JMeterUtils.getResString("testng_failure_default_msg")); //$NON-NLS-1$
        errorMsg.setText(JMeterUtils.getResString("testng_error_default_msg")); //$NON-NLS-1$
        errorCode.setText(JMeterUtils.getResString("testng_error_default_code")); //$NON-NLS-1$
    }

    public void clearGui() {
//		super.clearGui();
		initGui();
	}
    
    /* Implements JMeterGuiComponent.createTestElement() */ 
    public TestElement createTestElement()
    {
        TestNGSampler sampler = new TestNGSampler();
        modifyTestElement(sampler);
        return sampler;
    }

    /* Implements JMeterGuiComponent.modifyTestElement(TestElement) */
    public void modifyTestElement(TestElement el)
    {
    	TestNGSampler sampler = (TestNGSampler)el;
        configureTestElement(sampler);
        if (classnameCombo.getSelectedItem() != null && 
                classnameCombo.getSelectedItem() instanceof String) {
            sampler.setClassname((String)classnameCombo.getSelectedItem());
        }
        if (methodName.getSelectedItem() != null) {
            Object mobj = methodName.getSelectedItem();
            sampler.setMethod((String)mobj);
        }
        sampler.setFilterString(filterpkg.getText());
        sampler.setSuccess(successMsg.getText());
        sampler.setSuccessCode(successCode.getText());
        sampler.setFailure(failureMsg.getText());
        sampler.setFailureCode(failureCode.getText());
    }

    /* Overrides AbstractJMeterGuiComponent.configure(TestElement) */
    public void configure(TestElement el)
    {
        super.configure(el);
        TestNGSampler sampler = (TestNGSampler)el;
        classnameCombo.setSelectedItem(sampler.getClassname());
        instantiateClass();
        methodName.setSelectedItem(sampler.getMethod());
        filterpkg.setText(sampler.getFilterString());
        if (sampler.getSuccessCode().length() > 0) {
            successCode.setText(sampler.getSuccessCode());
        } else {
            successCode.setText(JMeterUtils.getResString("testng_success_default_code")); //$NON-NLS-1$
        }
        if (sampler.getSuccess().length() > 0) {
            successMsg.setText(sampler.getSuccess());
        } else {
            successMsg.setText(JMeterUtils.getResString("testng_success_default_msg")); //$NON-NLS-1$
        }
        if (sampler.getFailureCode().length() > 0) {
            failureCode.setText(sampler.getFailureCode());
        } else {
            failureCode.setText(JMeterUtils.getResString("testng_failure_default_code")); //$NON-NLS-1$
        }
        if (sampler.getFailure().length() > 0) {
            failureMsg.setText(sampler.getFailure());
        } else {
            failureMsg.setText(JMeterUtils.getResString("testng_failure_default_msg")); //$NON-NLS-1$
        }
        if (sampler.getError().length() > 0) {
            errorMsg.setText(sampler.getError());
        } else {
            errorMsg.setText(JMeterUtils.getResString("testng_error_default_msg")); //$NON-NLS-1$
        }
        if (sampler.getErrorCode().length() > 0) {
            errorCode.setText(sampler.getErrorCode());
        } else {
            errorCode.setText(JMeterUtils.getResString("testng_error_default_code")); //$NON-NLS-1$
        }
    }
    
    public void instantiateClass(){
        String className =
            ((String) classnameCombo.getSelectedItem());
        if (className != null) {
            try {
				testClass = getClass().getClassLoader().loadClass(className);
			} catch (ClassNotFoundException e) {
				throw new RuntimeException(e);
			}
            if (testClass == null) {
                clearMethodCombo();
            }
            configureMethodCombo();
        }
    }

    public void showErrorDialog() {
        JOptionPane.showConfirmDialog(this, 
                JMeterUtils.getResString("testng_constructor_error"),  //$NON-NLS-1$
                "Warning",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.ERROR_MESSAGE);
    }
    
    public void configureMethodCombo(){
        if (testClass != null) {
            clearMethodCombo();
            log.info("the test class is " + testClass);
            String [] names = getMethodNames(getMethods(testClass));
            for (int idx=0; idx < names.length; idx++){
                methodName.addItem(names[idx]);
                methodList.add(names[idx]);
            }
            methodName.repaint();
        }
    }
    
    public void clearMethodCombo(){
    	log.info("clearing method combo");
        methodName.removeAllItems();
        methodList.clear();
    }
    
    public Method[] getMethods(Class<?> testClass)
    {
    	log.info("getting methods");

    	List<Method> methods = ClassFinder.getAnnotatedMethods(Test.class, testClass);
        if (methods.size() > 0){
            Method[] rmeth = new Method[methods.size()];
            return (Method[])methods.toArray(rmeth);
        }
		return new Method[0];
    }
    
    public String[] getMethodNames(Method[] meths)
    {
        String[] names = new String[meths.length];
        for (int idx=0; idx < meths.length; idx++){
            names[idx] = meths[idx].getName();
        }
        return names;
    }
    
    public Class<?>[] filterClasses(Class<?>[] clz) {
        if (clz != null && clz.length > 0){
            Class<?>[] nclz = null;
            return nclz;
        }
		return clz;
    }
  
    /**
     * Handle action events for this component.  This method currently handles
     * events for the classname combo box.
     * 
     * @param evt  the ActionEvent to be handled
     */
    public void actionPerformed(ActionEvent evt)
    {
        if (evt.getSource() == classnameCombo)
        {
            instantiateClass();
        }
    }
    
    /**
     * the current implementation checks to see if the source
     * of the event is the filterpkg field.
     */
    public void stateChanged(ChangeEvent event) {
        if ( event.getSource() == filterpkg) {
            classFilter.setPackages(JOrphanUtils.split(filterpkg.getText(),",")); //$NON-NLS-1$
            classnameCombo.removeAllItems();
            // change the classname drop down
            Object[] clist = classFilter.filterClasses(classList);
            for (int idx=0; idx < clist.length; idx++) {
                classnameCombo.addItem(clist[idx]);
            }
        }
    }
}

