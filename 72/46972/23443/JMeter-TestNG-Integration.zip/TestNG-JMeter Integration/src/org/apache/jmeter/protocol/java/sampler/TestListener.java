/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.sampler;

import org.apache.jmeter.samplers.SampleResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

/**
 * Monitors the progress of a TestNG test and updates 
 * its status in a JMeter SampleResult instance.

 * @author Tom Cellucci
 *
 */
public class TestListener extends TestListenerAdapter {
	
	private SampleResult sampleResult;
	
	public TestListener(SampleResult sampleResult) {
		this.sampleResult = sampleResult;
	}	
	
	@Override
	public void onTestFailure(ITestResult tr) {
		sampleResult.sampleEnd();
		sampleResult.setSuccessful(false);
		super.onTestFailure(tr);
	}

	@Override
	public void onTestStart(ITestResult result) {
		super.onTestStart(result);
		sampleResult.sampleStart();				
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		sampleResult.sampleEnd();
		sampleResult.setSuccessful(true);
		super.onTestSuccess(tr);
	}

	@Override
	public void onConfigurationFailure(ITestResult itr) {
		itr.getThrowable().printStackTrace();				
		TestNGSampler testNGSampler = TestNGSampler.getInstance();
		sampleResult.setResponseCode(testNGSampler.getErrorCode());
		sampleResult.setResponseMessage(testNGSampler.getError());
		sampleResult.setResponseData(itr.getThrowable().getMessage().getBytes());
		sampleResult.setSuccessful(false);
		sampleResult.setStopTest(true);				
		super.onConfigurationFailure(itr);
	}

	@Override
	public void onStart(ITestContext testContext) {
		TestNGSampler testNGSampler = TestNGSampler.getInstance();
		testContext.setAttribute("thread-id", testNGSampler.getThreadContext().getThreadNum());
		testContext.setAttribute("thread-count", testNGSampler.getThreadContext().getThreadGroup().getNumThreads());
		testContext.setAttribute("total-iterations", testNGSampler.getState().getTotalIterations());
		super.onStart(testContext);
	}

}
