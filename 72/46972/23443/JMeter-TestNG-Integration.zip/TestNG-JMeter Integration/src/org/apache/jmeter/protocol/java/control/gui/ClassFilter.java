/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.control.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * @author pete
 *
 */
public class ClassFilter {

    protected List<String> includedPackages = new LinkedList<String>();
	/**
	 * 
	 */
	public ClassFilter() {
		super();
	}
    
    public void setPackages(String[] pkg) {
        includedPackages.addAll(Arrays.asList(pkg));
    }
    
    public void addPackage(String pkg) {
        includedPackages.add(pkg);
    }
    
    protected boolean isIncluded(String className) {
        boolean rv = false;
        for (String packageName : includedPackages) {
            if (className.startsWith(packageName)){
                rv = true;
                break;
            }
        }
        return rv;
    }
    
    public String[] filterClasses(List<String> classNames) {
        List<String> filteredClassNames = new ArrayList<String>(classNames.size());
        for (String className : classNames) {
            if (isIncluded(className)) {
            	filteredClassNames.add(className);
            }
        }
        
        String[] rv = null;
        if (!filteredClassNames.isEmpty()) {
            rv = filteredClassNames.toArray(new String[filteredClassNames.size()]);
        } else {
            rv = new String[0];
        }
        return rv;
    }

    public int size(){
        return includedPackages.size();
    }
}
