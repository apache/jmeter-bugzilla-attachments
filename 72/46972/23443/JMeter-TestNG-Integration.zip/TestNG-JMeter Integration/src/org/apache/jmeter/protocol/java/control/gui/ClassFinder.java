/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.control.gui;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.apache.jorphan.util.JOrphanUtils;

/**
 * This class finds classes that extend one of a set of parent classes
 * 
 * @author Burt Beckwith
 * @author Michael Stover (mstover1 at apache.org)
 * @author Tom Cellucci (added annotations code)
 */
public final class ClassFinder {
	private static final Logger log = Logger.getLogger(ClassFinder.class
			.getName());

	private static final String DOT_JAR = ".jar"; // $NON-NLS-1$
	private static final String DOT_CLASS = ".class"; // $NON-NLS-1$
	private static final int DOT_CLASS_LEN = DOT_CLASS.length();

	// static only
	private ClassFinder() {
	}



	/**
	 * Convenience method for
	 * <code>findClassesThatExtend(Class[], boolean)</code> with the option to
	 * include inner classes in the search set to false.
	 * 
	 * @return List containing discovered classes.
	 */
	public static List<String> findAnnotatedClasses(String[] paths,
			Class<? extends Annotation> annotation) throws IOException {
		return findAnnotatedClasses(paths, annotation, false);
	}

	// For each directory in the search path, add all the jars found there
	private static String[] addJarsInPath(String[] paths) {
		Set<String> fullList = new HashSet<String>();
		for (int i = 0; i < paths.length; i++) {
			final String path = paths[i];
			fullList.add(path); // Keep the unexpanded path
			// TODO - allow directories to end with .jar by removing this check?
			if (!path.endsWith(DOT_JAR)) {
				File dir = new File(path);
				if (dir.exists() && dir.isDirectory()) {
					String[] jars = dir.list(new FilenameFilter() {
						public boolean accept(File f, String name) {
							return name.endsWith(DOT_JAR);
						}
					});
					for (int x = 0; x < jars.length; x++) {
						fullList.add(jars[x]);
					}
				}
			}
		}
		return (String[]) fullList.toArray(new String[0]);
	}

	/**
	 * Find classes in the provided path(s)/jar(s) that extend the class(es).
	 * 
	 * @param strPathsOrJars -
	 *            pathnames or jarfiles to search for classes
	 * @param superClasses -
	 *            required parent class(es)
	 * @param innerClasses -
	 *            should we include inner classes?
	 * 
	 * @return List containing discovered classes
	 */
	public static List<String> findAnnotatedClasses(String[] strPathsOrJars,
			final Class<? extends Annotation> annotation, final boolean innerClasses)
			throws IOException {

		// Find all jars in the search path
		strPathsOrJars = addJarsInPath(strPathsOrJars);
		for (int k = 0; k < strPathsOrJars.length; k++) {
			strPathsOrJars[k] = fixPathEntry(strPathsOrJars[k]);
			if (log.isLoggable(Level.INFO)) {
				log.info("strPathsOrJars : " + strPathsOrJars[k]);
			}
		}

		// Now eliminate any classpath entries that do not "match" the search
		List<String> listPaths = getClasspathMatches(strPathsOrJars);
		if (log.isLoggable(Level.INFO)) {
			Iterator<String> tIter = listPaths.iterator();
			while (tIter.hasNext()) {
				log.info("listPaths : " + tIter.next());
			}
		}

		Set<String> listClasses = new TreeSet<String>();
		// first get all the classes
		findClassesInPaths(listPaths, listClasses);
		if (log.isLoggable(Level.FINE)) {
			log.fine("listClasses.size()=" + listClasses.size());
			Iterator<String> tIter = listClasses.iterator();
			while (tIter.hasNext()) {
				log.fine("listClasses : " + tIter.next());
			}
		}

		return new ArrayList<String>(listClasses);// subClassList);
	}

	/*
	 * Returns the classpath entries that match the search list of jars and
	 * paths
	 */
	private static List<String> getClasspathMatches(String[] strPathsOrJars) {
		log.fine("Classpath = " + System.getProperty("java.class.path")); // $NON-NLS-1$
		StringTokenizer stPaths = new StringTokenizer(System
				.getProperty("java.class.path"), // $NON-NLS-1$
				System.getProperty("path.separator")); // $NON-NLS-1$
		if (log.isLoggable(Level.FINE)) {
			for (int i = 0; i < strPathsOrJars.length; i++) {
				log.fine("strPathsOrJars[" + i + "] : " + strPathsOrJars[i]);
			}
		}

		// find all jar files or paths that end with strPathOrJar
		ArrayList<String> listPaths = new ArrayList<String>();
		String strPath = null;
		while (stPaths.hasMoreTokens()) {
			strPath = fixPathEntry(stPaths.nextToken());
			if (strPathsOrJars == null) {
				log.fine("Adding: " + strPath);
				listPaths.add(strPath);
			} else {
				boolean found = false;
				for (int i = 0; i < strPathsOrJars.length; i++) {
					if (strPath.endsWith(strPathsOrJars[i])) {
						found = true;
						log.fine("Adding " + strPath + " found at " + i);
						listPaths.add(strPath);
						break;// no need to look further
					}
				}
				if (!found) {
					log.fine("Did not find: " + strPath);
				}
			}
		}
		return listPaths;
	}

	/**
	 * Fix a path: - replace "." by current directory - trim any trailing spaces -
	 * replace \ by / - replace // by / - remove all trailing /
	 */
	private static String fixPathEntry(String path) {
		if (path == null)
			return null;
		if (path.equals(".")) { // $NON-NLS-1$
			return System.getProperty("user.dir"); // $NON-NLS-1$
		}
		path = path.trim().replace('\\', '/'); // $NON-NLS-1$ // $NON-NLS-2$
		path = JOrphanUtils.substitute(path, "//", "/"); // $NON-NLS-1$//
		// $NON-NLS-2$

		while (path.endsWith("/")) { // $NON-NLS-1$
			path = path.substring(0, path.length() - 1);
		}
		return path;
	}

	
	public static List<Method> getAnnotatedMethods(Class<? extends Annotation> annotation, Class<?> c) {
		List<Method> methodNames = new ArrayList<Method>();
		log.info("getting methods annotated by " + annotation + " for " + c.getSimpleName());
		// might throw an exception, assume this is ignorable
		try {
			if (!c.isInterface() && !Modifier.isAbstract(c.getModifiers())) {

				for (Method m : c.getDeclaredMethods()) {
					log.info("checking method " + m.getName());
					m.setAccessible(true);
					if (m.isAnnotationPresent(annotation)) {
						methodNames.add(m);
					}
				}

			}
		} catch (Throwable ignored) {
			log.fine(ignored.getLocalizedMessage());
		}
		log.info("returning " + methodNames.toString());
		return methodNames;
	}	



	/*
	 * Converts a class file from the text stored in a Jar file to a version
	 * that can be used in Class.forName().
	 * 
	 * @param strClassName the class name from a Jar file @return String the
	 * Java-style dotted version of the name
	 */
	private static String fixClassName(String strClassName) {
		strClassName = strClassName.replace('\\', '.'); // $NON-NLS-1$ //
		// $NON-NLS-2$
		strClassName = strClassName.replace('/', '.'); // $NON-NLS-1$ //
		// $NON-NLS-2$
		// remove ".class"
		strClassName = strClassName.substring(0, strClassName.length()
				- DOT_CLASS_LEN);
		return strClassName;
	}

	private static void findClassesInOnePath(String strPath, Set<String> listClasses)
			throws IOException {
		File file = new File(strPath);
		if (file.isDirectory()) {
			findClassesInPathsDir(strPath, file, listClasses);
		} else if (file.exists()) {
			ZipFile zipFile = new ZipFile(file);
			Enumeration<? extends ZipEntry> entries = zipFile.entries();
			while (entries.hasMoreElements()) {
				String strEntry = entries.nextElement().toString();
				if (strEntry.endsWith(DOT_CLASS)) {
					listClasses.add(fixClassName(strEntry));
				}
			}
		}
	}

	private static void findClassesInPaths(List<String> listPaths, Set<String> listClasses)
			throws IOException {
		Iterator<String> iterPaths = listPaths.iterator();
		while (iterPaths.hasNext()) {
			findClassesInOnePath(iterPaths.next(), listClasses);
		}
	}

	private static void findClassesInPathsDir(String strPathElement, File dir,
			Set<String> listClasses) throws IOException {
		String[] list = dir.list();
		for (int i = 0; i < list.length; i++) {
			File file = new File(dir, list[i]);
			if (file.isDirectory()) {
				// Recursive call
				findClassesInPathsDir(strPathElement, file, listClasses);
			} else if (list[i].endsWith(DOT_CLASS) && file.exists()
					&& (file.length() != 0)) {
				final String path = file.getPath();
				listClasses.add(path.substring(strPathElement.length() + 1,
						path.lastIndexOf(".")) // $NON-NLS-1$
						.replace(File.separator.charAt(0), '.')); // $NON-NLS-1$
			}
		}
	}
}