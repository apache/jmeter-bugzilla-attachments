/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.sampler;

import java.util.List;

import org.testng.IMethodSelector;
import org.testng.IMethodSelectorContext;
import org.testng.ITestNGMethod;

/** 
 * TestMethodSelector modifies the TestNG lifecycle for
 * compatibility with JMeter.  In particular we are interested
 * to limit the beforeTest/beforeClass/beforeSuite and 
 * afterTest/afterClass/afterSuite methods to fire only once 
 * per thread.
 * 
 * @author Tom Cellucci
 *
 */
public class TestMethodSelector implements IMethodSelector {
	private static final long serialVersionUID = 1L;

	/**
	 * goal here is to make sure we run the beforeTest/beforeClass/beforeSuite
	 * and afterTest/afterClass/afterSuite methods only once per thread
	 */
	@Override
	public boolean includeMethod(IMethodSelectorContext context,
			ITestNGMethod method, boolean isTestMethod) {
		// setting the context to 'stopped' means that no other method
		// selectors should be consulted (we can handle all outcomes here).
		context.setStopped(true);

		boolean rv = isTestMethod; // default: allow invocation of any test
									// method
		if (!rv) {
			// the method is considered a TestNG configuration method
			TestNGSamplerState sampler = TestNGSampler.getInstance().getState();
			if (sampler.isFirstTestInvocation()) {
				/*
				 * allow beforeTest/beforeClass/beforeSuite calls if this is the
				 * first invocation of the test
				 */
				if (method.isBeforeClassConfiguration()
						|| method.isBeforeTestConfiguration()
						|| method.isBeforeSuiteConfiguration()) {
					rv = true;
				}
			} else if (sampler.isLastTestInvocation()) {
				/*
				 * allow afterTest/afterClass/afterSuite calls if this is the
				 * last invocation of the test
				 */
				if (method.isAfterClassConfiguration()
						|| method.isAfterTestConfiguration()
						|| method.isAfterSuiteConfiguration()) {
					rv = true;
				}
			}
			/*
			 * allow all beforeGroup/beforeMethod/afterGroup/afterMethod calls
			 */
			if (method.isBeforeGroupsConfiguration()
					|| method.isBeforeMethodConfiguration()
					|| method.isAfterGroupsConfiguration()
					|| method.isAfterMethodConfiguration()) {
				rv = true;
			}
		}
		return rv;

	}

	/**
	 * a chance to alter the final list of test methods; i.e., order no need for
	 * this plugin
	 */
	@Override
	public void setTestMethods(List<ITestNGMethod> testMethods) {
	}

}
