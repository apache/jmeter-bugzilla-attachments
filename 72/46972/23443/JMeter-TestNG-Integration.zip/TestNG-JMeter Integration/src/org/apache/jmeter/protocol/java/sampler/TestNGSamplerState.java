/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.sampler;

/**
 * Contains the per-thread state of an executing TestNGSampler
 * 
 * @author Tom Cellucci
 * 
 */
class TestNGSamplerState {
	private int iteration;
	private int totalIterations;
	private Object testInstance;

	public TestNGSamplerState(Object testInstance) {
		this.testInstance = testInstance;
	}

	public int getIteration() {
		return iteration;
	}

	public void setIteration(int iteration) {
		this.iteration = iteration;
	}

	public int getTotalIterations() {
		return totalIterations;
	}

	/**
	 * indicates whether this is the first execution of the TestNG test for the
	 * current thread
	 * 
	 * @return true if this is the first execution, false otherwise
	 */
	protected boolean isFirstTestInvocation() {
		return getIteration() == 1;
	}

	/**
	 * indicates whether this is the last execution of the TestNG test for the
	 * current thread
	 * 
	 * @return true if this is the last execution, false otherwise
	 */
	protected boolean isLastTestInvocation() {
		return getIteration() == getTotalIterations();
	}

	public void setTotalIterations(int totalIterations) {
		this.totalIterations = totalIterations;
	}

	/**
	 * Object to be tested by TestNG framework. This instance presumedly has
	 * TestNG annotations that indicate which methods are tests, configuration,
	 * etc.
	 * 
	 * @return the test instance
	 */
	public Object getTestInstance() {
		return testInstance;
	}

	public void setTestInstance(Object testInstance) {
		this.testInstance = testInstance;
	}
}