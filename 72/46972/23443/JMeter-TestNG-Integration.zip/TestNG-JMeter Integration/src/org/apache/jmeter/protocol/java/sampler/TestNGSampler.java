/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */
package org.apache.jmeter.protocol.java.sampler;

import java.util.Arrays;
import java.util.logging.Logger;

import org.apache.jmeter.control.LoopController;
import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.threads.JMeterContextService;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

/**
 * TestNGSampler provides integration between JMeter and
 * the TestNG unit testing framework.
 * 
 * @author Tom Cellucci
 *
 */
public class TestNGSampler extends AbstractSampler implements org.apache.jmeter.testelement.TestListener {
	private static final Logger log = Logger.getLogger(TestNGSampler.class.getName());
	private static final long serialVersionUID = 1L;
	public static final String BASE = TestNGSampler.class.getSimpleName();
	public static final String CLASSNAME = BASE + ".classname";
	public static final String ERROR = BASE + ".error";
	public static final String ERRORCODE = BASE + ".error.code";
	public static final String METHOD = BASE + ".method";
	public static final String FAILURE = BASE + ".failure";
	public static final String FAILURECODE = BASE + ".failure.code";
	public static final String SUCCESS = BASE + ".success";
	public static final String SUCCESSCODE = BASE + ".success.code";
	public static final String FILTER = BASE + ".pkg.filter";
	
	private ThreadLocal<TestNGSamplerState> stateHolder = new ThreadLocal<TestNGSamplerState>();
	
	@Override
	public SampleResult sample(Entry e) {
		TestNGSamplerState state = getState();

		log.fine("Iteration # " + state.getIteration() + " for thread " + getThreadContext().getThreadNum());
		ClassLoader cl = Thread.currentThread().getContextClassLoader();
		if (cl == null) {
			cl = getClass().getClassLoader();
		}
		
		final SampleResult sampleResult = new SampleResult();
		
		TestNG testRunner = getTestRunner();
		testRunner.addListener(new TestListener(sampleResult));
		
		try {
			testRunner.run();			
		}
		catch (Exception x) {
			// update the sample with this failure
			sampleResult.setResponseCode(getErrorCode());
			sampleResult.setResponseMessage(getError());
			sampleResult.setResponseData(x.getMessage().getBytes());
			sampleResult.setSuccessful(false);
			sampleResult.setStopTest(true);				
		}
		finally {
			testRunner.getTestListeners().clear();
		}

		return sampleResult;
	}

	/**
	 * a holder for test state (i.e., test instance, iteration number) kept in thread-local scope.
	 * @return
	 */
	protected TestNGSamplerState getState() {
		TestNGSamplerState state = stateHolder.get();
		if (state == null) {
			try {
				Class<?> testClass = Thread.currentThread()
						.getContextClassLoader().loadClass(
								getClassname());
				state = new TestNGSamplerState(testClass.newInstance());
				stateHolder.set(state);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return state;
	}	

	/**
	 * creates a new TestNG instance and configures it to execute 
	 * the class and method configured for this Sampler.
	 * @return the TestNG instance
	 */
	private TestNG getTestRunner() {
		TestNG testng = new TestNG(false);

		XmlSuite xmlSuite = new XmlSuite();
		xmlSuite.setName(getName());
		XmlTest test = new XmlTest(xmlSuite);
		
		org.testng.xml.XmlMethodSelector methodSelector = new org.testng.xml.XmlMethodSelector();
		methodSelector.setName(TestMethodSelector.class.getName());
		test.setMethodSelectors(Arrays.asList(methodSelector));
		
		XmlClass testClass = new XmlClass(TestFactory.class.getName());
		if (getMethod() != null) {
			testClass.setIncludedMethods(Arrays.asList( getMethod() ));
		}
		test.setXmlClasses(Arrays.asList(testClass));
		testng.setXmlSuites(Arrays.asList(xmlSuite));
		return testng;
	}
	
	/**
	 * Sets the Classname attribute of the JavaConfig object
	 * 
	 * @param classname
	 *            the new Classname value
	 */
	public void setClassname(String classname) {
		setProperty(CLASSNAME, classname);
	}

	/**
	 * Gets the Classname attribute of the JavaConfig object
	 * 
	 * @return the Classname value
	 */
	public String getClassname() {
		return getPropertyAsString(CLASSNAME);
	}

	/**
	 * return the descriptive error for the test
	 */
	public String getError() {
		return getPropertyAsString(ERROR);
	}

	/**
	 * provide a descriptive error for the test method.
	 * 
	 * @param error
	 */
	public void setError(String error) {
		setProperty(ERROR, error);
	}

	/**
	 * return the error code for the test method. it should be an unique error
	 * code.
	 */
	public String getErrorCode() {
		return getPropertyAsString(ERRORCODE);
	}

	/**
	 * provide an unique error code for when the test does not pass the assert
	 * test.
	 * 
	 * @param code
	 */
	public void setErrorCode(String code) {
		setProperty(ERRORCODE, code);
	}

	/**
	 * Return the name of the method to test
	 */
	public String getMethod() {
		return getPropertyAsString(METHOD);
	}

	/**	 * 
	 * @param methodName
	 */
	public void setMethod(String methodName) {
		setProperty(METHOD, methodName);
	}

	/**
	 * get the failure message
	 */
	public String getFailure() {
		return getPropertyAsString(FAILURE);
	}

	/**
	 * set the failure message
	 * 
	 * @param fail
	 */
	public void setFailure(String fail) {
		setProperty(FAILURE, fail);
	}

	/**
	 * The failure code is used by other components
	 */
	public String getFailureCode() {
		return getPropertyAsString(FAILURECODE);
	}

	/**
	 * Provide some unique code to denote a type of failure
	 * 
	 * @param code
	 */
	public void setFailureCode(String code) {
		setProperty(FAILURECODE, code);
	}

	/**
	 * return the comma separated string for the filter
	 */
	public String getFilterString() {
		return getPropertyAsString(FILTER);
	}

	/**
	 * set the filter string in comma-separated format
	 * 
	 * @param text
	 */
	public void setFilterString(String text) {
		setProperty(FILTER, text);
	}

	/**
	 * get the success message
	 */
	public String getSuccess() {
		return getPropertyAsString(SUCCESS);
	}

	/**
	 * set the success message
	 * 
	 * @param success
	 */
	public void setSuccess(String success) {
		setProperty(SUCCESS, success);
	}

	/**
	 * get the success code defined by the user
	 */
	public String getSuccessCode() {
		return getPropertyAsString(SUCCESSCODE);
	}

	/**
	 * set the success code. the success code should be unique.
	 * 
	 * @param code
	 */
	public void setSuccessCode(String code) {
		setProperty(SUCCESSCODE, code);
	}

	@Override
	public void testEnded() {
	}

	@Override
	public void testEnded(String host) {
	}

	@Override
	public void testIterationStart(LoopIterationEvent event) {
		TestNGSamplerState state = getState();
		state.setIteration(event.getIteration());
		if (state.getIteration() == 1) {
			try {
				LoopController loopController =  (LoopController)super.getThreadContext().getThreadGroup().getSamplerController();
				state.setTotalIterations(loopController.getLoops());
			} catch (RuntimeException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void testStarted() {
	}

	@Override
	public void testStarted(String host) {
	}

	/**
	 * Obtains the TestNG Sample from the JMeterContextService.  The current sampler is 
	 * known to be an instance of TestNGSampler.
	 * @return the current TestNGSampler instance
	 */
	public static TestNGSampler getInstance() {
		return (TestNGSampler) JMeterContextService.getContext().getCurrentSampler();
	}
}
