package org.apache.jmeter.protocol.webmethods.sampler.gui;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/webmethods/org/apache/jmeter/protocol/webmethods/sampler/gui/ServiceFileChooserGui,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.gui.util.FileDialoger;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.BooleanProperty;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * Provides the ability to browse for XML test data and display to the user
 * @author conorcurlett
 *
 */
public class ServiceFileChooserGui extends JPanel implements ActionListener{
	transient private static Logger log = LoggingManager.getLoggerForClass();

	public final static String XML_INPUT = "xmlInput";
	
	private JTextField xmlInput;
	private JButton loadButton;
	private JTextArea fileContents;
	
	public ServiceFileChooserGui(){
		init();
	}
	
	private void init() {
		this.setLayout(new BorderLayout());
		xmlInput = new JTextField(20);
		xmlInput.setName("XMLInput");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_service_xmldata"));
		label.setLabelFor(xmlInput);
		loadButton = new JButton(JMeterUtils.getResString("load"));
		loadButton.setMnemonic('L');
		loadButton.setActionCommand("Load");
		loadButton.setEnabled(true);
		loadButton.addActionListener(this);
		
		fileContents = new JTextArea(10, 10);
		fileContents.setEditable(false);
		
		JPanel panel = new JPanel(new FlowLayout());
		panel.add(label);
		panel.add(xmlInput);
		panel.add(loadButton);
		JPanel fileContentsPanel = new JPanel(new BorderLayout());
		fileContentsPanel.add(fileContents, BorderLayout.CENTER);
		fileContentsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_service_file_contents")));
		this.add(panel, BorderLayout.NORTH);
		this.add(fileContentsPanel, BorderLayout.CENTER);
	}

	public TestElement createTestElement(){
		WebMethodsServiceSampler element = new WebMethodsServiceSampler();
		element.setProperty(WebMethodsServiceSampler.XML_INPUT, xmlInput.getText());
		return element;
	}
	
	protected void configure(TestElement element) {
		setName(element.getPropertyAsString(TestElement.NAME));
		String inputPath = element.getPropertyAsString(WebMethodsServiceSampler.XML_INPUT);
		xmlInput.setText(inputPath);
		fileContents.setText(getFileContents(inputPath));
	}
	
	protected void modifyTestElement(TestElement el){
		el.setProperty(WebMethodsServiceSampler.XML_INPUT, xmlInput.getText());
	}

	public String getLabelResource() {
		return "webmethods_xml_file_chooser";
	}

	
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();

		if (action.equalsIgnoreCase("Load")) {
			JFileChooser chooser = FileDialoger.promptToOpenFile();
			if (chooser == null) {
				return;
			}
			File file = chooser.getSelectedFile();

			if (file != null) {
				xmlInput.setText(file.getPath());
				fileContents.setText(getFileContents(file.getPath()));
			}
		}
	}

	private String getFileContents(String fileName){
		StringBuffer buf = new StringBuffer();
		try{
			Reader reader = new InputStreamReader(new FileInputStream(fileName));
			char[] charBuffer = new char[8192];
			int charsRead = 0;
			while((charsRead = reader.read(charBuffer)) != -1) {
				buf.append(charBuffer, 0, charsRead);
			}
			reader.close();
		} catch (Exception exc) {
			log.debug("An error occured loading the test data file " + fileName + ".  Details: " + exc.getMessage() );
		} finally {
			return buf.toString();
		}
	}
	
	
	public void clear() {
		xmlInput.setText("");
	}
	
}
