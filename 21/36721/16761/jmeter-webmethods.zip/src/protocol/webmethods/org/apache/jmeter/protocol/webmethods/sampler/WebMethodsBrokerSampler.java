package org.apache.jmeter.protocol.webmethods.sampler;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.digester.Digester;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.webmethods.sampler.javabeans.Input;
import org.apache.jmeter.protocol.webmethods.sampler.javabeans.WebMethodsTestData;
import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.xml.sax.SAXException;

import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;

import COM.activesw.api.client.BrokerClient;
import COM.activesw.api.client.BrokerDate;
import COM.activesw.api.client.BrokerEvent;
import COM.activesw.api.client.BrokerException;
import COM.activesw.api.client.BrokerTypeDef;

/**
 * Sampler to sample publishing to a webMethods Broker
 * based on XML test data.
 * @author conorcurlett
 *
 */
public class WebMethodsBrokerSampler extends AbstractSampler {

	private static transient Logger log = LoggingManager.getLoggerForClass();
	
	public final static String BROKER_HOST = "WebMethodsBrokerSampler.brokerHost";
	public final static String BROKER_PORT = "WebMethodsBrokerSampler.brokerPort";
	public final static String BROKER_NAME = "WebMethodsBrokerSampler.brokerName";
	public final static String CLIENT_GROUP = "WebMethodsBrokerSampler.clientGroup";
	public final static String EVENT_NAME = "WebMethodsBrokerSampler.eventName";
	public final static String FILE_INPUT = "WebMethodsBrokerSampler.fileInput";
	public final static String INTERACTION = "WebMethodsBrokerSampler.interaction";
	public final static String SUB_EVENT_NAME = "WebMethodsBrokerSampler.subEventName";
	
	/**
	 * Property key representing the arguments for the JavaSamplerClient.
	 */
	public static final String ARGUMENTS = "arguments";

	
	public WebMethodsBrokerSampler(){
	}
	
	public String getBrokerHost(){
		return this.getPropertyAsString(BROKER_HOST);
	}
	public void setBrokerHost(String brokerHost){
		this.setProperty(BROKER_HOST, brokerHost);
	}
	public String getBrokerPort(){
		return this.getPropertyAsString(BROKER_PORT);
	}
	public void setBrokerPort(String brokerPort){
		this.setProperty(BROKER_PORT, brokerPort);
	}
	public String getBrokerName(){
		return this.getPropertyAsString(BROKER_NAME);
	}
	public void setBrokerName(String brokerName){
		this.setProperty(BROKER_NAME, brokerName);
	}
	public String getClientGroup(){
		return this.getPropertyAsString(CLIENT_GROUP);
	}
	public void setClientGroup(String clientGroup){
		this.setProperty(CLIENT_GROUP, clientGroup);
	}
	public String getEventName(){
		return this.getPropertyAsString(EVENT_NAME);
	}
	public void setEventName(String eventName){
		this.setProperty(EVENT_NAME, eventName);
	}
	public String getSubEventName(){
		return this.getPropertyAsString(SUB_EVENT_NAME);
	}
	public void setSubEventName(String subEventName){
		this.setProperty(SUB_EVENT_NAME, subEventName);
	}
	public String getFileInput(){
		return this.getPropertyAsString(FILE_INPUT);
	}
	public void setFileInput(String fileInput){
		this.setProperty(FILE_INPUT, fileInput);
	}
	public String getInteraction(){
		return this.getPropertyAsString(INTERACTION);
	}
	public void setInteraction(String interaction){
		this.setProperty(INTERACTION, interaction);
	}
	/**
	 * Set the arguments (parameters) for the Sampler to be executed
	 * with.
	 * 
	 * @param args
	 *            the new arguments. These replace any existing arguments.
	 */
	public void setArguments(Arguments args) {
		setProperty(new TestElementProperty(ARGUMENTS, args));
	}

	/**
	 * Get the arguments (parameters) for the Sampler to be executed
	 * with.
	 * 
	 * @return the arguments
	 */
	public Arguments getArguments() {
		return (Arguments) getProperty(ARGUMENTS).getObjectValue();
	}	
	/**
	 * "Sample" the webMethods Broker.
	 * 
	 */
	public SampleResult sample(Entry e) {
		SampleResult result = new SampleResult();
		result.setSampleLabel(getName());
		result.setSamplerData(getFileInput());
		
		result.sampleStart();
		
		if (getInteraction().equalsIgnoreCase(JMeterUtils.getResString("webmethods_broker_publish_button"))){
			// publish the event
			publish(result);
		} else if (getInteraction().equalsIgnoreCase(JMeterUtils.getResString("webmethods_broker_subscribe_button"))){
			// subscribe to an event
			subscribe(result);
		} else if (getInteraction().equalsIgnoreCase(JMeterUtils.getResString("webmethods_broker_requestreply_button"))){
			// perform a request/reply
			requestReply(result);
		}
	    result.setDataType(SampleResult.TEXT);
		result.sampleEnd();
		return result;
	}
	
	/**
	 * publish a BrokerEvent based on given parameters.
	 * @param result The SampleResult for the publish
	 */
	private void publish(SampleResult result){
		BrokerClient brokerClient;
		BrokerEvent brokerEvent;
	    /* Create a client */
	    try {
	        brokerClient = new BrokerClient(this.getBrokerHost() + ":" + this.getBrokerPort(), this.getBrokerName(), null,
	                             this.getClientGroup(), "JMeter Automated Testing Sampler", null);
	        brokerEvent = new BrokerEvent(brokerClient, this.getEventName());
	        // check client group permission to publish
	        boolean canPublish = brokerClient.canPublish(this.getEventName());
	        if (canPublish){
	        		brokerEvent = initialiseBrokerEvent(brokerEvent);
	        		log.debug("publishing " + brokerEvent.toString());
	        		brokerClient.publish(brokerEvent);    
		        result.setSuccessful(true);
		        String responseString = "Published Successfully";
		        result.setResponseData(responseString.getBytes());
	        } else {
	        		result.setResponseMessage("Not allowed to publish, check permissions");
	        		result.setSuccessful(false);
	        }
	        brokerClient.destroy();
	    } catch (BrokerException ex) {
	        log.error("Error occurred publishing:\n"+ex);
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);
	    } catch (IOException ex){
	    		log.error("Unable to read test data:\n"+ex);
	    		result.setResponseMessage(ex.getLocalizedMessage());
	    		result.setSuccessful(false);
	    } catch (SAXException ex){
		    	log.error("Unable to parse test xml:\n"+ex);
	    		result.setResponseMessage(ex.getLocalizedMessage());
	    		result.setSuccessful(false);
	    }
	}

	/**
	 * subscribe to a BrokerEvent based on the parameters given
	 * @param result The SampleResult containing the returned BrokerEvent
	 */
	private void subscribe(SampleResult result){
		BrokerClient brokerClient;
		BrokerEvent brokerEvent;
	    /* Create a client */
	    try {
	        brokerClient = new BrokerClient(this.getBrokerHost() + ":" + this.getBrokerPort(), this.getBrokerName(), null,
	                             this.getClientGroup(), "JMeter Automated Testing Sampler", null);
	        brokerEvent = new BrokerEvent(brokerClient, this.getSubEventName());
	        // check the client group's permissions
	        boolean canSubscribe = brokerClient.canSubscribe(this.getSubEventName());
	        if (canSubscribe){
	        		brokerClient.newSubscription(this.getSubEventName(), null);
	        		// get the event
	        		// TBD: Possibly add timeout functionality
	        		brokerEvent= brokerClient.getEvent(-1);
	        		result.setSuccessful(true);
		        result.setResponseData(brokerEvent.toString().getBytes());
	        } else {
	        		result.setResponseMessage("Not allowed to subscribe, check permissions");
	        		result.setSuccessful(false);
	        }
	        brokerClient.destroy();
	    } catch (BrokerException ex) {
	        log.error("Error occurred subscribing:\n"+ex);
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);
	    }
	}
	
	/**
	 * requestReply: in Broker terms, this is simply a publish
	 * followed by a subscribe.
	 * It is not possible to guarantee that the event subscribed will
	 * be associated with the event published, so careful analysis
	 * should go into the design of the test plans.
	 * @param result
	 */
	private void requestReply(SampleResult result){
		publish(result);
		if (result.isSuccessful())
			subscribe(result);
	}
	
	/**
	 * Initialise a BrokerEvent object based on the contents of the XML Test Data file
	 * passed in. The XML is parsed using the Commons Digester.
	 * @param brokerEvent
	 * @return the BrokerEvent that contains the contents of the test data file.
	 * @throws BrokerException
	 * @throws IOException
	 * @throws SAXException
	 */
	private BrokerEvent initialiseBrokerEvent(BrokerEvent brokerEvent) throws BrokerException, IOException, SAXException{
		Digester digester = new Digester();
		digester.setValidating(false);
		
		digester.addObjectCreate("webmethodstestdata", WebMethodsTestData.class);
		digester.addSetProperties("webmethodstestdata");
		
		digester.addObjectCreate("*/webmethodstestdata", WebMethodsTestData.class);
		digester.addSetProperties("*/webmethodstestdata");
		
		digester.addObjectCreate("*/input", Input.class);
		digester.addSetProperties("*/input");
		digester.addCallMethod("*/input", "setValue", 0);
		
		digester.addSetNext("*/input", "addInput");
		digester.addSetNext("*/webmethodstestdata", "addInput");
		
		WebMethodsTestData message = (WebMethodsTestData)digester.parse(new File(this.getFileInput()));
		
		log.debug("XML Parsed, input was: " + message.toString());
		
		List inputs = message.getInputs();
		
		BrokerEvent be = new BrokerEvent(null, message.getName());
		be = addInputs(inputs, be);
		log.debug("Event returned from addInputs is " + be.toString());
		brokerEvent.setStructFieldFromEvent(message.getName(), be);
		return brokerEvent;
	}
	
	private BrokerEvent addInputs(List list, BrokerEvent brokerEvent) throws BrokerException{
		for (int i = 0; i < list.size(); i++){
			Object temp = list.get(i);
			if (temp.getClass() == Input.class){
				// if the object is an Input, it is a simple name/value pair
				Input input = (Input)temp;
				// Add the input into the BrokerEvent
				brokerEvent = this.setField(brokerEvent, input);
				//brokerEvent.setField(input.getName(), parseType(input.getType()), input.getValue());
			} else if (temp.getClass() == WebMethodsTestData.class){
				WebMethodsTestData testData = (WebMethodsTestData)temp;
				// if the object is a WebMethodsTestData, it is a nested Struct
				// there are multiple types, check the type
				
				
				BrokerEvent e = new BrokerEvent(null, testData.getName());
				
				// add the Inputs that are in the IData
				e = addInputs(testData.getInputs(), e);
				
				// if there is an index in the tag, it is part of a sequence
				if (testData.getIndex() != null){
					BrokerEvent[] array = new BrokerEvent[1];
					array[0] = e;
					brokerEvent.setStructSeqFieldFromEvents(testData.getName(), 0, Integer.parseInt(testData.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
				} else {
				// set the struct from the event
				brokerEvent.setStructFieldFromEvent(testData.getName(), e);
				}
			} 
		}
		return brokerEvent;
	}

	/**
	 * setField provides recursive ability to set a single field based on an input.
	 * @param brokerEvent
	 * @param input
	 * @return
	 * @throws BrokerException
	 */
	private BrokerEvent setField(BrokerEvent brokerEvent, Input input) throws BrokerException {
		//short fieldType = 0;
		Map args = getArguments().getArgumentsAsMap();
		if (args.containsKey(input.getName())){
			input.setValue((String)args.get(input.getValue()));
		}
		if (input.getType().equalsIgnoreCase("Byte")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_BYTE;
			if (input.getIndex() != null){
				byte[] array = new byte[1];
				array[0] = Byte.parseByte(input.getValue());
				brokerEvent.setByteSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setByteField(input.getName(), Byte.parseByte(input.getValue()));

		} else if (input.getType().equalsIgnoreCase("Short")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_SHORT;
			if (input.getIndex() != null){
				short[] array = new short[1];
				array[0] = Short.valueOf(input.getValue()).shortValue();
				brokerEvent.setShortSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setShortField(input.getName(), Short.valueOf(input.getValue()).shortValue());

		} else if (input.getType().equalsIgnoreCase("Int")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_INT;
			if (input.getIndex() != null){
				int[] array = new int[1];
				array[0] = Integer.parseInt(input.getValue());
				brokerEvent.setIntegerSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setIntegerField(input.getName(), Integer.parseInt(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Long")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_LONG;
			if (input.getIndex() != null){
				long[] array = new long[1];
				array[0] = Long.valueOf(input.getValue()).longValue();
				brokerEvent.setLongSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setLongField(input.getName(), Long.valueOf(input.getValue()).longValue());
		} else if (input.getType().equalsIgnoreCase("Float")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_FLOAT;
			if (input.getIndex() != null){
				float[] array = new float[1];
				array[0] = Float.valueOf(input.getValue()).floatValue();
				brokerEvent.setFloatSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setFloatField(input.getName(), Float.valueOf(input.getValue()).floatValue());

		} else if (input.getType().equalsIgnoreCase("Double")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_DOUBLE;
			if (input.getIndex() != null){
				double[] array = new double[1];
				array[0] = Double.valueOf(input.getValue()).doubleValue();
				brokerEvent.setDoubleSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setDoubleField(input.getName(), Double.valueOf(input.getValue()).doubleValue());
		} else if (input.getType().equalsIgnoreCase("Boolean")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_BOOLEAN;
			if (input.getIndex() != null){
				boolean[] array = new boolean[1];
				array[0] = Boolean.valueOf(input.getValue()).booleanValue();
				brokerEvent.setBooleanSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setBooleanField(input.getName(), Boolean.valueOf(input.getValue()).booleanValue());

		} else if (input.getType().equalsIgnoreCase("Date")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_DATE;
			if (input.getIndex() != null){
				BrokerDate[] array = new BrokerDate[1];
				array[0] = BrokerDate.parseDate(input.getValue());
				brokerEvent.setDateSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setDateField(input.getName(), BrokerDate.parseDate(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Char")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_CHAR;
			if (input.getIndex() != null){
				char[] array = new char[1];
				array[0] = input.getValue().charAt(0);
				brokerEvent.setCharSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setCharField(input.getName(), input.getValue().charAt(0));
		} else if (input.getType().equalsIgnoreCase("String")){
			//fieldType = BrokerTypeDef.FIELD_TYPE_STRING;
			if (input.getIndex() != null){
				String[] array = new String[1];
				array[0] = input.getValue();
				brokerEvent.setUCStringSeqField(input.getName(), 0, Integer.parseInt(input.getIndex()) - 1, BrokerEvent.AUTO_SIZE, array);
			}
			else 
				brokerEvent.setUCStringField(input.getName(), input.getValue());
		}
			
		return brokerEvent;
	}

}
