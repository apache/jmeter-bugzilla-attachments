package org.apache.jmeter.protocol.webmethods.config.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.config.gui.AbstractConfigGui;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;

/**
 * WebMethodsISDefaultsGui provides the capability to configure deafult connection settings
 * for an Integration Server in order to prepare multiple Service Samplers to test the same server.
 * @author conorcurlett
 *
 */
public class WebMethodsISDefaultsGui extends AbstractConfigGui {

	private JTextField isHostname;
	private JTextField isPort;
	private JTextField username;
	private JPasswordField password;
    
	public WebMethodsISDefaultsGui() {
		super();
		init();
	}

	public String getLabelResource() {
		return "webmethods_is_config_title";
	}

	/**
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		ConfigTestElement config = new ConfigTestElement();
		modifyTestElement(config);
		return config;
	}

	/**
	 * Modifies a given TestElement to mirror the data in the gui components.
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
	 */
	public void modifyTestElement(TestElement config) {
		super.configureTestElement(config);
		config.setProperty(WebMethodsServiceSampler.IS_HOSTNAME, isHostname.getText());
		config.setProperty(WebMethodsServiceSampler.IS_PORT, isPort.getText());
		config.setProperty(WebMethodsServiceSampler.USERNAME, username.getText());
		config.setProperty(WebMethodsServiceSampler.PASSWORD, new String(password.getPassword()));
	}

	public void configure(TestElement el) {
		super.configure(el);
		isHostname.setText(el.getPropertyAsString(WebMethodsServiceSampler.IS_HOSTNAME));
		isPort.setText(el.getPropertyAsString(WebMethodsServiceSampler.IS_PORT));
		username.setText(el.getPropertyAsString(WebMethodsServiceSampler.USERNAME));
		password.setText(el.getPropertyAsString(WebMethodsServiceSampler.PASSWORD));
	}

	private void init() {
		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());

		add(makeTitlePanel(), BorderLayout.NORTH);

		HorizontalPanel integrationServerPanel = new HorizontalPanel();
		integrationServerPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		integrationServerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_server")));
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		integrationServerPanel.add(getIntegrationServerHostPanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		integrationServerPanel.add(getIntegrationServerPortPanel(), gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		integrationServerPanel.add(getUsernamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		integrationServerPanel.add(getPasswordPanel(), gbc);

		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(integrationServerPanel, BorderLayout.NORTH);
		
		
		add(mainPanel, BorderLayout.CENTER);
		add(new JPanel(new BorderLayout()), BorderLayout.SOUTH);

		
	}

	public Dimension getPreferredSize() {
		return getMinimumSize();
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getIntegrationServerHostPanel() {
		isHostname = new JTextField(20);
		isHostname.setName("IntegrationServerHostName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_is_hostname"));
		label.setLabelFor(isHostname);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(isHostname, BorderLayout.CENTER);
		return panel;
	}
	
	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getIntegrationServerPortPanel() {
		isPort = new JTextField(6);
		isPort.setName("IntegrationServerPort");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_is_port"));
		label.setLabelFor(isPort);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(isPort, BorderLayout.CENTER);
		return panel;
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getUsernamePanel() {
		username = new JTextField(20);
		username.setName("UserName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_username"));
		label.setLabelFor(username);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(username, BorderLayout.CENTER);
		return panel;
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getPasswordPanel() {
		password = new JPasswordField(20);
		password.setName("Password");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_password"));
		label.setLabelFor(password);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(password, BorderLayout.CENTER);
		return panel;
	}
	
}
