package org.apache.jmeter.protocol.webmethods.sampler.gui;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/http/org/apache/jmeter/protocol/webmethods/gui/WebMethodsServiceSamplerGui.java,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * GUI for configuring a webMethods IS Service Sampler
 * @author conorcurlett
 *
 */
public class WebMethodsServiceSamplerGUI extends AbstractSamplerGui{
	transient private static Logger log = LoggingManager.getLoggerForClass();

	public final static String IS_HOSTNAME = "isHostname";
	public final static String IS_PORT = "isPort";
	public final static String USERNAME = "username";
	public final static String PASSWORD = "password";
	public final static String PACKAGE_NAME = "packageName";
	public final static String SERVICE_NAME = "serviceName";
	
	private JTextField isHostname;
	private JTextField isPort;
	private JTextField packageName;
	private JTextField serviceName;
	private JTextField username;
	private JPasswordField password;
    
	private ServiceFileChooserGui xmlFileChooserGui;
	
	/** A panel allowing the user to set arguments for this test. */
	private ArgumentsPanel argsPanel;

	
	public WebMethodsServiceSamplerGUI() {
		init();
	}

	public String getLabelResource() {
		return "webmethods_service_sampler_title";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		WebMethodsServiceSampler sampler = new WebMethodsServiceSampler();
		modifyTestElement(sampler);
		return sampler;
	}

	/**
	 * Configure the GUI with the contents of the test element.
	 */
	public void configure(TestElement el) {
		super.configure(el);
		isHostname.setText(el.getPropertyAsString(WebMethodsServiceSampler.IS_HOSTNAME));
		isPort.setText(el.getPropertyAsString(WebMethodsServiceSampler.IS_PORT));
		username.setText(el.getPropertyAsString(WebMethodsServiceSampler.USERNAME));
		password.setText(el.getPropertyAsString(WebMethodsServiceSampler.PASSWORD));
		packageName.setText(el.getPropertyAsString(WebMethodsServiceSampler.PACKAGE_NAME));
		serviceName.setText(el.getPropertyAsString(WebMethodsServiceSampler.SERVICE_NAME));
		xmlFileChooserGui.configure(el);
		argsPanel.configure((Arguments) el.getProperty(WebMethodsServiceSampler.ARGUMENTS).getObjectValue());
	}
	
	/**
	 * Modifies a given TestElement to mirror the data in the gui components.
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
	 */
	public void modifyTestElement(TestElement el) {
		configureTestElement(el);
		
		el.setProperty(WebMethodsServiceSampler.IS_HOSTNAME, isHostname.getText());
		el.setProperty(WebMethodsServiceSampler.IS_PORT, isPort.getText());
		el.setProperty(WebMethodsServiceSampler.USERNAME, username.getText());
		el.setProperty(WebMethodsServiceSampler.PASSWORD, String.valueOf(password.getPassword()));
		el.setProperty(WebMethodsServiceSampler.PACKAGE_NAME, packageName.getText());
		el.setProperty(WebMethodsServiceSampler.SERVICE_NAME, serviceName.getText());
		xmlFileChooserGui.modifyTestElement(el);
		((WebMethodsServiceSampler) el).setArguments((Arguments) argsPanel.createTestElement());
	}

	private void init() {
		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());

		add(makeTitlePanel(), BorderLayout.NORTH);

		HorizontalPanel integrationServerPanel = new HorizontalPanel();
		integrationServerPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		integrationServerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_server")));
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		integrationServerPanel.add(getIntegrationServerHostPanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		integrationServerPanel.add(getIntegrationServerPortPanel(), gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		integrationServerPanel.add(getUsernamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		integrationServerPanel.add(getPasswordPanel(), gbc);
		
		HorizontalPanel serviceDetailsPanel = new HorizontalPanel();
		serviceDetailsPanel.setLayout(new GridBagLayout());
		gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1.5;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		serviceDetailsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_service_details")));
		serviceDetailsPanel.add(getPackageNamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		serviceDetailsPanel.add(getServiceNamePanel(), gbc);
		
		xmlFileChooserGui = new ServiceFileChooserGui();
		HorizontalPanel testDataPanel = new HorizontalPanel();
		testDataPanel.setLayout(new BorderLayout());
		testDataPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_service_test_data")));
		testDataPanel.add(xmlFileChooserGui, BorderLayout.WEST);
		
		JPanel serviceArgumentsPanel = new JPanel(new BorderLayout());
		serviceArgumentsPanel.add(serviceDetailsPanel, BorderLayout.NORTH);
		serviceArgumentsPanel.add(this.createParameterPanel(), BorderLayout.CENTER);
		serviceArgumentsPanel.add(testDataPanel, BorderLayout.SOUTH);
		
		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(integrationServerPanel, BorderLayout.NORTH);
		mainPanel.add(serviceArgumentsPanel, BorderLayout.CENTER);

		
		add(mainPanel, BorderLayout.CENTER);
		add(new JPanel(new BorderLayout()), BorderLayout.SOUTH);
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getIntegrationServerHostPanel() {
		isHostname = new JTextField(20);
		isHostname.setName("IntegrationServerHostName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_is_hostname"));
		label.setLabelFor(isHostname);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(isHostname, BorderLayout.CENTER);
		return panel;
	}
	
	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getIntegrationServerPortPanel() {
		isPort = new JTextField(6);
		isPort.setName("IntegrationServerPort");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_is_port"));
		label.setLabelFor(isPort);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(isPort, BorderLayout.CENTER);
		return panel;
	}
	
	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getPackageNamePanel() {
		packageName = new JTextField(20);
		packageName.setName("PackageName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_packagename"));
		label.setLabelFor(packageName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(packageName, BorderLayout.CENTER);
		return panel;
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getServiceNamePanel() {
		serviceName = new JTextField(20);
		serviceName.setName("ServiceName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_servicename"));
		label.setLabelFor(serviceName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(serviceName, BorderLayout.CENTER);
		return panel;
	}
		
	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getUsernamePanel() {
		username = new JTextField(20);
		username.setName("UserName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_username"));
		label.setLabelFor(username);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(username, BorderLayout.CENTER);
		return panel;
	}

	/**
	 * Get the panel containing the label and textfield
	 * @return A labelled textfield on a panel
	 */
	protected JPanel getPasswordPanel() {
		password = new JPasswordField(20);
		password.setName("Password");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_password"));
		label.setLabelFor(password);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(password, BorderLayout.CENTER);
		return panel;
	}

	/**
	 * Create a panel containing components allowing the user to provide
	 * arguments to be passed to the test class instance.
	 * 
	 * @return a panel containing the relevant components
	 */
	private JPanel createParameterPanel() {
		argsPanel = new ArgumentsPanel(JMeterUtils.getResString("paramtable"));
		return argsPanel;
	}
	
	
	public Dimension getPreferredSize() {
		return getMinimumSize();
	}
		
	
}
