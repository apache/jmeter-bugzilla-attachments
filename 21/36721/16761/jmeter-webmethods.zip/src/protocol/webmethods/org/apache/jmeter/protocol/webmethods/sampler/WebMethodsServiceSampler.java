package org.apache.jmeter.protocol.webmethods.sampler;

import java.beans.IntrospectionException;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.digester.Digester;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.webmethods.sampler.javabeans.Input;
import org.apache.jmeter.protocol.webmethods.sampler.javabeans.WebMethodsTestData;
import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.xml.sax.SAXException;

import com.wm.app.b2b.client.Context;
import com.wm.app.b2b.client.ServiceException;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.util.Values;

/**
 * Sampler to handle webMethods Service Requests. It uses the webMethods Java
 * client API to invoke the nominated service.
 * The commons Digester is used to parse XML test data containing the inputs 
 * and their names in order to form the input data.
 * <p>
 * Created on: August 25, 2005
 * 
 * @version $Revision: 0.1 $
 */
public class WebMethodsServiceSampler extends AbstractSampler {

	private static transient Logger log = LoggingManager.getLoggerForClass();
	
	public final static String IS_HOSTNAME = "WebMethodsServiceSampler.isHostname";
	public final static String IS_PORT = "WebMethodsServiceSampler.isPort";
	public final static String USERNAME = "WebMethodsServiceSampler.username";
	public final static String PASSWORD = "WebMethodsServiceSampler.password";
	public final static String PACKAGE_NAME = "WebMethodsServiceSampler.packageName";
	public final static String SERVICE_NAME = "WebMethodsServiceSampler.serviceName";
	public final static String XML_INPUT = "WebMethodsServiceSampler.xmlInput";

	/**
	 * Property key representing the arguments for the JavaSamplerClient.
	 */
	public static final String ARGUMENTS = "arguments";


	public WebMethodsServiceSampler(){
	}
	
	public String getISHostname(){
		return this.getPropertyAsString(IS_HOSTNAME);
	}
	public void setISHostname(String isHostname){
		this.setProperty(IS_HOSTNAME, isHostname);
	}
	public String getISPort(){
		return this.getPropertyAsString(IS_PORT);
	}
	public void setISPort(String isPort){
		this.setProperty(IS_PORT, isPort);
	}
	public String getUsername(){
		return this.getPropertyAsString(USERNAME);
	}
	public void setUserName(String username){
		this.setProperty(USERNAME, username);
	}
	public String getPassword(){
		return this.getPropertyAsString(PASSWORD);
	}
	public void setPassword(String password){
		this.setProperty(PASSWORD, password);
	}
	public String getPackageName(){
		return this.getPropertyAsString(PACKAGE_NAME);
	}
	public void setPackageName(String packageName){
		this.setProperty(PACKAGE_NAME, packageName);
	}
	public String getServiceName(){
		return this.getPropertyAsString(SERVICE_NAME);
	}
	public void setServiceName(String serviceName){
		this.setProperty(SERVICE_NAME, serviceName);
	}
	public String getXMLInput(){
		return this.getPropertyAsString(XML_INPUT);
	}
	public void setXMLInput(String xmlInput){
		this.setProperty(XML_INPUT, xmlInput);
	}
	/**
	 * Set the arguments (parameters) for the Sampler to be executed
	 * with.
	 * 
	 * @param args
	 *            the new arguments. These replace any existing arguments.
	 */
	public void setArguments(Arguments args) {
		setProperty(new TestElementProperty(ARGUMENTS, args));
	}

	/**
	 * Get the arguments (parameters) for the Sampler to be executed
	 * with.
	 * 
	 * @return the arguments
	 */
	public Arguments getArguments() {
		return (Arguments) getProperty(ARGUMENTS).getObjectValue();
	}
	
	/**
	 * Sample the webMethods Integration Server service.
	 */
	public SampleResult sample(Entry e) {
		SampleResult result = new SampleResult();
		Arguments args = getArguments();
		result.setSampleLabel(getName());
		result.setSamplerData(getXMLInput());
		result.sampleStart();
		Context context = openContextConnection();
		try {
			// Initialise the IData object that provides input to the service
			IData inputs = loadXMLContents();
			// now add any arguments
			inputs = modifyIData(inputs, args);
			log.debug("Invoking with " + printIData(inputs, 0, 0));
			// invoke the service against the connected Integration Server
			IData outputDocument = context.invoke(getPackageName(), getServiceName(), inputs);
			// convert the response to a string
			String output = printIData(outputDocument, 0, 0);
			result.setResponseData(output.getBytes());
			result.setResponseMessage(output);
			result.setSuccessful(true);
		} catch (ParseException ex){
			log.error("Unable to parse date, expected format dd/mm/yyyy: " + ex.getLocalizedMessage());
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);
		} catch (ServiceException ex) {
			log.error("A service exception was encountered: " + ex.getLocalizedMessage() );
			log.error("Additional details: " + ex.getNestedErrorDump());
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);
		} catch (IOException ex){
			log.error("A I/O exception was encountered: " + ex.getLocalizedMessage() );
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);
		} catch (SAXException ex){
			log.error("Unable to parse test data XML: " + ex.getLocalizedMessage() );
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);	
		} catch (IntrospectionException ex){
			log.error("Unable to parse test data XML: " + ex.getLocalizedMessage() );
			result.setResponseMessage(ex.getLocalizedMessage());
			result.setSuccessful(false);	
		}
		finally {
			try{
				context.disconnect();
			} catch (Exception exc){
				log.error("Error disconnecting from IS: " + exc.getMessage());
			}
		}
		result.setDataType(SampleResult.TEXT);
		result.sampleEnd();
		return result;
	}
	
	// Open a connection to the webMethods Integration Server using a specified set of credentials
	private Context openContextConnection(){
		Context context = new Context();
		try {
			// Attempt to establish a connection to the webMethods Integration Server with 
			// the supplied credentials
			context.connect(getISHostname() + ":" + getISPort(), getUsername(), getPassword());
		} catch (Exception e) {
			log.error("Cannot connect to server \"" + getISHostname() + ":" + getISPort() + "\" with the credentials:");
			log.error("UserID: " + getUsername());
			log.error("Password: " + getPassword());
		}
		return context;
	}

	/**
	 * PrintObject forms part of the printIData set of methods
	 * that will convert a webMethods IData object to a string.
	 *
	 *
	 * @param o
	 * @param key
	 * @param num
	 * @return The string representation of the object
	 */
	private String printObject(Object o, String key, int pad, int num){
        String output = new String();
		if(o == null)
            output = (getPad(pad) + key + " = null\n");
        else if(o instanceof String)
            output = (getPad(pad) + key + (num <= 0 ? " " : "[" + (num - 1) + "] ") + "= " + (String)o + "\n");
        else if(o instanceof Values){
            output = (getPad(pad) + key + " ==> DOCUMENT" + (num <= 0 ? "" : "[" + (num - 1) + "]") + "\n");
            output += printValues((Values)o, pad + 1, 0);
        } else if(o instanceof IData){
            output = (getPad(pad) + key + " ==> DOCUMENT" + (num <= 0 ? "" : "[" + (num - 1) + "]")+ "\n");
            output += printIData((IData)o, pad + 1, 0);
        } else if(o instanceof Object[]){
            output = (getPad(pad) + key + " ==> " + (num <= 0 ? "" : "[" + (num - 1) + "]") + "[]" + "\n");
            Object oa[] = (Object[])o;
            int cnt = oa.length;
            for(int i = 0; i < cnt; i++)
                output += printObject(oa[i], key + (num <= 0 ? "" : "[" + (num - 1) + "]"), pad+1, i + 1) + "\n";
        } else {
        		output = (getPad(pad) + key + (num <= 0 ? " " : "[" + (num - 1) + "] ") + "= " + o.toString() + "\n");
        }
		return output;
    }
	
	/**
	 * printValues is part of the printIData set of methods
	 * that provide the ability to represent a webMethods IData object as a String.
	 * 
	 * @param v
	 * @param num
	 * @return the string representing the Values object.
	 */
	private String printValues(Values v, int pad, int num){
        String key;
        String output = new String();
        for(Enumeration keys = v.keys(); keys.hasMoreElements(); output += printObject(v.get(key), key, pad, 0))
            key = (String)keys.nextElement();
        return output;
    }
        
	/**
	 * PrintIData provides the means to resolve an IData object into a 
	 * String representation of the same.
	 * @param i
	 * @param num
	 * @return The String representation of the IData
	 */
    private String printIData(IData i, int pad, int num){
        IDataCursor idc = i.getCursor();
        String output = new String();
        if(!idc.first())
            return output;
        do{
            String key = idc.getKey();
            output += printObject(idc.getValue(), key, pad, num);
        } while(idc.next());
        return output;
    }   

    /**
     * LoadXMLContents will use the Commons Digester to parse the XML test data
     * based on the expected schema. 
     * @see testdatatemplate.xml 
     * Using the data parsed, it will then prime an IData object with the data.
     * @return The primed IData containing the parsed XML test data
     * @throws IOException
     * @throws SAXException
     * @throws IntrospectionException
     * @throws ParseException 
     */
	private IData loadXMLContents() throws IOException, SAXException, IntrospectionException, ParseException{
		Digester digester = new Digester();
		digester.setValidating(false);
		
		digester.addObjectCreate("webmethodstestdata", WebMethodsTestData.class);
		digester.addSetProperties("webmethodstestdata");
		
		digester.addObjectCreate("*/webmethodstestdata", WebMethodsTestData.class);
		digester.addSetProperties("*/webmethodstestdata");
		
		digester.addObjectCreate("*/input", Input.class);
		digester.addSetProperties("*/input");
		digester.addCallMethod("*/input", "setValue", 0);
		
		digester.addSetNext("*/input", "addInput");
		digester.addSetNext("*/webmethodstestdata", "addInput");
		
		WebMethodsTestData message = (WebMethodsTestData)digester.parse(new File(this.getXMLInput()));
		
		log.debug("The XML Test Data parsed is: " + message.toString());
		
		return getIData(message);
	}
	
	private void addInputs(List list, IDataCursor inputsCursor) throws ParseException{
		for (int i = 0; i < list.size(); i++){
			Object temp = list.get(i);
			if (temp.getClass() == Input.class){
				// if the object is an Input, it is a simple name/value pair
				Input input = (Input)temp;
				// Add the input into the IData
				processInput(input, inputsCursor);
			} else if (temp.getClass() == WebMethodsTestData.class){
				// if the object is a WebMethodsTestData, it is a nested document
				// this is represented as an IData object in the client API
				IData idata = IDataFactory.create();
				IDataCursor idc = idata.getCursor();
				WebMethodsTestData testData = (WebMethodsTestData)temp;
				
				if (testData.getType().equalsIgnoreCase("DocumentList")){
					
					// a DocumentList is a single-length array containing an IData
					// which contains all the documents in the list.
					IData[] idataList = new IData[1];
					List docList = testData.getInputs();
					
			         // fill the IData
					for (int j = 0; j < docList.size(); j++){
						WebMethodsTestData wm = (WebMethodsTestData)docList.get(j);
						IData docListIData = getIData(wm);
						idc.insertAfter(wm.getName(), docListIData);
					}
					idc.destroy();
					idataList[0] = idata;
					inputsCursor.insertAfter(testData.getName(), idataList);
				} else if (testData.getType().equalsIgnoreCase("StringList")){ 
					// a StringList is represented as an array of String
					List stringList = testData.getInputs();
					String[] stringArray = new String[stringList.size()];
					for (int k = 0; k < stringList.size(); k++){
						Input string = (Input)stringList.get(k);
						stringArray[k] = string.getValue();
					}
					inputsCursor.insertAfter(testData.getName(), stringArray);
					idc.destroy();
				} else if (testData.getType().equalsIgnoreCase("ObjectList")){
					// an ObjectList is represented as an array of Object
					List objectList = testData.getInputs();
					loadObjectList(objectList, inputsCursor, testData.getName());
					idc.destroy();
				} else {
					// add the Inputs that are in the IData
					addInputs(testData.getInputs(), idc);
					inputsCursor.insertAfter(testData.getName(), idata);
					//destroy the cursor
					idc.destroy();
				}
			}
		}
	}
	
	private void loadObjectList(List objectList, IDataCursor idc, String name) throws ParseException {
		Input object = (Input)objectList.get(0);
		if (object.getType().equalsIgnoreCase("Boolean")){
			Boolean[] array = new Boolean[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Boolean.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Integer")){
			Integer[] array = new Integer[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Integer.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Byte")){
			Byte[] array = new Byte[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Byte.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Character")){
			Character[] array = new Character[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = new Character(object.getValue().charAt(0));
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Double")){
			Double[] array = new Double[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Double.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);		
		} else if (object.getType().equalsIgnoreCase("Float")){
			Float[] array = new Float[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Float.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Long")){
			Long[] array = new Long[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Long.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Short")){
			Short[] array = new Short[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = Short.valueOf(object.getValue());
			}
			idc.insertAfter(name, array);
		} else if (object.getType().equalsIgnoreCase("Date")){
			Date[] array = new Date[objectList.size()];
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = sdf.parse(object.getValue());
			}
			idc.insertAfter(name, array);
		} else {
			String[] array = new String[objectList.size()];
			for (int i = 0; i < objectList.size(); i++){
				object = (Input)objectList.get(i);
				array[i] = object.getValue();
			}
			idc.insertAfter(name, array);
		}
	}

	private void processInput(Input input, IDataCursor inputsCursor) throws ParseException {
		if (input.getType().equalsIgnoreCase("Boolean")){
			inputsCursor.insertAfter(input.getName(), Boolean.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Integer")){
			inputsCursor.insertAfter(input.getName(), Integer.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Byte")){
			inputsCursor.insertAfter(input.getName(), Byte.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Character")){
			inputsCursor.insertAfter(input.getName(), new Character(input.getValue().charAt(0)));
		} else if (input.getType().equalsIgnoreCase("Double")){
			inputsCursor.insertAfter(input.getName(), Double.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Float")){
			inputsCursor.insertAfter(input.getName(), Float.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Long")){
			inputsCursor.insertAfter(input.getName(), Long.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Short")){
			inputsCursor.insertAfter(input.getName(), Short.valueOf(input.getValue()));
		} else if (input.getType().equalsIgnoreCase("Date")){
			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			date = sdf.parse(input.getValue());
			inputsCursor.insertAfter(input.getName(), date);
		} else {
			inputsCursor.insertAfter(input.getName(), input.getValue());
		}
	}

	private IData getIData(WebMethodsTestData testData) throws ParseException{
		IData idata = IDataFactory.create();
		IDataCursor inputsCursor = idata.getCursor();
		List inputs = testData.getInputs();
		addInputs(inputs, inputsCursor);
		inputsCursor.destroy();
		return idata;
	}
	
	private IData modifyIData(IData idata, Arguments args){
		Map map = args.getArgumentsAsMap();
		IDataCursor idc = idata.getCursor();
		Object[] keys = map.keySet().toArray();
		for (int i = 0; i < map.size(); i++){
			
			if (idc.first((String)keys[i])){
				// the key already exists
				idc.setValue(map.get(keys[i]));
			} else {
				// the key doesn't, add it at the end.
				idc.last();
				idc.insertAfter((String)keys[i], map.get(keys[i]));
			}
		}
		return idata;
	}
	
	private String getPad(int depth){
		String output = new String();
		for (int i = 0; i < depth; i++){
			output = output + "\t";
		}
		return output;
	}
}
