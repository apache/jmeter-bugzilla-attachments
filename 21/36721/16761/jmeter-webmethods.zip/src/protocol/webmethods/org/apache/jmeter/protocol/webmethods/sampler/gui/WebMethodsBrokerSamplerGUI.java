package org.apache.jmeter.protocol.webmethods.sampler.gui;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/http/org/apache/jmeter/protocol/webmethods/sampler/gui/WebMethodsBrokerPublishSamplerGUI.java,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsBrokerSampler;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * GUI to configure a webMethods Broker Sampler 
 * @author conorcurlett
 *
 */
public class WebMethodsBrokerSamplerGUI extends AbstractSamplerGui {
	transient private static Logger log = LoggingManager.getLoggerForClass();

	public final static String BROKER_HOST = "brokerHost";
	public final static String BROKER_PORT = "brokerPort";
	public final static String BROKER_NAME = "brokerName";
	public final static String CLIENT_GROUP = "clientGroup";
	public final static String EVENT_NAME = "eventName";
	public final static String SUB_EVENT_NAME = "subEventName";
	
	private JTextField brokerHost;
	private JTextField brokerPort;
	private JTextField brokerName;
	private JTextField clientGroup;
	private JTextField eventName;
	private JTextField subEventName;
	
	private BrokerInteractionSelecterGui brokerInteractionSelecterGui;
	private BrokerFileChooserGui brokerFileChooserGui;
	
	/** A panel allowing the user to set arguments for this test. */
	private ArgumentsPanel argsPanel;
	
	public WebMethodsBrokerSamplerGUI() {
		init();
	}

	public String getLabelResource() {
		return "webmethods_broker_sampler_title";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		WebMethodsBrokerSampler sampler = new WebMethodsBrokerSampler();
		modifyTestElement(sampler);
		return sampler;
	}

	/**
	 * Configure the GUI with the contents of the test element
	 */
	public void configure(TestElement el) {
		super.configure(el);
		brokerHost.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_HOST));
		brokerPort.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_PORT));
		brokerName.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_NAME));
		clientGroup.setText(el.getPropertyAsString(WebMethodsBrokerSampler.CLIENT_GROUP));
		eventName.setText(el.getPropertyAsString(WebMethodsBrokerSampler.EVENT_NAME));
		subEventName.setText(el.getPropertyAsString(WebMethodsBrokerSampler.SUB_EVENT_NAME));
		brokerInteractionSelecterGui.configureTestElement(el);
		brokerFileChooserGui.configureTestElement(el);
		argsPanel.configure((Arguments) el.getProperty(WebMethodsBrokerSampler.ARGUMENTS).getObjectValue());
	}
	
	/**
	 * Modifies a given TestElement to mirror the data in the gui components.
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
	 */
	public void modifyTestElement(TestElement el) {
		configureTestElement(el);
		
		el.setProperty(WebMethodsBrokerSampler.BROKER_HOST, brokerHost.getText());
		el.setProperty(WebMethodsBrokerSampler.BROKER_PORT, brokerPort.getText());
		el.setProperty(WebMethodsBrokerSampler.BROKER_NAME, brokerName.getText());
		el.setProperty(WebMethodsBrokerSampler.CLIENT_GROUP, clientGroup.getText());
		el.setProperty(WebMethodsBrokerSampler.EVENT_NAME, eventName.getText());
		el.setProperty(WebMethodsBrokerSampler.SUB_EVENT_NAME, subEventName.getText());
		brokerInteractionSelecterGui.modifyTestElement(el);
		brokerFileChooserGui.modifyTestElement(el);
		((WebMethodsBrokerSampler) el).setArguments((Arguments) argsPanel.createTestElement());
	}

	private void init() {
		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());

		add(makeTitlePanel(), BorderLayout.NORTH);

		HorizontalPanel brokerServerPanel = new HorizontalPanel();
		brokerServerPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		brokerServerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_broker")));
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		brokerServerPanel.add(getBrokerHostPanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		brokerServerPanel.add(getBrokerPortPanel(), gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		brokerServerPanel.add(getBrokerNamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		brokerServerPanel.add(getClientGroupPanel(), gbc);
		gbc.gridx = 0;
		gbc.gridy = 2;
		brokerServerPanel.add(getEventNamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 2;
		brokerServerPanel.add(getSubEventNamePanel(), gbc);
		
		brokerInteractionSelecterGui = new BrokerInteractionSelecterGui();
		HorizontalPanel interactionSelecterPanel = new HorizontalPanel();
		interactionSelecterPanel.setLayout(new BorderLayout());
		interactionSelecterPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_broker_interaction_selecter")));
		interactionSelecterPanel.add(brokerInteractionSelecterGui, BorderLayout.WEST);
		
		brokerFileChooserGui = new BrokerFileChooserGui();
		HorizontalPanel testDataPanel = new HorizontalPanel();
		testDataPanel.setLayout(new BorderLayout());
		testDataPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_service_test_data")));
		testDataPanel.add(brokerFileChooserGui, BorderLayout.WEST);
		testDataPanel.add(createParameterPanel(), BorderLayout.NORTH);		
		
		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(brokerServerPanel, BorderLayout.NORTH);
		mainPanel.add(testDataPanel, BorderLayout.CENTER);
		mainPanel.add(interactionSelecterPanel, BorderLayout.SOUTH);

		
		add(mainPanel, BorderLayout.CENTER);
		add(new JPanel(new BorderLayout()), BorderLayout.SOUTH);
	}
	
	protected JPanel getBrokerHostPanel() {
		brokerHost = new JTextField(20);
		brokerHost.setName("BrokerHost");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_hostname"));
		label.setLabelFor(brokerHost);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerHost, BorderLayout.CENTER);
		return panel;
	}
	
	protected JPanel getBrokerPortPanel() {
		brokerPort = new JTextField(6);
		brokerPort.setName("BrokerPort");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_port"));
		label.setLabelFor(brokerPort);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerPort, BorderLayout.CENTER);
		return panel;
	}
	
	protected JPanel getBrokerNamePanel() {
		brokerName = new JTextField(20);
		brokerName.setName("BrokerName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_name"));
		label.setLabelFor(brokerName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerName, BorderLayout.CENTER);
		return panel;
	}

	protected JPanel getClientGroupPanel() {
		clientGroup = new JTextField(20);
		clientGroup.setName("ClientGroup");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_client_group"));
		label.setLabelFor(clientGroup);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(clientGroup, BorderLayout.CENTER);
		return panel;
	}
	
	protected JPanel getEventNamePanel() {
		eventName = new JTextField(30);
		eventName.setName("EventName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_event_name"));
		label.setLabelFor(eventName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(eventName, BorderLayout.CENTER);
		return panel;
	}	

	protected JPanel getSubEventNamePanel() {
		subEventName = new JTextField(30);
		subEventName.setName("SubEventName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_sub_event_name"));
		label.setLabelFor(subEventName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(subEventName, BorderLayout.CENTER);
		return panel;
	}	

	/**
	 * Create a panel containing components allowing the user to provide
	 * arguments to be passed to the test class instance.
	 * 
	 * @return a panel containing the relevant components
	 */
	private JPanel createParameterPanel() {
		argsPanel = new ArgumentsPanel(JMeterUtils.getResString("paramtable"));
		return argsPanel;
	}
	
	
	public Dimension getPreferredSize() {
		return getMinimumSize();
	}
	

}
