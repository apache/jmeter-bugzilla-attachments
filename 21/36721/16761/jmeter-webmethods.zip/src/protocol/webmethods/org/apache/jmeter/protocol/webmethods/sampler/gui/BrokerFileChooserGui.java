package org.apache.jmeter.protocol.webmethods.sampler.gui;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/http/org/apache/jmeter/protocol/webmethods/sampler/gui/BrokerFileChooserGui.java,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.gui.util.FileDialoger;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsBrokerSampler;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.BooleanProperty;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * This provides a GUI panel which allows the user to pick a file 
 * as the xml test data and inspect the contents.
 * @author conorcurlett
 *
 */
public class BrokerFileChooserGui extends JPanel implements ActionListener{
	transient private static Logger log = LoggingManager.getLoggerForClass();

	public final static String FILE_INPUT = "fileInput";
	
	private JTextField fileInput;
	private JButton loadButton;
	private JTextArea fileContents;
	
	public BrokerFileChooserGui(){
		init();
	}
	
	private void init() {
		this.setLayout(new BorderLayout());
		fileInput = new JTextField(20);
		fileInput.setName("FileInput");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_file_data"));
		label.setLabelFor(fileInput);
		loadButton = new JButton(JMeterUtils.getResString("load"));
		loadButton.setMnemonic('L');
		loadButton.setActionCommand("Load");
		loadButton.setEnabled(true);
		loadButton.addActionListener(this);

		fileContents = new JTextArea(10, 10);
		fileContents.setEditable(false);

		JPanel panel = new JPanel(new FlowLayout());
		
		panel.add(label);
		panel.add(fileInput);
		panel.add(loadButton);
		JPanel fileContentsPanel = new JPanel(new BorderLayout());
		fileContentsPanel.add(fileContents, BorderLayout.CENTER);
		fileContentsPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_broker_file_contents")));
		this.add(panel, BorderLayout.NORTH);
		this.add(fileContentsPanel, BorderLayout.CENTER);
	}

	public TestElement createTestElement(){
		WebMethodsBrokerSampler element = new WebMethodsBrokerSampler();
		element.setProperty(WebMethodsBrokerSampler.FILE_INPUT, fileInput.getText());
		return element;
	}
	
	protected void configureTestElement(TestElement element) {
		setName(element.getPropertyAsString(TestElement.NAME));
		fileInput.setText(element.getPropertyAsString(WebMethodsBrokerSampler.FILE_INPUT));
	}

	protected void modifyTestElement(TestElement element) {
		element.setProperty(WebMethodsBrokerSampler.FILE_INPUT, fileInput.getText());
	}
	
	public String getLabelResource() {
		return "webmethods_broker_file_chooser";
	}

	
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();

		if (action.equalsIgnoreCase("Load")) {
			JFileChooser chooser = FileDialoger.promptToOpenFile();
			if (chooser == null) {
				return;
			}
			File file = chooser.getSelectedFile();

			if (file != null) {
				fileInput.setText(file.getPath());
				StringBuffer buf = new StringBuffer();
				try{
					Reader reader = new InputStreamReader(new FileInputStream(file));
					char[] charBuffer = new char[8192];
					int charsRead = 0;
					while((charsRead = reader.read(charBuffer)) != -1) {
						buf.append(charBuffer, 0, charsRead);
					}
					reader.close();
				} catch (Exception exc) {
					log.debug("An error occured loading the test data file " + file.toString() + ".  Details: " + exc.getMessage() );
				} 
				fileContents.setText(buf.toString());
			}
		}
	}

	

	public void clear() {
		fileInput.setText("");
	}
	
}
