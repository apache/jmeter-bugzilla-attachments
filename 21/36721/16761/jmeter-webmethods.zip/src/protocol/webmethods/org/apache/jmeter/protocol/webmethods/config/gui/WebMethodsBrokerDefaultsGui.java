package org.apache.jmeter.protocol.webmethods.config.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.config.gui.AbstractConfigGui;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsBrokerSampler;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.protocol.webmethods.sampler.gui.BrokerFileChooserGui;
import org.apache.jmeter.protocol.webmethods.sampler.gui.BrokerInteractionSelecterGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;

/**
 * WebMethodsBrokerDefaultsGui provides the ability to configure a set of
 * defaults for the webMethods Broker Sampler. This is of particular use
 * when configuring a number of tests against the same broker instance
 * (which given the singleton nature of a broker is frequently).
 * @author conorcurlett
 *
 */
public class WebMethodsBrokerDefaultsGui extends AbstractConfigGui {

	// the textfields to hold the defaults
	private JTextField brokerHost;
	private JTextField brokerPort;
	private JTextField brokerName;
	private JTextField clientGroup;

	public WebMethodsBrokerDefaultsGui() {
		super();
		init();
	}

	public String getLabelResource() {
		return "webmethods_broker_config_title";
	}

	/**
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		ConfigTestElement config = new ConfigTestElement();
		modifyTestElement(config);
		return config;
	}

	/**
	 * Modifies a given TestElement to mirror the data in the gui components.
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
	 */
	public void modifyTestElement(TestElement config) {
		super.configureTestElement(config);
		config.setProperty(WebMethodsBrokerSampler.BROKER_HOST, brokerHost.getText());
		config.setProperty(WebMethodsBrokerSampler.BROKER_PORT, brokerPort.getText());
		config.setProperty(WebMethodsBrokerSampler.BROKER_NAME, brokerName.getText());
		config.setProperty(WebMethodsBrokerSampler.CLIENT_GROUP, clientGroup.getText());
	}

	public void configure(TestElement el) {
		super.configure(el);
		brokerHost.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_HOST));
		brokerPort.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_PORT));
		brokerName.setText(el.getPropertyAsString(WebMethodsBrokerSampler.BROKER_NAME));
		clientGroup.setText(el.getPropertyAsString(WebMethodsBrokerSampler.CLIENT_GROUP));
	}

	private void init() {
		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());

		add(makeTitlePanel(), BorderLayout.NORTH);

		HorizontalPanel brokerServerPanel = new HorizontalPanel();
		brokerServerPanel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		brokerServerPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), JMeterUtils.
				getResString("webmethods_broker")));
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		brokerServerPanel.add(getBrokerHostPanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		brokerServerPanel.add(getBrokerPortPanel(), gbc);
		gbc.gridx = 0;
		gbc.gridy = 1;
		brokerServerPanel.add(getBrokerNamePanel(), gbc);
		gbc.gridx = 1;
		gbc.gridy = 1;
		brokerServerPanel.add(getClientGroupPanel(), gbc);

		JPanel mainPanel = new JPanel(new BorderLayout());
		mainPanel.add(brokerServerPanel, BorderLayout.NORTH);
		
		
		add(mainPanel, BorderLayout.CENTER);
		add(new JPanel(new BorderLayout()), BorderLayout.SOUTH);

		
	}

	public Dimension getPreferredSize() {
		return getMinimumSize();
	}

	protected JPanel getBrokerHostPanel() {
		brokerHost = new JTextField(20);
		brokerHost.setName("BrokerHost");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_hostname"));
		label.setLabelFor(brokerHost);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerHost, BorderLayout.CENTER);
		return panel;
	}
	
	protected JPanel getBrokerPortPanel() {
		brokerPort = new JTextField(6);
		brokerPort.setName("BrokerPort");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_port"));
		label.setLabelFor(brokerPort);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerPort, BorderLayout.CENTER);
		return panel;
	}
	
	protected JPanel getBrokerNamePanel() {
		brokerName = new JTextField(20);
		brokerName.setName("BrokerName");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_name"));
		label.setLabelFor(brokerName);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(brokerName, BorderLayout.CENTER);
		return panel;
	}

	protected JPanel getClientGroupPanel() {
		clientGroup = new JTextField(20);
		clientGroup.setName("ClientGroup");

		JLabel label = new JLabel(JMeterUtils.getResString("webmethods_broker_client_group"));
		label.setLabelFor(clientGroup);

		JPanel panel = new JPanel(new BorderLayout(5, 0));
		panel.add(label, BorderLayout.WEST);
		panel.add(clientGroup, BorderLayout.CENTER);
		return panel;
	}
	
	
}
