package org.apache.jmeter.protocol.webmethods.sampler.javabeans;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/webmethods/org/apache/jmeter/protocol/webmethods/sampler/javabeans/WebMethodsTestData.java,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/
import java.util.ArrayList;
import java.util.List;

/**
 * A JavaBean to parse the XML test data using Digester.
 * Contains a List of Inputs.
 * @author conorcurlett
 *
 */
public class WebMethodsTestData {

	private List inputs = new ArrayList();
	private String name = new String();
	private String index = null;
	private String type = new String();
	
	public WebMethodsTestData(){}

	
	public void addInput(Object input){
		inputs.add(input);
	}
	
	public List getInputs(){
		return inputs;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return this.name;
	}
	
	public void setIndex(String index){
		this.index = index;
	}
	
	public String getIndex(){
		return this.index;
	}
	
	public void setType(String type){
		this.type = type;
	}
	
	public String getType(){
		return this.type;
	}
	
	public String toString(){
		String newLine = System.getProperty("line.separator");
		StringBuffer buf = new StringBuffer();
		buf.append("Class Structure, Name = " + this.getName()).append(newLine);
		buf.append("--- Members ---").append(newLine);
		for (int i = 0; i < inputs.size(); i++){
			buf.append(inputs.get(i)).append(newLine);
		}
		return buf.toString();
	}
	
}
