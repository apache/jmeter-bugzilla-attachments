package org.apache.jmeter.protocol.webmethods.sampler.gui;
//$Header: /home/cvspublic/jakarta-jmeter/src/protocol/http/org/apache/jmeter/protocol/webmethods/sampler/gui/BrokerFileChooserGui.java,v 0.1 2005/08/25 20:50:45  Exp $
/*
* Copyright 2001-2004 The Apache Software Foundation.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
* 
*/
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.ConfigTestElement;
import org.apache.jmeter.gui.util.FileDialoger;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsBrokerSampler;
import org.apache.jmeter.protocol.webmethods.sampler.WebMethodsServiceSampler;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.BooleanProperty;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

/**
 * This provides a GUI panel which allows the user to select the  
 * type of interaction with the webMethods Broker
 * from publish, subscribe or Request/Reply.
 * @author conorcurlett
 *
 */
public class BrokerInteractionSelecterGui extends JPanel implements ActionListener{
	transient private static Logger log = LoggingManager.getLoggerForClass();
	// default is publish
	public final static String INTERACTION = "Publish";
	
	private JRadioButton publish;
	private JRadioButton subscribe;
	private JRadioButton requestReply;
	
	public BrokerInteractionSelecterGui(){
		init();
	}
	
	private void init() {
		this.setLayout(new BorderLayout());
		
		publish = new JRadioButton(JMeterUtils.getResString("webmethods_broker_publish_button"));
		publish.setMnemonic('p');
		publish.setActionCommand(JMeterUtils.getResString("webmethods_broker_publish_button"));
		publish.setSelected(true);
		
		subscribe = new JRadioButton(JMeterUtils.getResString("webmethods_broker_subscribe_button"));
		subscribe.setMnemonic('s');
		subscribe.setActionCommand(JMeterUtils.getResString("webmethods_broker_subscribe_button"));
	
		requestReply = new JRadioButton(JMeterUtils.getResString("webmethods_broker_requestreply_button"));
		requestReply.setMnemonic('r');
		requestReply.setActionCommand(JMeterUtils.getResString("webmethods_broker_requestreply_button"));

		ButtonGroup group = new ButtonGroup();
		group.add(publish);
		group.add(subscribe);
		group.add(requestReply);
		
		publish.addActionListener(this);
		subscribe.addActionListener(this);
		requestReply.addActionListener(this);

		JPanel panel = new JPanel(new FlowLayout());
		
		panel.add(publish);
		panel.add(subscribe);
		panel.add(requestReply);
		this.add(panel, BorderLayout.NORTH);
		
	}

	public TestElement createTestElement(){
		WebMethodsBrokerSampler element = new WebMethodsBrokerSampler();
		element.setProperty(WebMethodsBrokerSampler.INTERACTION, getInteraction());
		return element;
	}
	
	protected void configureTestElement(TestElement element) {
		setName(element.getPropertyAsString(TestElement.NAME));
		String interaction = element.getPropertyAsString(WebMethodsBrokerSampler.INTERACTION);
		if (interaction != null){
			if (interaction.equalsIgnoreCase(publish.getActionCommand()))
				publish.setSelected(true);
			else if (interaction.equalsIgnoreCase(subscribe.getActionCommand()))
				subscribe.setSelected(true);
			else if (interaction.equalsIgnoreCase(requestReply.getActionCommand()))
				requestReply.setSelected(true);
			else 
				publish.setSelected(true); //default
		}
	}

	protected void modifyTestElement(TestElement element) {
		element.setProperty(WebMethodsBrokerSampler.INTERACTION, getInteraction());
	}
	
	public String getLabelResource() {
		return "webmethods_broker_interaction_selecter";
	}

	
	public void actionPerformed(ActionEvent e) {
		// currently no need to handle actions.
	}

	

	public String getInteraction(){
		if (publish.isSelected())
			return publish.getActionCommand();
		else if (subscribe.isSelected())
			return subscribe.getActionCommand();
		else if (requestReply.isSelected())
			return requestReply.getActionCommand();
		else return publish.getActionCommand(); //default
	}
}
