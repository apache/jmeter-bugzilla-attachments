/**
* This package holds every classes in relation with the gui or gui-components.  
*  
* @since 1.0
*/
package org.apache.jmeter.protocol.smtp.sampler.gui;