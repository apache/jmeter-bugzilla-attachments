/*
 * Copyright 2007 Luca Maragnani / 2008 Michael Tschannen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package org.apache.jmeter.protocol.smtp.sampler.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * Class to build gui-components for SMTP-sampler. Getter-methods serve the
 * input-data to the sampler-object, which provides them to the
 * SendMailCommand-object.
 * 
 * @author luca / extended by Michael Tschannen
 * @version 1.0
 * 
 */
public class SmtpPanel extends javax.swing.JPanel {

    /**
     * Creates new form SmtpPanel, standard constructer. Calls
     * initComponents();.
     * 
     */
    public SmtpPanel() {
        initComponents();
    }

    /**
     * Returns sender-address for e-mail from textfield
     * 
     * @return Sender
     */
    public String getMailFrom() {
        return tfMailFrom.getText();
    }

    /**
     * Returns receiver in field "to" from textfield
     * 
     * @return Receiver "to"
     */
    public String getReceiverTo() {
        return tfMailTo.getText();
    }

    /**
     * Returns receiver in field "cc" from textfield
     * 
     * @return Receiver "cc"
     */
    public String getReceiverCC() {
        return tfMailToCC.getText();
    }

    /**
     * Returns receiver in field "bcc" from textfield
     * 
     * @return Receiver "bcc"
     */
    public String getReceiverBCC() {
        return tfMailToBCC.getText();
    }

    /**
     * Returns message body, i.e. main-mime-part of message (from textfield)
     * 
     * @return Message body
     */
    public String getBody() {
        return taMessage.getText();
    }

    /**
     * Sets message body, i.e. main-mime-part of message in textfield
     * 
     * @param messageBodyText
     *            Message body
     */
    public void setBody(String messageBodyText) {
        this.taMessage.setText(messageBodyText);
    }

    /**
     * Sets sender-address of e-mail in textfield
     * 
     * @param mailFrom
     *            Sender
     */
    public void setMailFrom(String mailFrom) {
        this.tfMailFrom.setText(mailFrom);
    }

    /**
     * Sets receiver in textfield "to"
     * 
     * @param mailTo
     *            Receiver "to"
     */
    public void setReceiverTo(String mailTo) {
        this.tfMailTo.setText(mailTo);
    }

    /**
     * Sets receiver in textfield "cc"
     * 
     * @param mailToCC
     *            Receiver "cc"
     */
    public void setReceiverCC(String mailToCC) {
        this.tfMailToCC.setText(mailToCC);
    }

    /**
     * Sets receiver in textfield "bcc"
     * 
     * @param mailToBCC
     *            Receiver "bcc"
     */
    public void setReceiverBCC(String mailToBCC) {
        this.tfMailToBCC.setText(mailToBCC);
    }

    /**
     * Returns path of file(s) to be attached in e-mail from textfield
     * 
     * @return File to attach
     */
    public String getAttachments() {
        return tfAttachment.getText();
    }

    /**
     * Sets path of file to be attached in e-mail in textfield
     * 
     * @param attachmentFolder
     *            File to attach
     */
    public void setAttachments(String attachments) {
        this.tfAttachment.setText(attachments);
    }

    /**
     * Returns port of mail-server (standard 25 for SMTP/SMTP with StartTLS, 465
     * for SSL) from textfield
     * 
     * @return Mail-server port
     */
    public String getDutPort() {
        if (tfMailServerPort.getText().equalsIgnoreCase("")) {
            return "25";
        } else {
            return tfMailServerPort.getText();
        }
    }

    /**
     * Sets port of mail-server (standard 25 for SMTP/SMTP with StartTLS, 465
     * for SSL) in textfield
     * 
     * @param dutPort
     *            Mail-server port
     */
    public void setDutPort(String dutPort) {
        this.tfMailServerPort.setText(dutPort);
    }

    /**
     * Returns mail-server to be used to send message (from textfield)
     * 
     * @return FQDN or IP of mail-server
     */
    public String getDut() {
        return tfMailServer.getText();
    }

    /**
     * Sets mail-server to be used to send message in textfield
     * 
     * @param dut
     *            FQDN or IP of mail-server
     */
    public void setDut(String dut) {
        this.tfMailServer.setText(dut);
    }

    /**
     * Returns subject of the e-mail from textfield
     * 
     * @return Subject of e-mail
     */
    public String getSubject() {
        return tfSubject.getText();
    }

    /**
     * Sets subject of the e-mail in textfield
     * 
     * @param subject
     *            Subject of e-mail
     */
    public void setSubject(String subject) {
        this.tfSubject.setText(subject);
    }

    /**
     * Returns if mail-server needs authentication (checkbox)
     * 
     * @return true if authentication is used
     */
    public boolean isUseAuth() {
        return cbUseAuth.isSelected();
    }

    /**
     * Returns if SSL is used to secure the SMTP-connection (checkbox)
     * 
     * @return true if SSL is used to secure the SMTP-connection
     */
    public boolean isUseSSL() {
        return rbUseSSL.isSelected();
    }

    /**
     * Sets SSL to be used to secure the SMTP-connection (checkbox)
     * 
     * @param useSSL
     *            Use SSL to secure the connection
     */
    public void setUseSSL(boolean useSSL) {
        rbUseSSL.setSelected(useSSL);
    }

    /**
     * Returns if StartTLS is used to secure the connection (checkbox)
     * 
     * @return true if StartTLS is used to secure the connection
     */
    public boolean isUseStartTLS() {
        return rbUseStartTLS.isSelected();
    }

    /**
     * Sets StartTLS to be used to secure the SMTP-connection (checkbox)
     * 
     * @param useStartTLS
     *            Use StartTLS to secure the connection
     */
    public void setUseStartTLS(boolean useStartTLS) {
        rbUseStartTLS.setSelected(useStartTLS);
    }

    /**
     * Returns if StartTLS is enforced (normally, SMTP uses plain
     * SMTP-connection as fallback if "250-STARTTLS" isn't sent from the
     * mailserver) (checkbox)
     * 
     * @return true if StartTLS is enforced
     */
    public boolean isEnforceStartTLS() {
        return cbEnforceStartTLS.isSelected();
    }

    /**
     * Enforces StartTLS to secure the SMTP-connection (checkbox)
     * 
     * @param enforceStartTLS
     *            Enforce the use of StartTLS to secure the connection
     * @see jmeter.smtpsampler.gui.SmtpPanel#isEnforceStartTLS()
     */
    public void setEnforceStartTLS(boolean enforceStartTLS) {
        cbEnforceStartTLS.setSelected(enforceStartTLS);
    }

    /**
     * Returns if all certificates are blindly trusted (using according
     * SocketFactory) (checkbox)
     * 
     * @return true if all certificates are blindly trusted
     */
    public boolean isTrustAllCerts() {
        return cbTrustAllCerts.isSelected();
    }

    /**
     * Enforces JMeter to trust all certificates, no matter what CA is issuer
     * (checkbox)
     * 
     * @param trustAllCerts
     *            Trust all certificates
     * @see jmeter.smtpsampler.gui.SmtpPanel#isTrustAllCerts()
     */
    public void setTrustAllCerts(boolean trustAllCerts) {
        cbTrustAllCerts.setSelected(trustAllCerts);
    }

    /**
     * Returns if server certificate is installed prior to avoid
     * SSL-Connection-Exceptions (checkbox)
     * 
     * @return true if certificate is installed in advance
     */
    public boolean isInstallTrustStore() {
        return cbInstallTrustStore.isSelected();
    }

    /**
     * Install server certificate in advance to avoid SSL-Connection-Exceptions
     * (checkbox)
     * 
     * @param InstallTrustStore
     *            True if server certificate should be installed in local
     *            truststore
     */
    public void setInstallTrustStore(boolean InstallTrustStore) {
        cbInstallTrustStore.setSelected(InstallTrustStore);
    }

    /**
     * Returns path to local truststore used to install server certificate
     * 
     * @return Path to local truststore
     */
    public String getTrustStoreToInstall() {
        return tfTrustStoreToInstall.getText();
    }

    /**
     * Sets path to local truststore used to install server certificate
     * 
     * @param trustStoreToInstall
     *            path to local truststore
     */
    public void setTrustStoreToInstall(String trustStoreToInstall) {
        this.tfTrustStoreToInstall.setText(trustStoreToInstall);
    }

    /**
     * Returns if local (pre-installed) truststore is used to avoid
     * SSL-connection-exceptions (checkbox)
     * 
     * @return true if a local truststore is used
     */
    public boolean isUseLocalTrustStore() {
        return cbUseLocalTrustStore.isSelected();
    }

    /**
     * Set the use of a local (pre-installed) truststore to avoid
     * SSL-connection-exceptions (checkbox)
     * 
     * @param useLocalTrustStore
     *            Use local keystore
     */
    public void setUseLocalTrustStore(boolean useLocalTrustStore) {
        cbUseLocalTrustStore.setSelected(useLocalTrustStore);
    }

    /**
     * Returns the path to the local (pre-installed) truststore to be used to
     * avoid SSL-connection-exceptions
     * 
     * @return Path to local truststore
     */
    public String getTrustStoreToUse() {
        return tfTrustStoreToUse.getText();
    }

    /**
     * Set the path to local (pre-installed) truststore to be used to avoid
     * SSL-connection-exceptions
     * 
     * @param trustStoreToUse
     *            Path to local truststore
     */
    public void setTrustStoreToUse(String trustStoreToUse) {
        this.tfTrustStoreToUse.setText(trustStoreToUse);
    }

    /**
     * Returns if an .eml-message is sent instead of the content of message-text
     * area
     * 
     * @return true if .eml is sent, false if text area content is sent in
     *         e-mail
     */
    public boolean isUseEmlMessage() {
        return cbUseEmlMessage.isSelected();
    }

    /**
     * Set the use of an .eml-message instead of the content of message-text
     * area
     * 
     * @param useEmlMessage
     *            Use eml message
     */
    public void setUseEmlMessage(boolean useEmlMessage) {
        this.cbUseEmlMessage.setSelected(useEmlMessage);
    }

    /**
     * Returns path to eml message to be sent
     * 
     * @return path to eml message to be sent
     */
    public String getEmlMessage() {
        return tfEmlMessage.getText();
    }

    /**
     * Set path to eml message to be sent
     * 
     * @param emlMessage
     *            path to eml message to be sent
     */
    public void setEmlMessage(String emlMessage) {
        this.tfEmlMessage.setText(emlMessage);
    }

    /**
     * Returns if current timestamp is included in the subject (checkbox)
     * 
     * @return true if current timestamp is included in subject
     */
    public boolean isIncludeTimestamp() {
        return cbIncludeTimestamp.isSelected();
    }

    /**
     * Set timestamp to be included in the message-subject (checkbox)
     * 
     * @param includeTimestamp
     *            Should timestamp be included in subject?
     */
    public void setIncludeTimestamp(boolean includeTimestamp) {
        this.cbIncludeTimestamp.setSelected(includeTimestamp);
    }

    /**
     * Returns if message size statistics are processed. Output of processing
     * will be included in sample result. (checkbox)
     * 
     * @return True if message size will be calculated
     */
    public boolean isMessageSizeStatistics() {
        return cbMessageSizeStats.isSelected();
    }

    /**
     * Set message size to be calculated and included in sample result
     * (checkbox)
     * 
     * @param val
     *            Schould message size be calculated?
     */
    public void setMessageSizeStatistic(boolean val) {
        this.cbMessageSizeStats.setSelected(val);
    }

    /**
     * Returns if status Code 200 is set if sampler wasn't successful
     * 
     * @return True if failure should be expected
     */
    public boolean isCheckForFailure() {
        return cbCheckForFailure.isSelected();
    }

    /**
     * Assigns sampler to set return code 200 (successful) if sending the
     * message failed
     * 
     * @param val
     *            Schould failure be expected?
     */
    public void setCheckForFailure(boolean val) {
        this.cbCheckForFailure.setSelected(val);
    }

    /**
     * Main method of class, builds all gui-components for SMTP-sampler.
     */
    private void initComponents() {
        GridBagConstraints gridBagConstraints, gridBagConstraintsMain;

        jlAddressFrom = new javax.swing.JLabel();
        jlAddressTo = new javax.swing.JLabel();
        jlAddressToCC = new javax.swing.JLabel();
        jlAddressToBCC = new javax.swing.JLabel();
        jlMailServerPort = new javax.swing.JLabel();
        jlMailServer = new javax.swing.JLabel();
        jlAttachFile = new javax.swing.JLabel();
        jlDutPortStandard = new javax.swing.JLabel();
        jlUsername = new javax.swing.JLabel();
        jlPassword = new javax.swing.JLabel();
        jlTrustStoreToInstall = new javax.swing.JLabel();
        jlTrustStoreToInstallFormat = new javax.swing.JLabel();
        jlTrustStoreToUse = new javax.swing.JLabel();
        jlSubject = new javax.swing.JLabel();
        jlMessage = new javax.swing.JLabel();

        tfMailServer = new javax.swing.JTextField(30);
        tfMailServerPort = new javax.swing.JTextField(6);
        tfTrustStoreToInstall = new javax.swing.JTextField(20);
        tfTrustStoreToUse = new javax.swing.JTextField(20);
        tfMailFrom = new javax.swing.JTextField(25);
        tfMailTo = new javax.swing.JTextField(25);
        tfMailToCC = new javax.swing.JTextField(25);
        tfMailToBCC = new javax.swing.JTextField(25);
        tfAuthUsername = new javax.swing.JTextField(20);
        tfAuthPassword = new javax.swing.JTextField(20);
        tfSubject = new javax.swing.JTextField(20);
        tfAttachment = new javax.swing.JTextField(30);
        tfEmlMessage = new javax.swing.JTextField(30);

        taMessage = new javax.swing.JTextArea(5, 20);

        cbUseAuth = new javax.swing.JCheckBox();
        rbUseNone = new javax.swing.JRadioButton("Use no security features");
        rbUseSSL = new javax.swing.JRadioButton("Use SSL");
        rbUseStartTLS = new javax.swing.JRadioButton("Use StartTLS");

        cbTrustAllCerts = new javax.swing.JCheckBox();
        cbEnforceStartTLS = new javax.swing.JCheckBox();
        cbIncludeTimestamp = new javax.swing.JCheckBox();
        cbMessageSizeStats = new javax.swing.JCheckBox();
        cbCheckForFailure = new javax.swing.JCheckBox();
        cbInstallTrustStore = new javax.swing.JCheckBox();
        cbUseLocalTrustStore = new javax.swing.JCheckBox();
        cbUseEmlMessage = new javax.swing.JCheckBox();

        attachmentFileChooser = new javax.swing.JFileChooser();
        emlFileChooser = new javax.swing.JFileChooser();

        browseButton = new javax.swing.JButton();
        emlBrowseButton = new javax.swing.JButton();

        attachmentFileChooser
                .addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        attachmentFolderFileChooserActionPerformed(evt);
                    }
                });

        emlFileChooser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emlFileChooserActionPerformed(evt);
            }
        });

        setLayout(new GridBagLayout());

        gridBagConstraintsMain = new GridBagConstraints();
        gridBagConstraintsMain.fill = GridBagConstraints.HORIZONTAL;
        gridBagConstraintsMain.anchor = GridBagConstraints.WEST;

        gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.insets = new java.awt.Insets(2, 2, 2, 2);
        gridBagConstraints.fill = GridBagConstraints.NONE;
        ;
        gridBagConstraints.anchor = GridBagConstraints.WEST;

        /*
         * Server Settings
         */
        JPanel panelServerSettings = new JPanel(new GridBagLayout());
        panelServerSettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Server settings"));

        jlMailServer.setText("Server:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelServerSettings.add(jlMailServer, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panelServerSettings.add(tfMailServer, gridBagConstraints);

        jlMailServerPort.setText("Port:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panelServerSettings.add(jlMailServerPort, gridBagConstraints);

        JPanel panelServerPortSettings = new JPanel(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelServerPortSettings.add(tfMailServerPort, gridBagConstraints);

        jlDutPortStandard.setText("(Standard: 25)");
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panelServerPortSettings.add(jlDutPortStandard, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panelServerSettings.add(panelServerPortSettings, gridBagConstraints);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 0;
        add(panelServerSettings, gridBagConstraintsMain);

        /*
         * E-Mail Settings
         */
        JPanel panelMailSettings = new JPanel(new GridBagLayout());
        panelMailSettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Mail settings"));

        jlAddressFrom.setText("Address From:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelMailSettings.add(jlAddressFrom, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panelMailSettings.add(tfMailFrom, gridBagConstraints);

        jlAddressTo.setText("Address To:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panelMailSettings.add(jlAddressTo, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panelMailSettings.add(tfMailTo, gridBagConstraints);

        jlAddressToCC.setText("Address To CC:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        panelMailSettings.add(jlAddressToCC, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panelMailSettings.add(tfMailToCC, gridBagConstraints);

        jlAddressToBCC.setText("Address To BCC:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        panelMailSettings.add(jlAddressToBCC, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        panelMailSettings.add(tfMailToBCC, gridBagConstraints);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 1;
        add(panelMailSettings, gridBagConstraintsMain);

        /*
         * Auth Settings
         */
        JPanel panelAuthSettings = new JPanel(new GridBagLayout());
        panelAuthSettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Auth settings"));

        cbUseAuth.setText("Use Auth");
        cbUseAuth.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0,
                0, 0));
        cbUseAuth.setMargin(new java.awt.Insets(0, 0, 0, 0));
        cbUseAuth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbUseAuthActionPerformed(evt);
            }
        });
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelAuthSettings.add(cbUseAuth, gridBagConstraints);

        jlUsername.setText("Username:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        panelAuthSettings.add(jlUsername, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        panelAuthSettings.add(tfAuthUsername, gridBagConstraints);
        tfAuthUsername.setEditable(false);

        jlPassword.setText("Password:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        panelAuthSettings.add(jlPassword, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panelAuthSettings.add(tfAuthPassword, gridBagConstraints);
        tfAuthPassword.setEditable(false);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 2;
        add(panelAuthSettings, gridBagConstraintsMain);

        /*
         * Security Settings
         */
        JPanel panelSecuritySettings = new JPanel(new GridBagLayout());
        panelSecuritySettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Security settings"));

        rbUseNone.setSelected(true);
        bgSecuritySettings = new javax.swing.ButtonGroup();
        bgSecuritySettings.add(rbUseNone);
        bgSecuritySettings.add(rbUseSSL);
        bgSecuritySettings.add(rbUseStartTLS);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelSecuritySettings.add(rbUseNone, gridBagConstraints);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panelSecuritySettings.add(rbUseSSL, gridBagConstraints);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        panelSecuritySettings.add(rbUseStartTLS, gridBagConstraints);

        rbUseNone.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbSecuritySettingsItemStateChanged(evt);
            }
        });
        rbUseSSL.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbSecuritySettingsItemStateChanged(evt);
            }
        });
        rbUseStartTLS.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rbSecuritySettingsItemStateChanged(evt);
            }
        });

        cbTrustAllCerts.setText("Trust all certificates");
        cbTrustAllCerts.setBorder(javax.swing.BorderFactory.createEmptyBorder(
                0, 0, 0, 0));
        cbTrustAllCerts.setMargin(new java.awt.Insets(0, 0, 0, 0));
        cbTrustAllCerts.setEnabled(false);
        cbTrustAllCerts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbTrustAllCertsActionPerformed(evt);
            }
        });

        String trustAllCertsToolTip = "<html><b>Enforces</b> JMeter to trust all certificates, whatever CA it comes from. <br />If not selected, you should install the server certificate manually <br />(using the corresponding option below)</html>";
        cbTrustAllCerts.setToolTipText(trustAllCertsToolTip);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panelSecuritySettings.add(cbTrustAllCerts, gridBagConstraints);

        cbEnforceStartTLS.setText("Enforce StartTLS");
        cbEnforceStartTLS.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbEnforceStartTLS.setMargin(new java.awt.Insets(0, 0, 0, 0));
        cbEnforceStartTLS.setEnabled(false);
        cbEnforceStartTLS
                .addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        cbEnforceStartTLSActionPerformed(evt);
                    }
                });

        String enforceStartTLSToolTip = "<html><b>Enforces</b> the server to use StartTLS.<br />If not selected and the SMTP-Server doesn't support StartTLS, <br />a normal SMTP-Connection will be used as fallback instead. <br /><i>Please note</i> that this checkbox creates a file in \"/tmp/\", <br />so this will cause problems under windows.</html>";
        cbEnforceStartTLS.setToolTipText(enforceStartTLSToolTip);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panelSecuritySettings.add(cbEnforceStartTLS, gridBagConstraints);

        cbInstallTrustStore
                .setText("Install server certificate in temporary truststore");
        cbInstallTrustStore.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbInstallTrustStore.setMargin(new java.awt.Insets(0, 0, 0, 0));
        cbInstallTrustStore.setEnabled(false);
        cbInstallTrustStore
                .addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        cbInstallTrustStoreActionPerformed(evt);
                    }
                });

        String installTrustStoreToolTip = "<html><b>Pleasae note:</b><br />This option will generate a new TrustStore to be used to authenticate the server certificate. <br />The new TrustStore (that will be fully trusted) will be stored in <i>$workingdir/jmeterSMTPTrustStore</i>. <br />It is ABSOLUTELY recommended to delete this file after running the tests.</html>";
        cbInstallTrustStore.setToolTipText(installTrustStoreToolTip);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 2;
        panelSecuritySettings.add(cbInstallTrustStore, gridBagConstraints);

        jlTrustStoreToInstall.setText("Server to get certificate from:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        panelSecuritySettings.add(jlTrustStoreToInstall, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        panelSecuritySettings.add(tfTrustStoreToInstall, gridBagConstraints);

        jlTrustStoreToInstallFormat.setText("(Format: <host>[:port])");
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        panelSecuritySettings.add(jlTrustStoreToInstallFormat,
                gridBagConstraints);

        cbUseLocalTrustStore.setText("Use local truststore");
        cbUseLocalTrustStore.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbUseLocalTrustStore.setMargin(new java.awt.Insets(0, 0, 0, 0));
        cbUseLocalTrustStore.setEnabled(false);
        cbUseLocalTrustStore
                .addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        cbUseLocalTrustStoreActionPerformed(evt);
                    }
                });

        String useLocalTrustStoreToolTip = "<html><b>Pleasae note:</b></html>";
        cbUseLocalTrustStore.setToolTipText(useLocalTrustStoreToolTip);

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 2;
        panelSecuritySettings.add(cbUseLocalTrustStore, gridBagConstraints);

        jlTrustStoreToUse.setText("Local truststore:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 1;
        panelSecuritySettings.add(jlTrustStoreToUse, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        panelSecuritySettings.add(tfTrustStoreToUse, gridBagConstraints);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 3;
        add(panelSecuritySettings, gridBagConstraintsMain);

        /*
         * (non-Javadoc) Message Settings
         */
        JPanel panelMessageSettings = new JPanel(new GridBagLayout());
        panelMessageSettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Message settings"));

        jlSubject.setText("Subject:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelMessageSettings.add(jlSubject, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panelMessageSettings.add(tfSubject, gridBagConstraints);

        cbIncludeTimestamp.setText("Include timestamp in subject");
        cbIncludeTimestamp.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbIncludeTimestamp.setMargin(new java.awt.Insets(0, 0, 0, 0));
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        panelMessageSettings.add(cbIncludeTimestamp, gridBagConstraints);

        jlMessage.setText("Message:");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panelMessageSettings.add(jlMessage, gridBagConstraints);

        taMessage.setBorder(javax.swing.BorderFactory.createBevelBorder(1));
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panelMessageSettings.add(taMessage, gridBagConstraints);

        jlAttachFile.setText("Attach file(s):");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        panelMessageSettings.add(jlAttachFile, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panelMessageSettings.add(tfAttachment, gridBagConstraints);
        tfAttachment.setText("separate multiple files with \";\"");

        browseButton.setText("Browse");
        browseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                browseButtonActionPerformed(evt);
            }
        });

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        panelMessageSettings.add(browseButton, gridBagConstraints);

        cbUseEmlMessage.setText("Send .eml:");
        cbUseEmlMessage.setSelected(false);
        cbUseEmlMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbUseEmlMessageActionPerformed(evt);
            }
        });

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        panelMessageSettings.add(cbUseEmlMessage, gridBagConstraints);

        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        tfEmlMessage.setEnabled(false);
        panelMessageSettings.add(tfEmlMessage, gridBagConstraints);

        emlBrowseButton.setText("Browse");
        emlBrowseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emlBrowseButtonActionPerformed(evt);
            }
        });
        emlBrowseButton.setEnabled(false);

        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        panelMessageSettings.add(emlBrowseButton, gridBagConstraints);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 4;
        add(panelMessageSettings, gridBagConstraintsMain);

        /*
         * Additional Settings
         */
        JPanel panelAdditionalSettings = new JPanel(new GridBagLayout());
        panelAdditionalSettings.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Additional Settings"));

        cbMessageSizeStats.setText("Calculate message size");
        cbMessageSizeStats.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbMessageSizeStats.setMargin(new java.awt.Insets(0, 0, 0, 0));

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panelAdditionalSettings.add(cbMessageSizeStats, gridBagConstraints);

        cbCheckForFailure.setText("Check for failure");
        cbCheckForFailure.setBorder(javax.swing.BorderFactory
                .createEmptyBorder(0, 0, 0, 0));
        cbCheckForFailure.setMargin(new java.awt.Insets(0, 0, 0, 0));

        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panelAdditionalSettings.add(cbCheckForFailure, gridBagConstraints);

        gridBagConstraintsMain.gridx = 0;
        gridBagConstraintsMain.gridy = 5;
        add(panelAdditionalSettings, gridBagConstraintsMain);
    }

    /**
     * ActionPerformed-method for checkbox "useAuth"
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void cbUseAuthActionPerformed(java.awt.event.ActionEvent evt) {
        if (cbUseAuth.isSelected()) {
            tfAuthUsername.setEditable(true);
            tfAuthPassword.setEditable(true);
        } else {
            tfAuthUsername.setEditable(false);
            tfAuthPassword.setEditable(false);
        }
    }

    /**
     * ActionPerformed-method for checkbox "installTrustStore"
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void cbInstallTrustStoreActionPerformed(
            java.awt.event.ActionEvent evt) {
        if (cbInstallTrustStore.isSelected()) {
            tfTrustStoreToInstall.setEditable(true);
            cbTrustAllCerts.setSelected(false);
            cbUseLocalTrustStore.setSelected(false);
            tfTrustStoreToUse.setEditable(false);
        }
    }

    /**
     * ActionPerformed-method for checkbox "useLocalTrustStore"
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void cbUseLocalTrustStoreActionPerformed(
            java.awt.event.ActionEvent evt) {
        if (cbUseLocalTrustStore.isSelected()) {
            tfTrustStoreToUse.setEditable(true);
            cbTrustAllCerts.setSelected(false);
            cbInstallTrustStore.setSelected(false);
            tfTrustStoreToInstall.setEditable(false);
        }
    }

    /**
     * ActionPerformed-method for filechoser "attachmentFileChoser", creates
     * FileChoser-Object
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void attachmentFolderFileChooserActionPerformed(
            java.awt.event.ActionEvent evt) {
        // if(!tfAttachment.getText().isEmpty()) { //JAVA1.6
        // as per https://bugs.privasphere.com/show_bug.cgi?id=2889
        if (null != tfAttachment.getText() && 0 !=
        // or should also trim()?
                tfAttachment.getText().length()) {
            tfAttachment
                    .setText(tfAttachment.getText()
                            + ";"
                            + attachmentFileChooser.getSelectedFile()
                                    .getAbsolutePath());
        } else {
            tfAttachment.setText(attachmentFileChooser.getSelectedFile()
                    .getAbsolutePath());
        }

    }

    /**
     * ActionPerformed-method for button "browseButton", opens FileDialog-Object
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void browseButtonActionPerformed(java.awt.event.ActionEvent evt) {
        attachmentFileChooser.showOpenDialog(this);
    }

    private void cbUseEmlMessageActionPerformed(java.awt.event.ActionEvent evt) {
        if (cbUseEmlMessage.isSelected()) {
            tfEmlMessage.setEnabled(true);
            emlBrowseButton.setEnabled(true);

            /*tfMailFrom.setEnabled(false);
            tfMailTo.setEnabled(false);
            tfMailToCC.setEnabled(false);
            tfMailToBCC.setEnabled(false);
            tfSubject.setEnabled(false);*/
            taMessage.setEnabled(false);
            tfAttachment.setEnabled(false);
            browseButton.setEnabled(false);
        } else {
            tfEmlMessage.setEnabled(false);
            emlBrowseButton.setEnabled(false);

            /*tfMailFrom.setEnabled(true);
            tfMailTo.setEnabled(true);
            tfMailToCC.setEnabled(true);
            tfMailToBCC.setEnabled(true);
            tfSubject.setEnabled(true);*/
            taMessage.setEnabled(true);
            tfAttachment.setEnabled(true);
            browseButton.setEnabled(true);
        }
    }

    /**
     * ActionPerformed-method for filechoser "emlFileChoser", creates
     * FileChoser-Object
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void emlFileChooserActionPerformed(java.awt.event.ActionEvent evt) {
        tfEmlMessage
                .setText(emlFileChooser.getSelectedFile().getAbsolutePath());
    }

    /**
     * ActionPerformed-method for button "emlButton", opens FileDialog-Object
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void emlBrowseButtonActionPerformed(java.awt.event.ActionEvent evt) {
        emlFileChooser.showOpenDialog(this);
    }

    /**
     * ActionPerformed-method for checkbox "trustAllCerts"
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void cbTrustAllCertsActionPerformed(java.awt.event.ActionEvent evt) {
        if (cbTrustAllCerts.isSelected()) {
            cbInstallTrustStore.setSelected(false);
            tfTrustStoreToInstall.setEditable(false);
        }
    }

    /**
     * ActionPerformed-method for checkbox "enforceStartTLS", empty method
     * header
     * 
     * @param evt
     *            ActionEvent to be handeled
     */
    private void cbEnforceStartTLSActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here
    }

    /**
     * ItemStateChanged-method for radiobutton "securitySettings"
     * 
     * @param evt
     *            ItemEvent to be handeled
     */
    private void rbSecuritySettingsItemStateChanged(java.awt.event.ItemEvent evt) {
        if (evt.getSource() == rbUseNone) {
        	if (tfMailServerPort.getText().trim().equals("465")) {
        		tfMailServerPort.setText("25");
        	}
            cbTrustAllCerts.setEnabled(false);
            cbTrustAllCerts.setSelected(false);
            cbEnforceStartTLS.setEnabled(false);
            cbEnforceStartTLS.setSelected(false);
            cbInstallTrustStore.setSelected(false);
            cbInstallTrustStore.setEnabled(false);
            tfTrustStoreToInstall.setEditable(false);
            cbUseLocalTrustStore.setSelected(false);
            cbUseLocalTrustStore.setEnabled(false);
            tfTrustStoreToUse.setEditable(false);
        } else if (evt.getSource() == rbUseSSL) {
        	if (tfMailServerPort.getText().trim().equals("255")) {
        		tfMailServerPort.setText("465");
        	}
            cbTrustAllCerts.setEnabled(true);
            ;
            cbEnforceStartTLS.setEnabled(false);
            cbEnforceStartTLS.setSelected(false);
            cbInstallTrustStore.setEnabled(true);
            cbInstallTrustStore.setSelected(false);
            cbUseLocalTrustStore.setEnabled(true);
            tfTrustStoreToInstall.setEditable(false);
            tfTrustStoreToUse.setEditable(false);
        } else if (evt.getSource() == rbUseStartTLS) {
        	if (tfMailServerPort.getText().trim().equals("465")) {
        		tfMailServerPort.setText("25");
        	}
        	cbTrustAllCerts.setEnabled(false);
            cbTrustAllCerts.setSelected(false);
            cbEnforceStartTLS.setEnabled(true);
            cbInstallTrustStore.setEnabled(true);
            cbInstallTrustStore.setSelected(true);
            cbUseLocalTrustStore.setEnabled(true);
            tfTrustStoreToInstall.setEditable(true);
            cbUseLocalTrustStore.setSelected(false);
            tfTrustStoreToUse.setEditable(false);
        }
    }

    /**
     * Standard ItemStateChanged-Method, empty method header
     * 
     * @param evt
     *            ItemEvent to be handeled
     */
    public void itemStateChanged(java.awt.event.ItemEvent evt) {
        // TODO add your handling code here
    }

    // local vars
    private javax.swing.JTextField tfMailFrom;
    private javax.swing.JButton browseButton;
    private javax.swing.JButton emlBrowseButton;
    private javax.swing.JCheckBox cbTrustAllCerts;
    private javax.swing.JCheckBox cbEnforceStartTLS;
    protected javax.swing.JCheckBox cbUseAuth;
    private javax.swing.JCheckBox cbInstallTrustStore;
    private javax.swing.JCheckBox cbUseLocalTrustStore;
    protected javax.swing.JRadioButton rbUseNone;
    protected javax.swing.JRadioButton rbUseSSL;
    protected javax.swing.JRadioButton rbUseStartTLS;
    protected javax.swing.ButtonGroup bgSecuritySettings;
    private javax.swing.JTextField tfMailServer;
    private javax.swing.JTextField tfMailServerPort;
    private javax.swing.JTextField tfTrustStoreToInstall;
    private javax.swing.JTextField tfTrustStoreToUse;
    private javax.swing.JTextField tfMailTo;
    private javax.swing.JTextField tfMailToCC;
    private javax.swing.JTextField tfMailToBCC;
    private javax.swing.JTextField tfAttachment;
    private javax.swing.JTextField tfEmlMessage;

    /**
     * TODO use for smime/pgp generated mails via bouncyCastle as per
     * https://issues.apache.org/bugzilla/show_bug.cgi?id=38387
     */
    private javax.swing.JTextField tfSigningKeyPairFile;

    private javax.swing.JTextArea taMessage;
    private javax.swing.JLabel jlAddressFrom;
    private javax.swing.JLabel jlAddressTo;
    private javax.swing.JLabel jlAddressToCC;
    private javax.swing.JLabel jlAddressToBCC;
    private javax.swing.JLabel jlMailServerPort;
    private javax.swing.JLabel jlMailServer;
    private javax.swing.JLabel jlAttachFile;
    private javax.swing.JLabel jlDutPortStandard;
    private javax.swing.JLabel jlTrustStoreToInstall;
    private javax.swing.JLabel jlTrustStoreToInstallFormat;
    private javax.swing.JLabel jlTrustStoreToUse;
    private javax.swing.JLabel jlPassword;
    private javax.swing.JLabel jlSubject;
    private javax.swing.JLabel jlUsername;
    private javax.swing.JLabel jlMessage;
    private javax.swing.JFileChooser attachmentFileChooser;
    private javax.swing.JFileChooser emlFileChooser;
    protected javax.swing.JTextField tfAuthPassword;
    protected javax.swing.JTextField tfAuthUsername;
    protected javax.swing.JTextField tfSubject;
    protected javax.swing.JCheckBox cbIncludeTimestamp;
    protected javax.swing.JCheckBox cbMessageSizeStats;
    protected javax.swing.JCheckBox cbCheckForFailure;
    protected javax.swing.JCheckBox cbUseEmlMessage;
}