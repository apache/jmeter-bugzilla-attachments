/**
* This package holds additional classes, acting as helpers for the smtp-sampler.  
*  
* @since 1.0
*/
package org.apache.jmeter.protocol.smtp.sampler.tools;