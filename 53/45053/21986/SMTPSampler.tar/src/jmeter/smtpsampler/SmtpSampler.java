/*
 * Copyright 2007 Luca Maragnani / 2008 Michael Tschannen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package jmeter.smtpsampler;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.AuthenticationFailedException;
import javax.net.ssl.SSLHandshakeException;
import javax.mail.internet.InternetAddress;

import jmeter.smtpsampler.protocol.MailBodyProvider;
import jmeter.smtpsampler.protocol.SendMailCommand;
import jmeter.smtpsampler.tools.CounterOutputStream;
import jmeter.smtpsampler.tools.UnexpectedSuccessException;

import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Sampler-Class for JMeter - builds, starts and interprets the results of the sampler. 
 * Has to implement some standard-methods for JMeter in order to be integrated in the framework.
 * All getter/setter methods just deliver/set values from/to the sampler, not from/to the message-object.
 * Therefor, all these methods are also present in class SendMailCommand.   
 * 
 * @see jmeter.smtpsampler.protocol.SendMailCommand
 * @author Luca Maragnani / slightly extended by Michael Tschannen
 * @version 1.0
 */
public class SmtpSampler extends AbstractSampler {
	
    private static final Logger log = LoggingManager.getLoggerForClass();
	
    public final static String SERVER = "server";
	public final static String SERVER_PORT = "serverPort";
    public final static String USE_AUTH = "useAuth";
	public final static String USERNAME = "username";
	public final static String PASSWORD = "password";
	public final static String MAIL_FROM = "SmtpSampler.mailFrom"; 
	public final static String RECEIVER_TO = "SmtpSampler.receiverTo";
	public final static String RECEIVER_CC = "SmtpSampler.receiverCC";
	public final static String RECEIVER_BCC = "SmtpSampler.receiverBCC";
	
	public final static String SUBJECT = "SmtpSampler.subject"; 
	public final static String MESSAGE = "message";
	public final static String INCLUDE_TIMESTAMP = "SmtpSampler.include_timestamp";  
	public final static String ATTACH_FILE = "SmtpSampler.attachFile"; 
	public final static String MESSAGE_SIZE_STATS = "SmtpSampler.messageSizeStatistics";
	public final static String CHECK_FOR_FAILURE = "checkForFailure";
    
    public final static String USE_SSL = "useSSL";
	public final static String USE_STARTTLS= "useStartTLS";
	public final static String SSL_TRUST_ALL_CERTS = "trustAllCerts";
	public final static String ENFORCE_STARTTLS = "enforceStartTLS";
	public final static String INSTALL_TRUSTSTORE = "installTrustStore";
	public final static String TRUSTSTORE_TO_INSTALL = "trustStoreToInstall";
	public final static String USE_LOCAL_TRUSTSTORE = "useLocalTrustStore";
	public final static String TRUSTSTORE_TO_USE = "trustStoreToUse";
	
	private static int classCount = 0; 
	
	/**
	 * Constructer for SMTP-Sampler, does nothing special. 
	 *
	 */
	public SmtpSampler() {
		classCount++;
		trace("SmtpSampler()");
	}
	
	/**
	 * Performs the sample, and returns the result
	 *
	 * @param e Standard-method-header from JMeter
	 * @return sampleresult Result of the sample
	 * @see org.apache.jmeter.samplers.Sampler#sample(org.apache.jmeter.samplers.Entry)
	 */
	public SampleResult sample(Entry e) {
		trace("sample()");
		Message message = null;
		SampleResult res = new SampleResult();
		boolean isOK = false; // Did sample succeed?
		
		// prepare message
		SendMailCommand instance = new SendMailCommand();
		try {
			instance.setSmtpServer(getPropertyAsString(SmtpSampler.SERVER));
			instance.setSmtpPort(getPropertyAsString(SmtpSampler.SERVER_PORT));
			
			instance.setUseSSL(getPropertyAsBoolean(USE_SSL));
			instance.setUseStartTLS(getPropertyAsBoolean(USE_STARTTLS));
			instance.setTrustAllCerts(getPropertyAsBoolean(SSL_TRUST_ALL_CERTS));
			instance.setEnforceStartTLS(getPropertyAsBoolean(ENFORCE_STARTTLS));
			
			instance.setUseAuthentication(getPropertyAsBoolean(USE_AUTH));
			instance.setUsername(getPropertyAsString(USERNAME));
			instance.setPassword(getPropertyAsString(PASSWORD));
			
			instance.setInstallTrustStore(getPropertyAsBoolean(INSTALL_TRUSTSTORE));
			instance.setTrustStoreToInstall(getPropertyAsString(TRUSTSTORE_TO_INSTALL));
			instance.setUseLocalTrustStore(getPropertyAsBoolean(USE_LOCAL_TRUSTSTORE));
			instance.setTrustStoreToUse(getPropertyAsString(TRUSTSTORE_TO_USE));
						
			instance.setSender(getMailFrom());
			
			//check if there are really mail-addresses in the fields and if there are multiple ones
			List <InternetAddress> receiversTo = new Vector();
			if(getPropertyAsString(SmtpSampler.RECEIVER_TO).matches(".*@.*")){
				String[] strReceivers = (getPropertyAsString(SmtpSampler.RECEIVER_TO)).split(";");
				for (int i = 0 ; i < strReceivers.length ; i++) {
					receiversTo.add(new InternetAddress(strReceivers[i].trim()));
				}
			}
			else {
				receiversTo.add(new InternetAddress(getMailFrom()));
			}
			
			instance.setReceiverTo(receiversTo);
			
			//check if there are really mail-addresses in the fields and if there are multiple ones
			if(getPropertyAsString(SmtpSampler.RECEIVER_CC).matches(".*@.*")){
				List <InternetAddress> receiversCC = new Vector();
				String[] strReceivers = (getPropertyAsString(SmtpSampler.RECEIVER_CC)).split(";");
				for (int i = 0 ; i < strReceivers.length ; i++) {
					receiversCC.add(new InternetAddress(strReceivers[i].trim()));
				}
				instance.setReceiverCC(receiversCC);
			}
			
			//check if there are really mail-addresses in the fields and if there are multiple ones
			if(getPropertyAsString(SmtpSampler.RECEIVER_BCC).matches(".*@.*")){
				List <InternetAddress> receiversBCC = new Vector();
				String[] strReceivers = (getPropertyAsString(SmtpSampler.RECEIVER_BCC)).split(";");
				for (int i = 0 ; i < strReceivers.length ; i++) {
					receiversBCC.add(new InternetAddress(strReceivers[i].trim()));
				}
				instance.setReceiverBCC(receiversBCC);
			}
			
			MailBodyProvider mb = new MailBodyProvider();
			if (getPropertyAsString(MESSAGE) != null && !getPropertyAsString(MESSAGE).equals(""))
				mb.setBody(getPropertyAsString(MESSAGE));
			instance.setMbProvider(mb);
			
			if (!getAttachments().equals("")) {
				String[] attachments = getAttachments().split(";");
				for(String attachment : attachments) {
					instance.addAttachment(new File(attachment));
				}
			} 
			
			instance.setSubject(getPropertyAsString(SUBJECT) + (getPropertyAsBoolean(INCLUDE_TIMESTAMP)?" <<< current timestamp: "+new Date().getTime()+" >>>":""));
			
			// needed for measuring sending time
			instance.setSynchronousMode(true);
			
			message = instance.prepareMessage();
			
			if (getPropertyAsBoolean(MESSAGE_SIZE_STATS)) {
				// calculate message size
				CounterOutputStream cs = new CounterOutputStream();
				message.writeTo(cs);
				res.setBytes(cs.getCount());
			} else {
				res.setBytes(-1);
			}
			
		} catch (Exception ex) {
			log.debug("Error while preparing message",ex);			
			return res;
		}
		
		// Perform the sampling
		res.sampleStart();

		try {
			instance.execute(message);
			
			if (getCheckForFailure())
				throw new UnexpectedSuccessException("Expected failure but got success...");
			
			// Set up the sample result details
			res.setSamplerData("To: "+getPropertyAsString(SmtpSampler.RECEIVER_TO)+"\nCC: "+getPropertyAsString(SmtpSampler.RECEIVER_CC)+"\nBCC: "+getPropertyAsString(SmtpSampler.RECEIVER_BCC));
			res.setDataType(SampleResult.TEXT);
			res.setResponseCodeOK();
			res.setResponseMessage("Message successfully sent!");
			res.setSampleLabel(getName());
			isOK = true;
		} 
		// username / password incorrect
		catch (AuthenticationFailedException afex) {
			res.setSampleLabel(getName());
			log.debug("", afex);
			res.setResponseCode("500");
			res.setResponseMessage("AuthenticationFailedException: authentication failed - wrong username / password!");
		}
		// SSL not supported, startTLS not supported, other messagingException
		catch (MessagingException mex) {
			if(getCheckForFailure()) {
				res.setSampleLabel(getName());
				res.setSamplerData(getPropertyAsString(SmtpSampler.RECEIVER_TO));
				res.setDataType(SampleResult.TEXT);
				res.setResponseCodeOK();
				res.setResponseMessage("Sending message failed");
				isOK = true;
			} 
			else {
				res.setSampleLabel(getName());
				mex.printStackTrace();
				log.debug("", mex);
				res.setResponseCode("500");
				if(mex.getMessage().matches(".*Could not connect to SMTP host.*465.*") && mex.getCause().getMessage().matches(".*Connection timed out.*")){
					res.setResponseMessage("MessagingException: Probably, SSL is not supported by the SMTP-Server!");
				}
				else if(mex.getMessage().matches(".*StartTLS failed.*")){
					res.setResponseMessage("MessagingException: StartTLS not supported by server or initializing failed!");
				}
				else if(mex.getMessage().matches(".*send command to.*") && mex.getCause().getMessage().matches(".*unable to find valid certification path to requested target.*")) {
					res.setResponseMessage("MessagingException: Server certificate not trusted - perhaps you have to restart JMeter!");
				}
				else {
					res.setResponseMessage("Other MessagingException: "+mex.toString());
				}
			}
		} 
		//general exception
		catch (Exception ex) {
			res.setSampleLabel(getName());
			ex.printStackTrace();
			log.debug("", ex);
			res.setResponseCode("500");
			if(ex.getMessage().matches("Failed to build truststore")) {
				res.setResponseMessage("Failed to build truststore - did not try to send mail!");
			}
			else {
				res.setResponseMessage("Other Exception: "+ex.toString());
			}
		}
		
		res.sampleEnd();
		
		try {
			// process the sampler result
			InputStream is = message.getInputStream();
			StringBuffer sb = new StringBuffer();
			byte[] buf = new byte[1024];
			while (is.read(buf) > 0) {
				sb.append(new String(buf));
			} 
			res.setResponseData(sb.toString().getBytes());
		} catch (IOException ex) {
			ex.printStackTrace();
		} catch (MessagingException ex) {
			ex.printStackTrace();
		}
		
		res.setSuccessful(isOK);
		
		return res;
	}
	
	/**
	 * 
	 * @return Sampler-title
	 */
	private String getTitle() {
		return this.getName();
	}
	
	/**
	 * @return FQDN or IP of mailserver
	 */
	public String getDut() {
		return getPropertyAsString(SERVER);
	}
	
	
	/**
	 * @return Mailserver-Port
	 */
	public int getDutPort() {
		return getPropertyAsInt(SERVER_PORT);
	}
	
	/**
	 * @return Sender's mail address
	 */
	public String getMailFrom() {
		return getPropertyAsString(MAIL_FROM);
	}
	
	/**
	 * @return Receiver in field "to"
	 */
	public String getReceiverTo() {
		return getPropertyAsString(RECEIVER_TO);
	}
	
	/**
	 * @return Receiver in field "cc"
	 */
	public String getReceiverCC() {
		return getPropertyAsString(RECEIVER_CC);
	}
	
	/**
	 * @return Receiver in field "bcc"
	 */
	public String getReceiverBCC() {
		return getPropertyAsString(RECEIVER_BCC);
	}
	
	/**
	 * @return Username for mailserver-login 
	 */
	public String getUsername() {
		return getPropertyAsString(USERNAME);
	}
	
	/**
	 * @return Password for mailserver-login
	 */
	public String getPassword() {
		return getPropertyAsString(PASSWORD);
	}

	/**
	 * @return Mail-subject
	 */
	public String getSubject() {
		return this.getPropertyAsString(SUBJECT);
	}
	
	/**
	 * @return true if timestamp is included in subject
	 */
	public boolean getIncludeTimestamp () {
		return this.getPropertyAsBoolean(INCLUDE_TIMESTAMP);
	}
	
	/**
	 * @return Path to file(s) to attach
	 */
	public String getAttachments () {
		return this.getPropertyAsString(ATTACH_FILE);
	}
	
	/**
	 * @return true if authentication is used to access mailserver
	 */
	public boolean getUseAuthentication () {
		return this.getPropertyAsBoolean(USE_AUTH);
	}
	
	/**
	 * @return true if sampler result is positive when sending fails 
	 */
	public boolean getCheckForFailure () {
		return this.getPropertyAsBoolean(CHECK_FOR_FAILURE);
	}
	
	
	/**
	 * Helper method - writes title, classcount, name, ... to logfile
	 *   
	 */
	private void trace(String s) {
		String tl = getTitle();
		String tn = Thread.currentThread().getName();
		String th = this.toString();
		log.debug(tn + " (" + classCount + ") " + tl + " " + s + " " + th);
	}
}