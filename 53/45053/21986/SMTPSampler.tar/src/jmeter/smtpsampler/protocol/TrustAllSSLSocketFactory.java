/*
 * Copyright 2007 Luca Maragnani
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package jmeter.smtpsampler.protocol;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import javax.net.SocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * This class can be used as a SocketFactory with SSL-connections. 
 * Its purpose is to ensure that all certificates - no matter from which CA -are accepted to secure the SSL-connection.
 * It has to be kept in mind that a SocketFactory must not be used with StartTLS, because the javaMail-api assumes 
 * to use SSL when using the socketFactory.class- or socketFactory.fallback-property.
 * 
 * @author luca
 */
public class TrustAllSSLSocketFactory extends SSLSocketFactory  {
	
	private SSLSocketFactory factory;

	/**
	 * Standard constructor
	 */
	public TrustAllSSLSocketFactory() {
		try {
			SSLContext sslcontext = SSLContext.getInstance( "TLS");
			sslcontext.init( null, new TrustManager[]{
				new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return null;
					}
					public void checkClientTrusted(
							java.security.cert.X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(
							java.security.cert.X509Certificate[] certs, String authType) {
					}
				}
			},
					new java.security.SecureRandom());
			factory = ( SSLSocketFactory) sslcontext.getSocketFactory();
		} catch( Exception ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * Factory method
	 * @return New TrustAllSSLSocketFactory
	 */
	public static SocketFactory getDefault() {
		return new TrustAllSSLSocketFactory();
	}
	
	/* (non-Javadoc)
	 * @see javax.net.ssl.SSLSocketFactory#createSocket(java.net.Socket, java.lang.String, int, boolean)
	 */
	public Socket createSocket( Socket socket, String s, int i, boolean
			flag)
			throws IOException {
		return factory.createSocket( socket, s, i, flag);
	}
	
	/* (non-Javadoc)
	 * @see javax.net.SocketFactory#createSocket(java.net.InetAddress, int, java.net.InetAddress, int)
	 */
	public Socket createSocket( InetAddress inaddr, int i,
			InetAddress inaddr1, int j) throws IOException {
		return factory.createSocket( inaddr, i, inaddr1, j);
	}
	
	/* (non-Javadoc)
	 * @see javax.net.SocketFactory#createSocket(java.net.InetAddress, int)
	 */
	public Socket createSocket( InetAddress inaddr, int i) throws
			IOException {
		return factory.createSocket( inaddr, i);
	}
	
	/* (non-Javadoc)
	 * @see javax.net.SocketFactory#createSocket(java.lang.String, int, java.net.InetAddress, int)
	 */
	public Socket createSocket( String s, int i, InetAddress inaddr, int j)
	throws IOException {
		return factory.createSocket( s, i, inaddr, j);
	}
	
	/* (non-Javadoc)
	 * @see javax.net.SocketFactory#createSocket(java.lang.String, int)
	 */
	public Socket createSocket( String s, int i) throws IOException {
		return factory.createSocket( s, i);
	}
	
	/* (non-Javadoc)
	 * @see javax.net.SocketFactory#createSocket()
	 */
	public Socket createSocket() throws IOException {
		return factory.createSocket();
	}
	
	/* (non-Javadoc)
	 * @see javax.net.ssl.SSLSocketFactory#getDefaultCipherSuites()
	 */
	public String[] getDefaultCipherSuites() {
		return factory.getSupportedCipherSuites();
	}
	
	/* (non-Javadoc)
	 * @see javax.net.ssl.SSLSocketFactory#getSupportedCipherSuites()
	 */
	public String[] getSupportedCipherSuites() {
		return factory.getSupportedCipherSuites();
	}
}