/*
 * Copyright 2007 Luca Maragnani / 2008 Michael Tschannen
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */


package jmeter.smtpsampler.gui;

import java.awt.BorderLayout;
import java.awt.Component;

import jmeter.smtpsampler.SmtpSampler;

import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;

/**
 * Class to build superstructure-gui for SMTP-panel, sets/gets value for a JMeter's testElement-object (i.e. also for save/load-purposes).
 * This class extends AbstractSamplerGui, therefor most implemented methods are defined by JMeter's structure. 
 *
 * @author  luca / slightly extended by Michael Tschannen
 * @version 1.0
 * 
 */
public class SmtpSamplerGui extends AbstractSamplerGui {

	private SmtpPanel smtpPanel;

	/** 
	 * Creates new SmtpSamplerGui, standard constructer. Calls init();
	 */
	public SmtpSamplerGui() {
		init();
	}

	/**
	 * Method to be implemented by interface, overwritten by getStaticLabel(). Method has to be implemented by interface
	 * @return Null-String
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getLabelResource()
	 */
	public String getLabelResource() {
		return null;
	}
	
	/**
	 * Overwrites getLabelResource(), sets a static label to the sampler
	 * @return Static label for SMTP-Sampler
	 * @see org.apache.jmeter.gui.AbstractJMeterGuiComponent#getStaticLabel()
	 */
	public String getStaticLabel() {
		return "SMTP Sampler";
	}

	/**
	 * Copy the data from the test element to the GUI, method has to be implemented by interface
	 * @param element Test-element to be used as data-input
	 * @see org.apache.jmeter.gui.AbstractJMeterGuiComponent#configure(org.apache.jmeter.testelement.TestElement)
	 */
	public void configure(TestElement element) {
		if (smtpPanel == null)
			smtpPanel = new SmtpPanel();
		
		smtpPanel.setDut(element.getPropertyAsString(SmtpSampler.SERVER));
		smtpPanel.setDutPort(element.getPropertyAsString(SmtpSampler.SERVER_PORT));
		smtpPanel.setMailFrom(element.getPropertyAsString(SmtpSampler.MAIL_FROM));
		smtpPanel.setReceiverTo(element.getPropertyAsString(SmtpSampler.RECEIVER_TO));
		smtpPanel.setReceiverCC(element.getPropertyAsString(SmtpSampler.RECEIVER_CC));
		smtpPanel.setReceiverBCC(element.getPropertyAsString(SmtpSampler.RECEIVER_BCC));
		
		smtpPanel.setBody(element.getPropertyAsString(SmtpSampler.MESSAGE));
		smtpPanel.setSubject(element.getPropertyAsString(SmtpSampler.SUBJECT));
		smtpPanel.setIncludeTimestamp(element.getPropertyAsBoolean(SmtpSampler.INCLUDE_TIMESTAMP));
		smtpPanel.setAttachments(element.getPropertyAsString(SmtpSampler.ATTACH_FILE));
		
		smtpPanel.setUseSSL(element.getPropertyAsBoolean(SmtpSampler.USE_SSL));
		smtpPanel.setUseStartTLS(element.getPropertyAsBoolean(SmtpSampler.USE_STARTTLS));
		if(!element.getPropertyAsBoolean(SmtpSampler.USE_STARTTLS) && !element.getPropertyAsBoolean(SmtpSampler.USE_SSL)){
			smtpPanel.rbUseNone.setSelected(true);
		}
		smtpPanel.setTrustAllCerts(element.getPropertyAsBoolean(SmtpSampler.SSL_TRUST_ALL_CERTS));
		smtpPanel.setEnforceStartTLS(element.getPropertyAsBoolean(SmtpSampler.ENFORCE_STARTTLS));
		smtpPanel.setInstallTrustStore(element.getPropertyAsBoolean(SmtpSampler.INSTALL_TRUSTSTORE));
		smtpPanel.setTrustStoreToInstall(element.getPropertyAsString(SmtpSampler.TRUSTSTORE_TO_INSTALL));
		smtpPanel.setUseLocalTrustStore(element.getPropertyAsBoolean(SmtpSampler.USE_LOCAL_TRUSTSTORE));
		smtpPanel.setTrustStoreToUse(element.getPropertyAsString(SmtpSampler.TRUSTSTORE_TO_USE));
		
		smtpPanel.cbUseAuth.setSelected(element.getPropertyAsBoolean(SmtpSampler.USE_AUTH));
		smtpPanel.tfAuthUsername.setText(element.getPropertyAsString(SmtpSampler.USERNAME));
		smtpPanel.tfAuthUsername.setEditable(element.getPropertyAsBoolean(SmtpSampler.USE_AUTH));
		smtpPanel.tfAuthPassword.setText(element.getPropertyAsString(SmtpSampler.PASSWORD));
		smtpPanel.tfAuthPassword.setEditable(element.getPropertyAsBoolean(SmtpSampler.USE_AUTH));
		
		smtpPanel.setMessageSizeStatistic(element.getPropertyAsBoolean(SmtpSampler.MESSAGE_SIZE_STATS));
		smtpPanel.setCheckForFailure(element.getPropertyAsBoolean(SmtpSampler.CHECK_FOR_FAILURE));

		super.configure(element);
	}

	/** 
	 * Creates a new TestElement and set up its data
	 * @return Test-element for JMeter
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		SmtpSampler sampler = new SmtpSampler();
		modifyTestElement(sampler);
		return sampler;
	}

	/** 
	 * Modifies a given TestElement to mirror the data in the gui components
	 * @param te TestElement for JMeter
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(org.apache.jmeter.testelement.TestElement)
	 */
	public void modifyTestElement(TestElement te) {
		te.clear();
		super.configureTestElement(te);
		te.setProperty(SmtpSampler.SERVER, smtpPanel.getDut());
		te.setProperty(SmtpSampler.SERVER_PORT, smtpPanel.getDutPort());
		te.setProperty(SmtpSampler.MAIL_FROM, smtpPanel.getMailFrom());
		te.setProperty(SmtpSampler.RECEIVER_TO, smtpPanel.getReceiverTo());
		te.setProperty(SmtpSampler.RECEIVER_CC, smtpPanel.getReceiverCC());
		te.setProperty(SmtpSampler.RECEIVER_BCC, smtpPanel.getReceiverBCC());
		te.setProperty(SmtpSampler.SUBJECT, smtpPanel.getSubject());
		te.setProperty(SmtpSampler.INCLUDE_TIMESTAMP, Boolean.toString(smtpPanel.isIncludeTimestamp()));
		te.setProperty(SmtpSampler.MESSAGE, smtpPanel.getBody());
		te.setProperty(SmtpSampler.ATTACH_FILE, smtpPanel.getAttachments());
		
		te.setProperty(SmtpSampler.USE_SSL, Boolean.toString(smtpPanel.isUseSSL()));
		te.setProperty(SmtpSampler.USE_STARTTLS, Boolean.toString(smtpPanel.isUseStartTLS()));
		te.setProperty(SmtpSampler.SSL_TRUST_ALL_CERTS, Boolean.toString(smtpPanel.isTrustAllCerts()));
		te.setProperty(SmtpSampler.ENFORCE_STARTTLS, Boolean.toString(smtpPanel.isEnforceStartTLS()));
		te.setProperty(SmtpSampler.INSTALL_TRUSTSTORE, Boolean.toString(smtpPanel.isInstallTrustStore()));
		te.setProperty(SmtpSampler.TRUSTSTORE_TO_INSTALL, smtpPanel.getTrustStoreToInstall());
		te.setProperty(SmtpSampler.USE_LOCAL_TRUSTSTORE, Boolean.toString(smtpPanel.isUseLocalTrustStore()));
		te.setProperty(SmtpSampler.TRUSTSTORE_TO_USE, smtpPanel.getTrustStoreToUse());
		
		te.setProperty(SmtpSampler.USE_AUTH, Boolean.toString(smtpPanel.isUseAuth()));
		te.setProperty(SmtpSampler.PASSWORD, smtpPanel.tfAuthPassword.getText());
		te.setProperty(SmtpSampler.USERNAME, smtpPanel.tfAuthUsername.getText());
		
		te.setProperty(SmtpSampler.MESSAGE_SIZE_STATS, Boolean.toString(smtpPanel.isMessageSizeStatistics()));
		te.setProperty(SmtpSampler.CHECK_FOR_FAILURE, Boolean.toString(smtpPanel.isCheckForFailure()));
	}

	/**
	 * Helper method to set up the GUI screen
	 */
	private void init() {
		// Standard setup
		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());
		add(makeTitlePanel(), BorderLayout.NORTH); // Add the standard title
		
		// Specific setup
		add(makeDataPanel(), BorderLayout.CENTER);
	}

	/**
	 * Creates a sampler-gui-object, singleton-method
	 * @return SmtpPanel-object
	 * @return Panel for entering the data
	 */
	private Component makeDataPanel() {
		if (smtpPanel == null)
			smtpPanel = new SmtpPanel();	
		return smtpPanel;
	}
}