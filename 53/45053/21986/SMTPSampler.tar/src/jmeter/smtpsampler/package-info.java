/**
* Main package of JMeter-SMTP-Sampler. 
*  
* @since 1.0
*/
package jmeter.smtpsampler;
