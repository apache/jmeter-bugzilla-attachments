/**
* This package holds every classes concerning protocols, building messages, 
* transmitting messages and similar. 
*  
* @since 1.0
*/
package jmeter.smtpsampler.protocol;