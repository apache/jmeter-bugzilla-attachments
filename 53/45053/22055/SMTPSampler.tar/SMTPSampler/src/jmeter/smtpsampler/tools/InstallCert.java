/*
 * Copyright 2006 Sun Microsystems, Inc.  All Rights Reserved.
 * This source has been modified by Michael Tschannen, 2008@InIT, ZHAW 
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of Sun Microsystems nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package jmeter.smtpsampler.tools;

import java.io.*;

import java.security.*;
import java.security.cert.*;

import javax.net.ssl.*;

/**
 * Helper-class used to install server-certificate on-the-fly. 
 * This class provides methods to fetch the server-certificate and to put it in a local truststore, which can be used to avoid SSL-Exceptions.  
 *
 * @author  SUN / Michael Tschannen
 * @version 1.0
 */

public class InstallCert {
	private String host;
	private String filename;
	private int port;
	private char[] passphrase;
	private KeyStore ks;
	private SavingTrustManager tm;
	private X509Certificate[] chain;
	
	/**
	 * Standard-constructor
	 * 
	 * @param args Host- and port-settings. Format <host>[:port]
	 * @param filename Path to truststore used to safe server-certificate
	 * @param pw Password used to protect truststore
	 */
	public InstallCert(String args, String filename, String pw) {
		String[] c = args.split(":");
		host = c[0];
		port = (c.length == 1) ? 443 : Integer.parseInt(c[1]);
		this.filename = filename;
		String p = pw;
		this.passphrase = p.toCharArray();
	}
	
	/**
	 * 
	 * Main-method, performs all tasks necessary to build the new truststore: <br />
	 * - fetches server-certificate <br />
	 * - sets up local truststore <br />
	 * - includes server-certificate in local truststore <br />
	 * - returns if task has been successful  
	 * 
	 * @return Boolean value if truststore has been successfully set up
	 * @throws Exception
	 */
	public boolean buildCertStore() throws Exception {
		try {
			File file = new File(filename);
			if (file.isFile() == false) {
			    char SEP = File.separatorChar;
			    File dir = new File(System.getProperty("java.home") + SEP + "lib" + SEP + "security");
			    file = new File(dir, filename);
			    if (file.isFile() == false) {
			    	file = new File(dir, "cacerts");
			    }
			}
			InputStream in = new FileInputStream(file);
			ks = KeyStore.getInstance(KeyStore.getDefaultType());
			ks.load(in, passphrase);
			in.close();
		}
		catch (Exception ex) {
			System.out.println("Could not open new keystore");
			ex.printStackTrace(System.out);
			return false;
		}
		
		SSLContext context = SSLContext.getInstance("TLS");
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(ks);
		X509TrustManager defaultTrustManager = (X509TrustManager)tmf.getTrustManagers()[0];
		tm = new SavingTrustManager(defaultTrustManager);
		context.init(null, new TrustManager[] {tm}, null);
		SSLSocketFactory factory = context.getSocketFactory();
		
		SSLSocket socket = (SSLSocket)factory.createSocket(host, port);
		socket.setSoTimeout(1000);
		
		try {
			socket.startHandshake();
		    System.out.println("No errors, certificate is already trusted");
		    return true;
		}
		catch (SSLException ex) {
			System.out.println("Certificate not trustet at the moment - wanted exception, I'll go further...");
		} 
		finally {
			socket.close();
			socket = null;
		}
		
		chain = tm.chain;
		if (chain == null) {
		    System.out.println("Could not obtain server certificate chain");
		    return false;
		}

		try {
			OutputStream out = new FileOutputStream(filename);
			for (int i = 0; i < chain.length; i++) {
				X509Certificate cert = chain[i];
				String alias = host + "-" + (i + 1);
				ks.setCertificateEntry(alias, cert);
				ks.store(out, passphrase);			
			}
			out.close();
		}
		catch (Exception ex) {
			System.out.println("Could not store new keystore");
			ex.printStackTrace(System.out);
			return false;
		}
		
		System.out.println("Certificate(s) successfully added to keystore.");
		return true;
    }
	
    private static final char[] HEXDIGITS = "0123456789abcdef".toCharArray();

    /**
     * Helper-method, converts byte-array to hexString
     * 
     * @param bytes Byte-array to be converted
     * @return HexString of byte-array
     */
    private static String toHexString(byte[] bytes) {
	StringBuilder sb = new StringBuilder(bytes.length * 3);
		for (int b : bytes) {
			b &= 0xff;
			sb.append(HEXDIGITS[b >> 4]);
			sb.append(HEXDIGITS[b & 15]);
			sb.append(' ');
		}
		return sb.toString();
    }

    /**
     * Helper-class used to set up certificate-trust
     * 
     * @author SUN
     * @version 1.0
     *
     */
    private static class SavingTrustManager implements X509TrustManager {

    	private final X509TrustManager tm;
    	private X509Certificate[] chain;

    	/**
    	 * Standard-constructor
    	 * 
    	 * @param tm TrustManager to be processed
    	 */
    	SavingTrustManager(X509TrustManager tm) {
    		this.tm = tm;
    	}

    	/* (non-Javadoc)
    	 * @see javax.net.ssl.X509TrustManager#getAcceptedIssuers()
    	 */
    	public X509Certificate[] getAcceptedIssuers() {
    		throw new UnsupportedOperationException();
    	}

    	/* (non-Javadoc)
    	 * @see javax.net.ssl.X509TrustManager#checkClientTrusted(java.security.cert.X509Certificate[], java.lang.String)
    	 */
    	public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
    		throw new UnsupportedOperationException();
    	}

    	/* (non-Javadoc)
    	 * @see javax.net.ssl.X509TrustManager#checkServerTrusted(java.security.cert.X509Certificate[], java.lang.String)
    	 */
    	public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
    		this.chain = chain;
    		tm.checkServerTrusted(chain, authType);
    	}
    }

}