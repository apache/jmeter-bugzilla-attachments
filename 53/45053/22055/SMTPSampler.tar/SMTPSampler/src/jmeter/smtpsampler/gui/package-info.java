/**
* This package holds every classes in relation with the gui or gui-components.  
*  
* @since 1.0
*/
package jmeter.smtpsampler.gui;