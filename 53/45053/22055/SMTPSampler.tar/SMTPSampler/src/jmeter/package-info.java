/**
* Main package of JMeter-Sampler, 
* additional sampler should be placed here in additional folders / packages. 
*  
* @since 1.0
*/
package jmeter;