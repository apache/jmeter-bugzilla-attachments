CREATE TABLE tests (
  uuid bigint(20) NOT NULL,
  startdate varchar(50) COLLATE utf8_bin NOT NULL,
  tagname varchar(255) COLLATE utf8_bin NOT NULL,
  project varchar(255) COLLATE utf8_bin NOT NULL,
  status varchar(45) COLLATE utf8_bin NOT NULL,
  environment varchar(255) COLLATE utf8_bin DEFAULT NULL,
  duration varchar(50) COLLATE utf8_bin DEFAULT NULL,
  comment varchar(400) COLLATE utf8_bin DEFAULT NULL,
  accepted varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (uuid)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE results (
  id bigint(20) NOT NULL,
  testuuid bigint(20) NOT NULL,
  timestamp varchar(50) COLLATE utf8_bin DEFAULT NULL,
  elapsed varchar(50) COLLATE utf8_bin DEFAULT NULL,
  label varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  responsecode varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  responsemessage varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  threadname varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  datatype varchar(50) COLLATE utf8_bin DEFAULT NULL,
  success varchar(50) COLLATE utf8_bin DEFAULT NULL,
  failuremessage varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  bytes varchar(50) COLLATE utf8_bin DEFAULT NULL,
  grpthreads varchar(50) COLLATE utf8_bin DEFAULT NULL,
  allthreads varchar(50) COLLATE utf8_bin DEFAULT NULL,
  url varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  filename varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  latency varchar(50) COLLATE utf8_bin DEFAULT NULL,
  encoding varchar(50) COLLATE utf8_bin DEFAULT NULL,
  samplecount varchar(50) COLLATE utf8_bin DEFAULT NULL,
  errorcount varchar(50) COLLATE utf8_bin DEFAULT NULL,
  hostname varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  idletime varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (id,testuuid),
  KEY testuuid (testuuid)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
