package com.sky.ocp.jmeter.service.api;

import java.sql.Connection;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sky.ocp.jmeter.service.dao.AddTestDao;
import com.sky.ocp.jmeter.service.db.DatabaseManager;
import com.sky.ocp.jmeter.service.db.UpdateHandler;
import com.sky.ocp.jmeter.service.util.JsonProcessor;

@Path("/addTest")
public class AddTest {

	private static Logger log = Logger.getLogger(AddTest.class);
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public String post(String body) {
		log.debug("Recieved request body: " + body);
		JSONObject jsonResponse = new JSONObject();
		String response;
		try {
			AddTestDao addTestDao = new AddTestDao(JsonProcessor.parseAddTestRequest(body));
			addTestDao.processData();
			if(addTestDao.getModel().getErrors().size() > 0)
				response = addTestDao.getModel().getErrors().get(0);
			else
				response = "Test creation successful";
			response = jsonResponse.toString();
		} catch(JSONException e) {
			log.error(e);
			response = e.getMessage();
		}
		return response;
	}
	
	@GET
	@Path("setDuration/{uuid}")
	public String setDuration(@PathParam("uuid") long uuid) {
		log.debug("Recieved setDuration request for Test UUID: " + uuid);
		String response = "Duration set!";
		Connection conn = null;
		try {
			if(uuid > 0) {
				conn = DatabaseManager.getConnection();
				UpdateHandler.updateTestDuration(conn, uuid);
			} else {
				response = "Invalid uuid";
			}
		} catch(Exception e) {
			response = "Error setting duration: "+e.getMessage();
			log.error(e);
		} finally {
			DatabaseManager.closeConnection(conn);
		}
		return response;
	}
	
	@GET
	public String get() {
		return "Endpoint is available!";
	}
	
}
