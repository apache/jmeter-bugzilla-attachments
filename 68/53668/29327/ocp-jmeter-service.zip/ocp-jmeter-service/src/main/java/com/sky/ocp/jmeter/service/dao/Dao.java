package com.sky.ocp.jmeter.service.dao;

import com.sky.ocp.jmeter.service.model.Model;

public interface Dao {
	public Model getModel();
	public void processData();
}
