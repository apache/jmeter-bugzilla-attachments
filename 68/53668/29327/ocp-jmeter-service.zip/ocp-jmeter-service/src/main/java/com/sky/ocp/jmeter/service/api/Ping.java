package com.sky.ocp.jmeter.service.api;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Path("/ping")
public class Ping {

	public static final String REPLY = "OCP JMeter service is running!"; 
	
	@POST
	public String post() {
		return REPLY;
	}
	
	@GET
	public String get() {
		return REPLY;
	}
}
