package com.sky.ocp.jmeter.service.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.sky.ocp.jmeter.service.util.ResourceUtils;

public class DatabaseManager {
	
	private static Logger log = Logger.getLogger(DatabaseManager.class);
	
	private static int connectionCount = 0;
	
	public enum DatabaseType{ MYSQL, ORACLE } 
	
	public static Connection getConnection() throws DatabaseConnectionException {
		Connection conn = null;
		try {
			
			if(DatabaseType.MYSQL.toString().equalsIgnoreCase(ResourceUtils.getDatabaseType()))
				Class.forName("com.mysql.jdbc.Driver").newInstance();
			else if(DatabaseType.ORACLE.toString().equalsIgnoreCase(ResourceUtils.getDatabaseType()))
				Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
			else
				throw new DatabaseConnectionException("Invalid database.type in WebResource: " + ResourceUtils.getDatabaseType());
			
			String databaseUrl = ResourceUtils.getDatabaseConnectionString();
			conn = DriverManager.getConnection(databaseUrl);
			connectionCount++;
			log.debug("Database connections open: "  + connectionCount);
			
		} catch(SQLException e) {
			throw new DatabaseConnectionException(e);
		} catch (InstantiationException e) {
			throw new DatabaseConnectionException(e);
		} catch (IllegalAccessException e) {
			throw new DatabaseConnectionException(e);
		} catch (ClassNotFoundException e) {
			throw new DatabaseConnectionException(e);
		}
		return conn;
	}
	
	public static void closeConnection(Connection conn) {
		if(conn != null) {
			try {
				conn.close();
				connectionCount--;
				log.debug("Database connections open: "  + connectionCount);
			} catch (SQLException e) {
				log.error("Problem closing database connection: " + e.getMessage(), e);
			}
		}
	}
	
	public static void closeStatement(Statement stmt) {
		if(stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				log.error("Problem closing database statement: " + e.getMessage(), e);
			}
		}
	}
	
	public static void closeResultSet(ResultSet rs) {
		if(rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				log.error("Problem closing database result set: " + e.getMessage(), e);
			}
		}
	}
	
	public static int getConnectionCount() {
		return connectionCount;
	}
}
