package com.sky.ocp.jmeter.service.util;

import java.util.Locale;
import java.util.ResourceBundle;

public class ResourceUtils {

	private static Locale enGBLocale = new Locale("en", "GB");
	private static ResourceBundle webResource = ResourceBundle.getBundle("WebResource", enGBLocale);
	
	private static final String KEY_DATABASE_TYPE = "database.type";
	private static final String KEY_DATABASE_CONN_STRING = "database.connection.string";
	
	public static ResourceBundle getWebResource() {
		return webResource;
	}
	
	public static String getDatabaseType() {
		return webResource.getString(KEY_DATABASE_TYPE).toUpperCase();
	}
	
	public static String getDatabaseConnectionString() {
		return webResource.getString(KEY_DATABASE_CONN_STRING);
	}
}
