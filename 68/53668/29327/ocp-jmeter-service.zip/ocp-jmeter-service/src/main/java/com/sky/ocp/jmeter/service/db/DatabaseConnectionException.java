package com.sky.ocp.jmeter.service.db;

public class DatabaseConnectionException extends Exception {

	private static final long serialVersionUID = 2563249625587899987L;

	public DatabaseConnectionException() { }

	public DatabaseConnectionException(String arg0) {
		super(arg0);
	}

	public DatabaseConnectionException(Throwable arg0) {
		super(arg0);
	}

	public DatabaseConnectionException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public DatabaseConnectionException(String arg0, Throwable arg1,
			boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

}
