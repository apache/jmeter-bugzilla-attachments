package com.sky.ocp.jmeter.service.util;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sky.ocp.jmeter.service.model.AddResultsModel;
import com.sky.ocp.jmeter.service.model.AddTestModel;
import com.sky.ocp.jmeter.service.model.ResultBean;

public class JsonProcessor {

	private static Logger log = Logger.getLogger(JsonProcessor.class);
	
	public static AddResultsModel parseAddResultsRequest(String jsonString) throws JSONException {
		
		JSONObject jsonData = new JSONObject(jsonString);
		AddResultsModel addResultsModel = new AddResultsModel();
		addResultsModel.setTestUuid(Long.parseLong(jsonData.getString("testUuid")));
		try {
			JSONArray results = (JSONArray)jsonData.get("results");
			for(int i=0; i < results.length(); i++) {
				ResultBean result = new ResultBean();
				result.setId(Long.parseLong(((JSONObject)results.get(i)).getString("id")));
				result.setAllThreads(((JSONObject)results.get(i)).getString("allt"));
				result.setBytes(((JSONObject)results.get(i)).getString("by"));
				result.setElapsed(((JSONObject)results.get(i)).getString("elap"));
				result.setErrorCount(((JSONObject)results.get(i)).getString("ec"));
				result.setGrpThreads(((JSONObject)results.get(i)).getString("grpt"));
				result.setIdleTime(((JSONObject)results.get(i)).getString("it"));
				result.setLatency(((JSONObject)results.get(i)).getString("lat"));
				result.setSampleCount(((JSONObject)results.get(i)).getString("sc"));
				result.setTimeStamp(((JSONObject)results.get(i)).getString("ts"));
				result.setDataType(((JSONObject)results.get(i)).getString("dt"));
				result.setSuccess(((JSONObject)results.get(i)).getString("suc"));
				result.setEncoding(((JSONObject)results.get(i)).getString("enc"));
				result.setFailureMessage(((JSONObject)results.get(i)).getString("fm"));
				result.setFilename(((JSONObject)results.get(i)).getString("file"));
				result.setHostname(((JSONObject)results.get(i)).getString("host"));
				result.setLabel(((JSONObject)results.get(i)).getString("label"));
				result.setResponseCode(((JSONObject)results.get(i)).getString("rc"));
				result.setResponseMessage(((JSONObject)results.get(i)).getString("rm"));
				result.setThreadName(((JSONObject)results.get(i)).getString("tn"));
				result.setUrl(((JSONObject)results.get(i)).getString("url"));
				addResultsModel.addResult(result);
			}
		} catch(JSONException e) {
			log.error("Error parsing addResults request: "+ e.getMessage());
		}
		addResultsModel.log();
		return addResultsModel;
	}
	
	
	public static AddTestModel parseAddTestRequest(String jsonString) throws JSONException {
		JSONObject jsonData = new JSONObject(jsonString);
		AddTestModel addTestModel = new AddTestModel();
		try {
			addTestModel.setAccepted(jsonData.getString("accepted"));
			addTestModel.setComment(jsonData.getString("comment"));
			addTestModel.setDuration(jsonData.getString("duration"));
			addTestModel.setEnvironment(jsonData.getString("environment"));
			addTestModel.setProject(jsonData.getString("project"));
			addTestModel.setStartDate(jsonData.getString("startdate"));
			addTestModel.setStatus(jsonData.getString("status"));
			addTestModel.setTagName(jsonData.getString("tagname"));
			addTestModel.setUuid(Long.parseLong(jsonData.getString("uuid")));
		} catch(JSONException e) {
			log.error("Error parsing addTest request: "+ e.getMessage());
		}
		addTestModel.log();
		return addTestModel;
	}
}
