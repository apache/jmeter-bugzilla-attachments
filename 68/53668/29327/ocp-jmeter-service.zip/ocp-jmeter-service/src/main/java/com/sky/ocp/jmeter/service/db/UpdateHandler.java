package com.sky.ocp.jmeter.service.db;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.apache.log4j.Logger;


public class UpdateHandler {

	private static Logger log = Logger.getLogger(InsertHandler.class);
	
	public static int updateTestDuration(Connection conn, long uuid) throws Exception {
		int updatedResults = 0;
		StringBuilder sqlUpdate = new StringBuilder();
		sqlUpdate.append("update tests set duration = (select (max(timestamp) - min(timestamp)) from results where testuuid = ?) ");
		sqlUpdate.append("where uuid = ? ");
		PreparedStatement pStmt = null;
		try {
			pStmt = conn.prepareStatement(sqlUpdate.toString());
			pStmt.setLong(1, uuid);
			pStmt.setLong(2, uuid);
			updatedResults += pStmt.executeUpdate();
			log.debug("JMeter Test[UUID:"+uuid+"] rows updated: " + updatedResults);
		} finally {
			DatabaseManager.closeStatement(pStmt);
		}
		return updatedResults;
	}
	
}
