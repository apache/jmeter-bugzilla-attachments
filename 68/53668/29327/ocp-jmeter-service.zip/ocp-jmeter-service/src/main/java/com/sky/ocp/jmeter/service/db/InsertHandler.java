package com.sky.ocp.jmeter.service.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.sky.ocp.jmeter.service.model.AddResultsModel;
import com.sky.ocp.jmeter.service.model.AddTestModel;
import com.sky.ocp.jmeter.service.model.ResultBean;

public class InsertHandler {
	
	private static Logger log = Logger.getLogger(InsertHandler.class);
	
	public static int insertResults(Connection conn, AddResultsModel addResultsModel) throws SQLException {
		int savedResults = 0;
		StringBuilder sqlInsert = new StringBuilder();
		sqlInsert.append("insert into results(testUuid, id, allthreads, bytes, elapsed, errorcount, grpthreads, idletime, latency, samplecount, timestamp, datatype, success, encoding, failuremessage, filename, hostname, label, responsecode, responsemessage, threadname, url) ");
		sqlInsert.append("values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		PreparedStatement pStmt = null;
		try {
			pStmt = conn.prepareStatement(sqlInsert.toString());
			for(ResultBean result : addResultsModel.getResults()) {
				try {
					pStmt.setLong(1, addResultsModel.getTestUuid());
					pStmt.setLong(2, result.getId());
					pStmt.setString(3, result.getAllThreads());
					pStmt.setString(4, result.getBytes());
					pStmt.setString(5, result.getElapsed());
					pStmt.setString(6, result.getErrorCount());
					pStmt.setString(7, result.getGrpThreads());
					pStmt.setString(8, result.getIdleTime());
					pStmt.setString(9, result.getLatency());
					pStmt.setString(10, result.getSampleCount());
					pStmt.setString(11, result.getTimeStamp());
					pStmt.setString(12, result.getDataType());
					pStmt.setString(13, result.getSuccess());
					pStmt.setString(14, result.getEncoding());
					pStmt.setString(15, result.getFailureMessage());
					pStmt.setString(16, result.getFilename());
					pStmt.setString(17, result.getHostname());
					pStmt.setString(18, result.getLabel());
					pStmt.setString(19, result.getResponseCode());
					pStmt.setString(20, result.getResponseMessage());
					pStmt.setString(21, result.getThreadName());
					pStmt.setString(22, result.getUrl());
					savedResults += pStmt.executeUpdate();
				} catch (Exception e) {
					log.error("Unable to insert Result[id:"+result.getId()+"] for Test[UUID:"+addResultsModel.getTestUuid()+"] "+e.getMessage());
					log.error(e);
				}
			}
			log.debug("JMeter results inserted into database: " + savedResults);
		} finally {
			DatabaseManager.closeStatement(pStmt);
		}
		return savedResults;
	}
	
	public static int insertTest(Connection conn, AddTestModel addTestModel) throws SQLException {
		int savedResults = 0;
		StringBuilder sqlInsert = new StringBuilder();
		sqlInsert.append("insert into tests(uuid, startdate, tagname, project, environment, duration, comment, accepted, status) ");
		sqlInsert.append("values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
		PreparedStatement pStmt = null;
		try {
			pStmt = conn.prepareStatement(sqlInsert.toString());
			pStmt.setLong(1, addTestModel.getUuid());
			pStmt.setString(2, addTestModel.getStartDate());
			pStmt.setString(3, addTestModel.getTagName());
			pStmt.setString(4, addTestModel.getProject());
			pStmt.setString(5, addTestModel.getEnvironment());
			pStmt.setString(6, addTestModel.getDuration());
			pStmt.setString(7, addTestModel.getComment());
			pStmt.setString(8, addTestModel.getAccepted());
			pStmt.setString(9, addTestModel.getStatus());
			savedResults += pStmt.executeUpdate();
			log.debug("JMeter Test[UUID:"+addTestModel.getUuid()+"] inserted into database: " + savedResults);
		} catch (Exception e) {
			log.error(e);
			throw new SQLException("Unable to insert Test[UUID:"+addTestModel.getUuid()+"] "+e.getMessage());
		} finally {
			DatabaseManager.closeStatement(pStmt);
		}
		return savedResults;
	}
}
