package com.sky.ocp.jmeter.service.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.sky.ocp.jmeter.service.db.DatabaseConnectionException;
import com.sky.ocp.jmeter.service.db.DatabaseManager;
import com.sky.ocp.jmeter.service.db.InsertHandler;
import com.sky.ocp.jmeter.service.model.AddTestModel;

public class AddTestDao implements Dao {

private static Logger log = Logger.getLogger(AddResultsDao.class);
	
	private AddTestModel addTestModel;
	
	public AddTestDao(AddTestModel addTestModel) {
		this.addTestModel = addTestModel;
	}
	
	public AddTestModel getModel() {
		return addTestModel;
	}

	public void processData() {
		log.debug("Inserting JMeter Test into database using UUID: " + addTestModel.getUuid());
		Connection conn = null;
		try {
			conn = DatabaseManager.getConnection();
			if(addTestModel.getUuid() > 0) {
				addTestModel.setSavedResults(InsertHandler.insertTest(conn, addTestModel));
			} else 
				throw new SQLException("Test UUID unknown, database insert aborted");
		
		} catch (SQLException e) {
			log.error(e);
			addTestModel.addError(e.getMessage());
		} catch (DatabaseConnectionException e) {
			log.error(e);
			addTestModel.addError(e.getMessage());
		} finally {
			DatabaseManager.closeConnection(conn);
		}
	}

}
