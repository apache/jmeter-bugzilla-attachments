package com.sky.ocp.jmeter.service.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class AddTestModel implements Model, Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(AddResultsModel.class);
	
	private long uuid;
	private String startDate;
	private String tagName;
	private String project;
	private String environment;
	private String duration;
	private String comment;
	private String accepted;
	private String status;
	private int savedResults;
	private List<String> errors = new ArrayList<String>();
	
	public void log() {
		log.debug("AddTestModel[uuid:"+uuid+",startDate:"+startDate+",tagName:"+tagName+",project:"+project+",environment:"+environment+",duration:"+duration+",comment:"+comment+",accepted:"+accepted+",status:"+status+"]");
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the project
	 */
	public String getProject() {
		return project;
	}

	/**
	 * @param project the project to set
	 */
	public void setProject(String project) {
		this.project = project;
	}

	/**
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * @param environment the environment to set
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}

	/**
	 * @return the comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment the comment to set
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the accepted
	 */
	public String getAccepted() {
		return accepted;
	}

	/**
	 * @param accepted the accepted to set
	 */
	public void setAccepted(String accepted) {
		this.accepted = accepted;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the savedResults
	 */
	public int getSavedResults() {
		return savedResults;
	}

	/**
	 * @param savedResults the savedResults to set
	 */
	public void setSavedResults(int savedResults) {
		this.savedResults = savedResults;
	}

	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	/**
	 * @param error the error to set
	 */
	public void addError(String error) {
		if(errors == null) errors = new ArrayList<String>();
		this.errors.add(error);
	}

	/**
	 * @return the tagName
	 */
	public String getTagName() {
		return tagName;
	}

	/**
	 * @param tagName the tagName to set
	 */
	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	/**
	 * @return the uuid
	 */
	public long getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(long uuid) {
		this.uuid = uuid;
	}
}
