package com.sky.ocp.jmeter.service.model;

public interface Model {
	
	/**
	 * Write contents of object to log.
	 */
	public void log();

}
