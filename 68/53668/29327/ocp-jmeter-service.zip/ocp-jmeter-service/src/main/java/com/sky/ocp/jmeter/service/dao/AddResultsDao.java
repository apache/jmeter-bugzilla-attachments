package com.sky.ocp.jmeter.service.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.sky.ocp.jmeter.service.db.DatabaseConnectionException;
import com.sky.ocp.jmeter.service.db.DatabaseManager;
import com.sky.ocp.jmeter.service.db.InsertHandler;
import com.sky.ocp.jmeter.service.model.AddResultsModel;

public class AddResultsDao implements Dao {

	private static Logger log = Logger.getLogger(AddResultsDao.class);
	
	private AddResultsModel addResultsModel;
	
	public AddResultsDao(AddResultsModel addResultsModel) {
		this.addResultsModel = addResultsModel;
	}
	
	public AddResultsModel getModel() {
		return addResultsModel;
	}

	public void processData() {
		log.debug("Inserting JMeter results into database for Test UUID: " + addResultsModel.getTestUuid());
		Connection conn = null;
		try {
			conn = DatabaseManager.getConnection();
			if(addResultsModel.getTestUuid() > 0) {
				addResultsModel.setSavedResults(InsertHandler.insertResults(conn, addResultsModel));
			} else 
				throw new SQLException("Test UUID unknown, database insert aborted");
		
		} catch (SQLException e) {
			log.error(e);
			addResultsModel.addError(e.getMessage());
		} catch (DatabaseConnectionException e) {
			log.error(e);
			addResultsModel.addError(e.getMessage());
		} finally {
			DatabaseManager.closeConnection(conn);
		}
	}

}