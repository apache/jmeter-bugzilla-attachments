package com.sky.ocp.jmeter.service.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

public class AddResultsModel implements Model, Serializable {

	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(AddResultsModel.class);
	
	private long testUuid;
	private int savedResults;
	private List<ResultBean> results = new ArrayList<ResultBean>();
	private List<String> errors = new ArrayList<String>();
	
	public void log() {
		log.debug("AddResultsModel[testUuid:"+testUuid+",jmeterResults.size:"+results.size()+"]");
	}

	/**
	 * @return the errors
	 */
	public List<String> getErrors() {
		return errors;
	}

	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<String> errors) {
		this.errors = errors;
	}
	
	/**
	 * @param error the error to set
	 */
	public void addError(String error) {
		if(errors == null) errors = new ArrayList<String>();
		this.errors.add(error);
	}

	/**
	 * @return the savedResults
	 */
	public int getSavedResults() {
		return savedResults;
	}

	/**
	 * @param savedResults the savedResults to set
	 */
	public void setSavedResults(int savedResults) {
		this.savedResults = savedResults;
	}

	/**
	 * @return the results
	 */
	public List<ResultBean> getResults() {
		return results;
	}

	/**
	 * @param results the results to set
	 */
	public void setResults(List<ResultBean> results) {
		this.results = results;
	}
	
	/**
	 * @param result the result to set
	 */
	public void addResult(ResultBean result) {
		if(results == null) results = new ArrayList<ResultBean>();
		this.results.add(result);
	}

	/**
	 * @return the testUuid
	 */
	public long getTestUuid() {
		return testUuid;
	}

	/**
	 * @param testUuid the testUuid to set
	 */
	public void setTestUuid(long testUuid) {
		this.testUuid = testUuid;
	}
}
