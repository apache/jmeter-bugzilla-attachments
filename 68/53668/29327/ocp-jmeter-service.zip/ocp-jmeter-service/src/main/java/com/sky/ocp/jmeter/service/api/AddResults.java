package com.sky.ocp.jmeter.service.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.sky.ocp.jmeter.service.dao.AddResultsDao;
import com.sky.ocp.jmeter.service.util.JsonProcessor;

@Path("/addResults")
public class AddResults {

	private static Logger log = Logger.getLogger(AddResults.class);
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public String post(String body) {
		log.debug("Recieved request body: " + body);
		JSONObject jsonResponse = new JSONObject();
		String response;
		try {
			AddResultsDao addResultsDao = new AddResultsDao(JsonProcessor.parseAddResultsRequest(body));
			addResultsDao.processData();
			if(addResultsDao.getModel().getErrors().size() > 0)
				response = addResultsDao.getModel().getErrors().get(0);
			else
				response = "Upload successful";
			response = jsonResponse.toString();
		} catch (JSONException e) {
			log.error(e);
			response = e.getMessage();
		}
		return response;
	}
	
	@GET
	public String get() {
		return "Endpoint is available!";
	}
	
}
