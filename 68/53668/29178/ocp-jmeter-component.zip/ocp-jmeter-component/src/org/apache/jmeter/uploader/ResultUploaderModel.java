package org.apache.jmeter.uploader;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedList;
import java.util.Queue;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.jmeter.assertions.AssertionResult;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

public class ResultUploaderModel extends AbstractTestElement {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggingManager.getLoggerForClass();
	private static final String KEY_URL_HOST = "ResultUploaderModel.url.host";
	private static final String KEY_URL_TEST_ENDPOINT = "ResultUploaderModel.url.test.endpoint";
	private static final String KEY_URL_RESULTS_ENDPOINT = "ResultUploaderModel.url.results.endpoint";
	private static final String KEY_INTERVAL = "ResultUploaderModel.interval";
	private static final String KEY_TAGNAME = "ResultUploaderModel.tagname";
	private static final String KEY_PROJECT = "ResultUploaderModel.project";
	private static final String KEY_ENV = "ResultUploaderModel.env";
	private static final String KEY_COMMENT = "ResultUploaderModel.comment";
	
    private transient ChangeListener changeListener;
	private Queue<ResultBean> resultsQueue;
	private long resultCounter;
	
	public ResultUploaderModel() {
		super();
		resultsQueue = new LinkedList<ResultBean>();
		resultCounter = 1;
	}
	
    public void addChangeListener(ChangeListener listener) {
        changeListener = listener;
    }
    
    @Override
    public Object clone() {
    	ResultUploaderModel model = (ResultUploaderModel) super.clone();
        model.changeListener = changeListener;
        return model;
    }
    
    @Override
    public synchronized void clear() {
        notifyChangeListeners();
    }
    
    @Override
    public String toString() {
        return "Result Uploader";
    }
    
    public void notifyChangeListeners() {
        if (changeListener != null) {
            changeListener.stateChanged(new ChangeEvent(this));
        }
    }
	
    public synchronized void add(SampleResult result, String hostname) {
    	resultsQueue.offer(generateResult(result, hostname));
	}
    
	public synchronized void add(SampleEvent event) {
		add(event.getResult(), event.getHostname());
	}
	
	/**
	 * POST JSON results to URL.
	 * 
	 * @param url
	 * @param jsonContent
	 * @return
	 */
    public String postJSONToURL(String url, String jsonContent) {
    	log.info("POST to URL: " + url);
    	try {
    		PostMethod method = new PostMethod(url);
    		method.setRequestEntity(new StringRequestEntity(jsonContent, "application/json", "utf-8"));
    		HttpClient client = new HttpClient();
    		client.getParams().setParameter(HttpClientParams.SO_TIMEOUT, 5000); // 5 seconds
    		log.info("JSON content: " + jsonContent);
    		int statusCode = client.executeMethod(method);
    		log.info("Status code: " + statusCode);
    		StringWriter writer = new StringWriter();
    		InputStream in = method.getResponseBodyAsStream();
    		IOUtils.copy(in, writer, "utf-8");
    		return writer.toString();
    	} catch(UnsupportedEncodingException e) {
    		log.error("Encoding error: " + e.getMessage());
    		return "Encoding error: "+e.getMessage();
    	} catch (HttpException e) {
			log.error("HTTP error: " + e.getMessage());
			return "HTTP error: "+e.getMessage();
		} catch (IOException e) {
			log.error("IO error: " + e.getMessage());
			return "IO error: "+e.getMessage();
		}
    }
    
    public String callSetDurationURL(String url, long uuid) {
    	log.info("POST to URL: " + url);
    	try {
    		GetMethod method = new GetMethod(url+"/setDuration/"+uuid);
    		HttpClient client = new HttpClient();
    		client.getParams().setParameter(HttpClientParams.SO_TIMEOUT, 5000);
    		int statusCode = client.executeMethod(method);
    		log.info("Status code: " + statusCode);
    		StringWriter writer = new StringWriter();
    		InputStream in = method.getResponseBodyAsStream();
    		IOUtils.copy(in, writer, "utf-8");
    		return writer.toString();
    	} catch(UnsupportedEncodingException e) {
    		log.error("Encoding error: " + e.getMessage());
    		return "Encoding error: "+e.getMessage();
    	} catch (HttpException e) {
			log.error("HTTP error: " + e.getMessage());
			return "HTTP error: "+e.getMessage();
		} catch (IOException e) {
			log.error("IO error: " + e.getMessage());
			return "IO error: "+e.getMessage();
		}
    }
	
	/**
	 * Test host URL.
	 * 
	 * @return
	 * @throws InvalidUploadUrlException
	 */
	public String testUrl(String testUrl) throws InvalidUploadUrlException {
		StringBuilder response = new StringBuilder();
		log.info("Testing URL: " + testUrl);
		HttpURLConnection conn = null;
		try {
			URL url = new URL(testUrl);
	        conn = (HttpURLConnection) url.openConnection();
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-type", "text/plain"); 
	        conn.setConnectTimeout(5000);
	        conn.setDoOutput(true);
	        int code = conn.getResponseCode();
	        if(code == 200) {
	        	InputStream in = conn.getInputStream();
	        	StringWriter writer = new StringWriter();
	        	IOUtils.copy(in, writer, "utf-8");
	        	response.append("Success: " + writer.toString());
	        }
	        else throw new InvalidUploadUrlException("Response code " + code);
		} catch(Exception e) {
			log.info(e.getMessage());
			throw new InvalidUploadUrlException("Failed: " + e.getMessage());
		}
		return response.toString();
	}
	
	public void setUrlHost(String urlHost) {
		setProperty(KEY_URL_HOST, urlHost);
	}
	
	public String getUrlHost() {
		 return getPropertyAsString(KEY_URL_HOST);
	}
	
	public void setResultsEndpoint(String endpoint) {
		setProperty(KEY_URL_RESULTS_ENDPOINT, endpoint);
	}
	
	public String getResultsEndpoint() {
		 return getPropertyAsString(KEY_URL_RESULTS_ENDPOINT);
	}
	
	public void setTestEndpoint(String endpoint) {
		setProperty(KEY_URL_TEST_ENDPOINT, endpoint);
	}
	
	public String getTestEndpoint() {
		 return getPropertyAsString(KEY_URL_TEST_ENDPOINT);
	}
	
	public void setComment(String comment) {
		setProperty(KEY_COMMENT, comment);
	}
	
	public String getComment() {
		 return getPropertyAsString(KEY_COMMENT);
	}
	
	public void setProject(String project) {
		setProperty(KEY_PROJECT, project);
	}
	
	public String getProject() {
		 return getPropertyAsString(KEY_PROJECT);
	}
	
	public void setEnv(String env) {
		setProperty(KEY_ENV, env);
	}
	
	public String getEnv() {
		 return getPropertyAsString(KEY_ENV);
	}
	
	public void setInterval(String interval) {
		setProperty(KEY_INTERVAL, interval);
	}
	
	public String getInterval() {
		 return getPropertyAsString(KEY_INTERVAL);
	}
	
	public void setTagName(String tagName) {
		setProperty(KEY_TAGNAME, tagName);
	}
	
	public String getTagName() {
		 return getPropertyAsString(KEY_TAGNAME);
	}
	
	public Queue<ResultBean> getResultsQueue() {
		return resultsQueue;
	}
	
    // Set results in same column order as JMeter (see: http://jmeter.apache.org/usermanual/listeners.html)
    private ResultBean generateResult(SampleResult result, String hostname) {
    	ResultBean resultBean = new ResultBean();
    	resultBean.setId(resultCounter++);
    	resultBean.setTimeStamp(getValue(""+result.getTimeStamp()));
    	resultBean.setElapsed(getValue(""+result.getTime()));
    	resultBean.setLabel(getValue(result.getSampleLabel()));
    	resultBean.setResponseCode(getValue(result.getResponseCode()));
    	resultBean.setResponseMessage(getValue(result.getResponseMessage()));
    	resultBean.setThreadName(getValue(result.getThreadName()));
    	resultBean.setDataType(getValue(result.getDataType()));
    	resultBean.setSuccess(getValue(""+result.isSuccessful()));
    	if(result.getAssertionResults() != null && result.getAssertionResults().length > 0) {
    		StringBuilder failures = new StringBuilder();
    		for(AssertionResult ar : result.getAssertionResults()) 
    			failures.append(ar.getFailureMessage()+",");
    		resultBean.setFailureMessage(failures.toString());
    	} else {
    		resultBean.setFailureMessage("");
    	}
    	resultBean.setBytes(getValue(""+result.getBytes()));
    	resultBean.setGrpThreads(getValue(""+result.getGroupThreads()));
    	resultBean.setAllThreads(getValue(""+result.getAllThreads()));
    	resultBean.setUrl(getValue(""+result.getUrlAsString()));
    	resultBean.setFilename(getValue(result.getResultFileName()));
    	resultBean.setLatency(getValue(""+result.getLatency()));
    	resultBean.setEncoding(getValue(result.getDataEncodingWithDefault()));
    	resultBean.setSampleCount(getValue(""+result.getSampleCount()));
    	resultBean.setErrorCount(getValue(""+result.getErrorCount()));
    	resultBean.setHostname(hostname);
    	resultBean.setIdleTime(getValue(""+result.getIdleTime()));
    	//resultBean.log();
    	return resultBean;
    }
    
    private String getValue(String value) {
    	if(StringUtils.isNotBlank(value)) return value;
    	else return "";
    }

}
