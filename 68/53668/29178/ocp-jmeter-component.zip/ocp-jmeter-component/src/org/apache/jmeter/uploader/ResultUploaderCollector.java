package org.apache.jmeter.uploader;

import java.util.GregorianCalendar;
import java.util.Queue;
import java.util.TimeZone;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ResultUploaderCollector extends ResultCollector {

	public static final String RESULT_UPLOADER_MODEL = "ResultUploaderCollector.resultUploaderModel";
	
	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggingManager.getLoggerForClass();
	private Timer timer;
	private int queueCounter;
	private long uuid;
	private String hostURL;
	private String addResultsEndpoint;
	private String addTestEndpoint;
	private long startdate;
	private String tagName;
	private String project;
	private String environment;
	private String comment;
	
	public ResultUploaderCollector() {
		super();
		setProperty(new TestElementProperty(RESULT_UPLOADER_MODEL, new ResultUploaderModel()));
	}
	
	@Override
	public void testStarted(String host) {
		queueCounter = 0;
		UUID actualUUID = UUID.randomUUID();
		uuid = Math.abs((actualUUID.getMostSignificantBits()));
		hostURL = getResultUploaderModel().getUrlHost();
		addResultsEndpoint = getResultUploaderModel().getResultsEndpoint();
		addTestEndpoint = getResultUploaderModel().getTestEndpoint();
		startdate = new GregorianCalendar(TimeZone.getTimeZone("GB")).getTimeInMillis();
		tagName = getResultUploaderModel().getTagName();
		project = getResultUploaderModel().getProject();
		environment = getResultUploaderModel().getEnv();
		comment = getResultUploaderModel().getComment();
		int interval = (Integer.parseInt(getResultUploaderModel().getInterval()) * 1000); 
		
		log.info("UUID: " + uuid);
		log.info("Host URL: " + hostURL);
		log.info("Results Endpoint: " + addResultsEndpoint);
		log.info("Test Endpoint: " + addTestEndpoint);
		log.info("Start Time: " + startdate + " millis");
		log.info("Project: " + project);
		log.info("Environment: " + environment);
		log.info("Tag: " + tagName);
		log.info("Comment: " + comment);
		log.info("Interval: " + interval + " millis");
		
		registerNewTest();
		
		timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				log.info("Processing results on queue...");
				processResults(getResultUploaderModel().getResultsQueue());
			}
		}, interval, interval);
	}
	
    @Override
    public void sampleOccurred(SampleEvent event) {
    	super.sampleOccurred(event);
    	getResultUploaderModel().add(event);
    }
    
    @Override
    public void testEnded(String host) {
    	if(!getResultUploaderModel().getResultsQueue().isEmpty()) {
    		log.info("Processing remaining results on queue...");
    		processResults(getResultUploaderModel().getResultsQueue());
    	}
    	timer.cancel();
    	log.info("Queue scheduler gracefully terminated");
    	log.info("Results processed: " + queueCounter);
    	setTestDuration();
    }

    @Override
    public void clear() {
        super.clear();
        setProperty(new TestElementProperty(RESULT_UPLOADER_MODEL, new ResultUploaderModel()));
    }
    
    public ResultUploaderModel getResultUploaderModel() {
        return (ResultUploaderModel) getProperty(RESULT_UPLOADER_MODEL).getObjectValue();
    }
    
    private void setTestDuration() {
    	if(queueCounter > 0 && uuid > 0) {
    		log.info("Final step, setting test duration...");
    		log.info(getResultUploaderModel().callSetDurationURL((hostURL+addTestEndpoint), uuid));
    	}
    }
    
    private void registerNewTest() {
    	JSONObject jsonData = new JSONObject();
    	try {
    		jsonData.put("uuid", uuid);
    		jsonData.put("startdate", startdate);
    		jsonData.put("tagname", tagName);
    		jsonData.put("project", project);
    		jsonData.put("status", 1);
    		jsonData.put("environment", environment);
    		jsonData.put("duration", "");
    		jsonData.put("comment", comment);
    		jsonData.put("accepted", "N");
			getResultUploaderModel().postJSONToURL((hostURL+addTestEndpoint), jsonData.toString());
		} catch (JSONException e) {
			log.error("Error registering new test: " + e.getMessage());
		}
    }
    
    private void processResults(Queue<ResultBean> queue) {
    	if(!queue.isEmpty()) { 
	    	JSONObject jsonData = new JSONObject();
	    	try {
		    	jsonData.put("testUuid", uuid);
		    	JSONArray jsonArray = new JSONArray();
		    	while(!queue.isEmpty()) {
		    		ResultBean result = queue.poll();
					JSONObject jsonResult = new JSONObject();
					jsonResult.put("id", result.getId());
					jsonResult.put("allt", result.getAllThreads());
					jsonResult.put("by", result.getBytes());
					jsonResult.put("elap", result.getElapsed());
					jsonResult.put("ec", result.getErrorCount());
					jsonResult.put("grpt", result.getGrpThreads());
					jsonResult.put("it", result.getIdleTime());
					jsonResult.put("lat", result.getLatency());
					jsonResult.put("sc", result.getSampleCount());
					jsonResult.put("ts", result.getTimeStamp());
					jsonResult.put("dt", result.getDataType());
					jsonResult.put("suc", result.getSuccess());
					jsonResult.put("enc", result.getEncoding());
					jsonResult.put("fm", result.getFailureMessage());
					jsonResult.put("file", result.getFilename());
					jsonResult.put("host", result.getHostname());
					jsonResult.put("label", result.getLabel());
					jsonResult.put("rc", result.getResponseCode());
					jsonResult.put("rm", result.getResponseMessage());
					jsonResult.put("tn", result.getThreadName());
					jsonResult.put("url", result.getUrl());
					jsonArray.put(jsonResult);
					queueCounter++;
		    	}
		    	jsonData.put("results", jsonArray);
		    	getResultUploaderModel().postJSONToURL((hostURL+addResultsEndpoint), jsonData.toString());
			} catch (JSONException e) {
				log.error("Error processing results for Test [UUID:"+uuid+"]: " + e.getMessage());
			}
    	}
    }

}
