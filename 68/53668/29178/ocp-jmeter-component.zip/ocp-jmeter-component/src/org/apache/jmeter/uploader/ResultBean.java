package org.apache.jmeter.uploader;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

public class ResultBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggingManager.getLoggerForClass();
	
	private long id;
	private String timeStamp; // in milliseconds since 1/1/1970
	private String elapsed; // in milliseconds
	private String label; // sampler label
	private String responseCode; // e.g. 200, 400
	private String responseMessage; // e.g. OK
	private String threadName;
	private String dataType; // e.g. text
	private String success;
	private String failureMessage; // if any
	private String bytes; // number of bytes in the sample
	private String grpThreads; // number of active threads in this thread group
	private String allThreads; // total number of active threads in all groups 
	private String url;
	private String filename; // if Save Response to File was used
	private String latency; // time to first response
	private String encoding;
	private String sampleCount; // number of samples (1, unless multiple samples are aggregated) 
	private String errorCount; // number of errors (0 or 1, unless multiple samples are aggregated) 
	private String hostname; // where the sample was generated
	private String idleTime; // number of milliseconds of 'Idle' time (normally 0) 
	
	// Logged in same column order as JMeter (see: http://jmeter.apache.org/usermanual/listeners.html)
	public void log() {
		StringBuilder sb = new StringBuilder();
		sb.append("ResultBean[id:"+id+",");
		sb.append("timeStamp:"+timeStamp+",");
		sb.append("elapsed:"+elapsed+",");
		if(StringUtils.isNotBlank(label)) sb.append("label:"+label+",");
		if(StringUtils.isNotBlank(responseCode)) sb.append("responseCode:"+responseCode+",");
		if(StringUtils.isNotBlank(responseMessage)) sb.append("responseMessage:"+responseMessage+",");
		if(StringUtils.isNotBlank(threadName)) sb.append("threadName:"+threadName+",");
		if(StringUtils.isNotBlank(dataType)) sb.append("dataType:"+dataType+",");
		sb.append("success:"+success+",");
		if(StringUtils.isNotBlank(failureMessage)) sb.append("failureMessage:"+failureMessage+",");
		sb.append("bytes:"+bytes+",");
		sb.append("grpThreads:"+grpThreads+",");
		sb.append("allThreads:"+allThreads+",");
		if(StringUtils.isNotBlank(url)) sb.append("url:"+url+",");
		if(StringUtils.isNotBlank(filename)) sb.append("filename:"+filename+",");
		sb.append("latency:"+latency+",");
		if(StringUtils.isNotBlank(encoding)) sb.append("encoding:"+encoding+",");
		sb.append("sampleCount:"+sampleCount+",");
		sb.append("errorCount:"+errorCount+",");
		if(StringUtils.isNotBlank(hostname)) sb.append("hostname:"+hostname+",");
		sb.append("idleTime:"+idleTime);
		sb.append("]");
		log.info(sb.toString());
	}

	/**
	 * @return the timeStamp
	 */
	public String getTimeStamp() {
		return timeStamp;
	}

	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	/**
	 * @return the elapsed
	 */
	public String getElapsed() {
		return elapsed;
	}

	/**
	 * @param elapsed the elapsed to set
	 */
	public void setElapsed(String elapsed) {
		this.elapsed = elapsed;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}

	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	/**
	 * @return the responseMessage
	 */
	public String getResponseMessage() {
		return responseMessage;
	}

	/**
	 * @param responseMessage the responseMessage to set
	 */
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	/**
	 * @return the threadName
	 */
	public String getThreadName() {
		return threadName;
	}

	/**
	 * @param threadName the threadName to set
	 */
	public void setThreadName(String threadName) {
		this.threadName = threadName;
	}

	/**
	 * @return the dataType
	 */
	public String getDataType() {
		return dataType;
	}

	/**
	 * @param dataType the dataType to set
	 */
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	/**
	 * @return the success
	 */
	public String getSuccess() {
		return success;
	}

	/**
	 * @param success the success to set
	 */
	public void setSuccess(String success) {
		this.success = success;
	}

	/**
	 * @return the failureMessage
	 */
	public String getFailureMessage() {
		return failureMessage;
	}

	/**
	 * @param failureMessage the failureMessage to set
	 */
	public void setFailureMessage(String failureMessage) {
		this.failureMessage = failureMessage;
	}

	/**
	 * @return the bytes
	 */
	public String getBytes() {
		return bytes;
	}

	/**
	 * @param bytes the bytes to set
	 */
	public void setBytes(String bytes) {
		this.bytes = bytes;
	}

	/**
	 * @return the grpThreads
	 */
	public String getGrpThreads() {
		return grpThreads;
	}

	/**
	 * @param grpThreads the grpThreads to set
	 */
	public void setGrpThreads(String grpThreads) {
		this.grpThreads = grpThreads;
	}

	/**
	 * @return the allThreads
	 */
	public String getAllThreads() {
		return allThreads;
	}

	/**
	 * @param allThreads the allThreads to set
	 */
	public void setAllThreads(String allThreads) {
		this.allThreads = allThreads;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the latency
	 */
	public String getLatency() {
		return latency;
	}

	/**
	 * @param latency the latency to set
	 */
	public void setLatency(String latency) {
		this.latency = latency;
	}

	/**
	 * @return the encoding
	 */
	public String getEncoding() {
		return encoding;
	}

	/**
	 * @param encoding the encoding to set
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * @return the sampleCount
	 */
	public String getSampleCount() {
		return sampleCount;
	}

	/**
	 * @param sampleCount the sampleCount to set
	 */
	public void setSampleCount(String sampleCount) {
		this.sampleCount = sampleCount;
	}

	/**
	 * @return the errorCount
	 */
	public String getErrorCount() {
		return errorCount;
	}

	/**
	 * @param errorCount the errorCount to set
	 */
	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	/**
	 * @return the hostname
	 */
	public String getHostname() {
		return hostname;
	}

	/**
	 * @param hostname the hostname to set
	 */
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	/**
	 * @return the idleTime
	 */
	public String getIdleTime() {
		return idleTime;
	}

	/**
	 * @param idleTime the idleTime to set
	 */
	public void setIdleTime(String idleTime) {
		this.idleTime = idleTime;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}


	
}
