/**
 * 
 */
package org.apache.jmeter.uploader;

public class InvalidUploadUrlException extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidUploadUrlException() { }

	/**
	 * @param arg0
	 */
	public InvalidUploadUrlException(String arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 */
	public InvalidUploadUrlException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public InvalidUploadUrlException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
