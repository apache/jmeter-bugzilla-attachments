package org.apache.jmeter.uploader;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;

import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.visualizers.gui.AbstractVisualizer;

public class ResultUploader extends AbstractVisualizer implements ActionListener {

	private static final long serialVersionUID = 1L;
	private static final ResourceBundle resource = ResourceBundle.getBundle("org.apache.jmeter.uploader.ResultUploaderResources");

	private static final String key_comment_label = "comment.label";
	private static final String key_environment_label = "environment.label";
	private static final String key_project_label = "project.label";
	private static final String key_settings_label = "settings.label";
	private static final String key_tag_label = "tagname.label";
	private static final String key_test_description = "test.description";
	private static final String key_title = "result.uploader.title";
	private static final String key_url_host_label = "url.host.label";
	private static final String key_url_addresults_label = "url.addresults.label";
	private static final String key_url_addtest_label = "url.addtest.label";
	private static final String key_url_default_host = "url.default.host";
	private static final String key_url_default_endpoint_addresults = "url.default.endpoint.addresults";
	private static final String key_url_default_endpoint_addtest = "url.default.endpoint.addtest";
	private static final String key_url_description = "url.description";
	private static final String key_url_test_button_success = "url.test.button.success";
	private static final String key_url_test_button_error = "url.test.button.error";
	private static final String key_url_test_button_label = "url.test.button.label";
	private static final String key_upload_interval_label = "upload.interval.label";
	private static final String key_upload_interval_default_value = "upload.interval.default.value";
	private static final String key_upload_interval_description = "upload.interval.description";
	
	private JButton hostTestButton;
	private JButton resultsTestButton;
	private JButton testTestButton;
	private JTextField urlHostField;
	private JTextField urlEndpointAddResultsField;
	private JTextField urlEndpointAddTestField;
	private JTextField intervalField;
	private JTextField projectField;
	private JTextField envField;
	private JTextField tagField;
	private JTextField commentField;
	
	public ResultUploader() {
		super();
		setModel(new ResultUploaderCollector());
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        add(createMainPanel(), BorderLayout.NORTH);
		setName(getStaticLabel());
	}
	
    private Container createMainPanel() {
    	JPanel mainPanel = new VerticalPanel();
    	
        VerticalPanel titlePanel = new VerticalPanel();
        titlePanel.add(createTitleLabel());
        VerticalPanel contentPanel = new VerticalPanel();
        contentPanel.setBorder(BorderFactory.createEtchedBorder());
        contentPanel.add(getNamePanel());
        titlePanel.add(contentPanel);
        mainPanel.add(titlePanel);
        
        VerticalPanel settingsPanel = new VerticalPanel();
        settingsPanel.add(createSettingsLabel());
        
        VerticalPanel urlPanel = new VerticalPanel();
        urlPanel.setBorder(BorderFactory.createEtchedBorder());
        urlPanel.add(getUrlDescription());
        urlPanel.add(getUrlHostPanel());
        urlPanel.add(getTestEndpointPanel());
        urlPanel.add(getResultsEndpointPanel());
        settingsPanel.add(urlPanel);
        
        VerticalPanel intervalPanel = new VerticalPanel();
        intervalPanel.setBorder(BorderFactory.createEtchedBorder());
        intervalPanel.add(getIntervalDescription());
        intervalPanel.add(getIntervalPanel());
        settingsPanel.add(intervalPanel);
        
        VerticalPanel testParamPanel = new VerticalPanel();
        testParamPanel.setBorder(BorderFactory.createEtchedBorder());
        testParamPanel.add(getTestDescription());
        testParamPanel.add(getProjectPanel());
        testParamPanel.add(getEnvPanel());
        testParamPanel.add(getTagPanel());
        testParamPanel.add(getCommentPanel());
        settingsPanel.add(testParamPanel);
        
        mainPanel.add(settingsPanel);
        
        return mainPanel;
    }

    private void displayMessage(String message, boolean isError) {
        int type = 0;
        if (isError) type = JOptionPane.ERROR_MESSAGE;
        else type = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, message, isError ? 
                resource.getString(key_url_test_button_error) : resource.getString(key_url_test_button_success), type);
    }
    
    private Component createSettingsLabel() {
        JLabel settingsLabel = new JLabel(resource.getString(key_settings_label));
        Font curFont = settingsLabel.getFont();
        settingsLabel.setFont(curFont.deriveFont((float) curFont.getSize() + 4));
        return settingsLabel;
    }
    
    private JLabel getIntervalDescription() {
        JLabel intervalDesc = new JLabel(resource.getString(key_upload_interval_description));
        Font curFont = intervalDesc.getFont();
        intervalDesc.setFont(curFont.deriveFont((float)curFont.getSize() +1));
        intervalDesc.setFont(curFont.deriveFont(Font.BOLD));
        return intervalDesc;
    }
    
    private JLabel getTestDescription() {
        JLabel testDesc = new JLabel(resource.getString(key_test_description));
        Font curFont = testDesc.getFont();
        testDesc.setFont(curFont.deriveFont((float)curFont.getSize() +1));
        testDesc.setFont(curFont.deriveFont(Font.BOLD));
        return testDesc;
    }
    
    private JPanel getIntervalPanel() {
    	JPanel intervalPanel = new JPanel(new BorderLayout());
    	intervalPanel.add(new JLabel(resource.getString(key_upload_interval_label)), BorderLayout.WEST);
        intervalField = new JTextField(2);
        intervalField.setEditable(true);
        intervalField.setText(resource.getString(key_upload_interval_default_value));
        intervalPanel.add(intervalField);
        return intervalPanel;
    }
    
    private JLabel getUrlDescription() {
        JLabel urlDesc = new JLabel(resource.getString(key_url_description));
        Font curFont = urlDesc.getFont();
        urlDesc.setFont(curFont.deriveFont((float) curFont.getSize()+1));
        urlDesc.setFont(curFont.deriveFont(Font.BOLD));
        return urlDesc;
    }
    
    private JPanel getUrlHostPanel() {
    	JPanel urlPanel = new JPanel(new BorderLayout());
        urlPanel.add(new JLabel(resource.getString(key_url_host_label)), BorderLayout.WEST);
        urlHostField = new JTextField(10);
        urlHostField.setEditable(true);
        urlHostField.setText(resource.getString(key_url_default_host));
        urlPanel.add(urlHostField);
        hostTestButton = new JButton(resource.getString(key_url_test_button_label));
        hostTestButton.addActionListener(this);
        hostTestButton.setEnabled(true);
        urlPanel.add(hostTestButton, BorderLayout.EAST);
        return urlPanel;
    }
    
    private JPanel getResultsEndpointPanel() {
    	JPanel urlPanel = new JPanel(new BorderLayout());
        urlPanel.add(new JLabel(resource.getString(key_url_addresults_label)), BorderLayout.WEST);
        urlEndpointAddResultsField = new JTextField(10);
        urlEndpointAddResultsField.setEditable(true);
        urlEndpointAddResultsField.setText(resource.getString(key_url_default_endpoint_addresults));
        urlPanel.add(urlEndpointAddResultsField);
        resultsTestButton = new JButton(resource.getString(key_url_test_button_label));
        resultsTestButton.addActionListener(this);
        resultsTestButton.setEnabled(true);
        urlPanel.add(resultsTestButton, BorderLayout.EAST);
        return urlPanel;
    }
    
    private JPanel getTestEndpointPanel() {
    	JPanel urlPanel = new JPanel(new BorderLayout());
        urlPanel.add(new JLabel(resource.getString(key_url_addtest_label)), BorderLayout.WEST);
        urlEndpointAddTestField = new JTextField(10);
        urlEndpointAddTestField.setEditable(true);
        urlEndpointAddTestField.setText(resource.getString(key_url_default_endpoint_addtest));
        urlPanel.add(urlEndpointAddTestField);
        testTestButton = new JButton(resource.getString(key_url_test_button_label));
        testTestButton.addActionListener(this);
        testTestButton.setEnabled(true);
        urlPanel.add(testTestButton, BorderLayout.EAST);
        return urlPanel;
    }
    
    private JPanel getProjectPanel() {
    	JPanel projectPanel = new JPanel(new BorderLayout());
    	projectPanel.add(new JLabel(resource.getString(key_project_label)), BorderLayout.WEST);
        projectField = new JTextField(10);
        projectField.setEditable(true);
        projectPanel.add(projectField);
        return projectPanel;
    }
    
    private JPanel getEnvPanel() {
    	JPanel envPanel = new JPanel(new BorderLayout());
    	envPanel.add(new JLabel(resource.getString(key_environment_label)), BorderLayout.WEST);
        envField = new JTextField(10);
        envField.setEditable(true);
        envPanel.add(envField);
        return envPanel;
    }
    
    private JPanel getTagPanel() {
    	JPanel tagPanel = new JPanel(new BorderLayout());
    	tagPanel.add(new JLabel(resource.getString(key_tag_label)), BorderLayout.WEST);
        tagField = new JTextField(10);
        tagField.setEditable(true);
        tagPanel.add(tagField);
        return tagPanel;
    }
    
    private JPanel getCommentPanel() {
    	JPanel commentPanel = new JPanel(new BorderLayout());
    	commentPanel.add(new JLabel(resource.getString(key_comment_label)), BorderLayout.WEST);
        commentField = new JTextField(10);
        commentField.setEditable(true);
        commentPanel.add(commentField);
        return commentPanel;
    }
    
    private void updateVisualizer(ResultUploaderModel model) {
        urlHostField.setText(model.getUrlHost());
        urlEndpointAddResultsField.setText(model.getResultsEndpoint());
        urlEndpointAddTestField.setText(model.getTestEndpoint());
        intervalField.setText(model.getInterval());
        projectField.setText(model.getProject());
        envField.setText(model.getEnv());
        tagField.setText(model.getTagName());
        commentField.setText(model.getComment());
        repaint();
    }
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == hostTestButton || event.getSource() == resultsTestButton || event.getSource() == testTestButton) {
            ResultCollector testElement = getModel();
            modifyTestElement(testElement);
            try {
            	ResultUploaderModel model = ((ResultUploaderCollector)testElement).getResultUploaderModel();
                if(event.getSource() == hostTestButton) {
                	displayMessage(model.testUrl(model.getUrlHost()), false);
                } else if(event.getSource() == resultsTestButton) {
                	displayMessage(model.testUrl(model.getUrlHost()+model.getResultsEndpoint()), false);
                } else {
                	displayMessage(model.testUrl(model.getUrlHost()+model.getTestEndpoint()), false);
                }
            } catch (InvalidUploadUrlException e) {
                displayMessage(e.getMessage(), true);
            }
        }
	}
	
	@Override
	public void add(final SampleResult result) {
        if (getModel() != null) {
            JMeterUtils.runSafe(new Runnable() {
                public void run() {
                	ResultUploaderModel model = ((ResultUploaderCollector)getModel()).getResultUploaderModel();
                    model.add(result, null);
                    updateVisualizer(model);
                }
            });
        }
	}

	@Override
    public synchronized void clearData() {
        if (getModel() != null) {
        	ResultUploaderModel model = ((ResultUploaderCollector) getModel()).getResultUploaderModel();
            model.clear();
            updateVisualizer(model);
        }
    }
	
    @Override
    public void configure(TestElement testElement) {
        super.configure(testElement);
        updateVisualizer(((ResultUploaderCollector)testElement).getResultUploaderModel());
    }
	
    @Override
    public TestElement createTestElement() {
        ResultCollector model = getModel();
        if (model == null) {
            model = new ResultUploaderCollector();
            setModel(model);
        }
        modifyTestElement(model);
        return model;
    }
	
	@Override
	public String getLabelResource() {
		return null;
	}
	
	@Override
    public String getStaticLabel() {
		return resource.getString(key_title);
	}
	
    @Override
    public void modifyTestElement(TestElement testElement) {
        super.modifyTestElement(testElement);
        ResultUploaderModel resultUploaderModel = ((ResultUploaderCollector)testElement).getResultUploaderModel();
        resultUploaderModel.setUrlHost(urlHostField.getText());
        resultUploaderModel.setResultsEndpoint(urlEndpointAddResultsField.getText());
        resultUploaderModel.setTestEndpoint(urlEndpointAddTestField.getText());
        resultUploaderModel.setInterval(intervalField.getText());
        resultUploaderModel.setProject(projectField.getText());
        resultUploaderModel.setEnv(envField.getText());
        resultUploaderModel.setTagName(tagField.getText());
        resultUploaderModel.setComment(commentField.getText());
    }
	
    @Override
    public void stateChanged(ChangeEvent event) {
        if (event.getSource() instanceof ResultUploaderModel) {
        	ResultUploaderModel model = (ResultUploaderModel)event.getSource();
            updateVisualizer(model);
        } else {
            super.stateChanged(event);
        }
    }
    
    @Override
    public String toString() {
        return resource.getString(key_title);
    }
    
    public static ResourceBundle getResouceBundle() {
    	return resource;
    }
}
