package wsdlgenerator;

import com.eviware.soapui.impl.wsdl.WsdlInterface;
import com.eviware.soapui.impl.wsdl.WsdlOperation;
import com.eviware.soapui.impl.wsdl.WsdlProject;

import java.util.Vector;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

/**
 * User: shahs
 * Date: Feb 2, 2007
 * Time: 3:35:13 PM
 */
public class WSDLRequestGenerator {
    private static final Pattern pattern = Pattern.compile("\\?</(.*?)>");

    public static WSDLOperation[] generateRequests(String URL) throws Exception {
        Vector operations = new Vector();
        String wsdl = URL;
        if(wsdl == null || wsdl.length() <= 0) return (WSDLOperation[])operations.toArray(new WSDLOperation[operations.size()]);
        WsdlProject project = new WsdlProject();
        WsdlInterface[] ifaces = project.importWsdl(wsdl, true);
        for(int i = 0; i < ifaces.length; i++) {
            WsdlInterface iface = ifaces[i];
            for(int j = 0; j < iface.getOperationCount(); j++) {
                WsdlOperation operation = (WsdlOperation)iface.getOperationAt(j);
                operations.add(new WSDLOperation(operation.getName(), convertParameters(operation.getRequestAt(0).getRequestContent())));
            }
        }
        return (WSDLOperation[])operations.toArray(new WSDLOperation[operations.size()]);
    }

    public static String convertParameters(String input) {
        String output = input;
        Matcher matcher = pattern.matcher(input);
        while(matcher.find()) {
            String parameterName = matcher.group(1);
            output = matcher.replaceFirst("\\${" + parameterName + "}</" + parameterName + ">");
            matcher.reset(output);
        }
        return output;
    }

    public static void main(String args[]) throws Exception {
        generateRequests(args[0]);
    }
}
