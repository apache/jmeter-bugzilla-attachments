package wsdlgenerator;

/**
 * User: shahs
 * Date: Feb 2, 2007
 * Time: 3:32:57 PM
 */
public class WSDLOperation {
    private String operationName = "";
    private String requestTemplate = "";
    
    public WSDLOperation(String operationName, String requestTemplate) {
        this.operationName = operationName;
        this.requestTemplate = requestTemplate; 
    }

    public String getRequestTemplate() {
        return requestTemplate;
    }
    
    public String toString() {
        return operationName;
    }
}
