import org.opensolaris.os.dtrace.*;
import java.io.File;
import java.io.IOException;

/*
The MyShutdown Class implements the functionality that will get fired when the JVM goes down.
We are disabling the DTrace probes which got enabled when we started the profiling activity
*/
class MyShutdown extends Thread {
    String pid;

    public MyShutdown( String pid ) {
        this.pid = pid;
    }

    public void run() {
        String[] jinfo_stop_args = new String[]{ "jinfo", "-flag", "-ExtendedDTraceProbes", this.pid };
        Runtime runtime = Runtime.getRuntime();
        try {
            Process proc1 = runtime.exec(jinfo_stop_args);
        } catch( IOException e) {
            e.printStackTrace();
        }
    }
}


/*
Here initially, we invoke a awk script to create a DTrace script which will meet our specification. Then fire the DTrace script
using the jDTrace interface. Make sure
*/

public class MethodProfiler {
    public static void main(String[] args) {
        Runtime runtime = Runtime.getRuntime();
        MyShutdown cleanup_tasks = new MyShutdown( args[0] );
        runtime.addShutdownHook(cleanup_tasks);

        String[] awk_args = new String[]{ "sh", "-c", "gawk -f CreateDTraceScript.awk MethodProfiler_template.d >MethodProfiler.d"};
        String[] jinfo_start_args = new String[]{ "jinfo", "-flag", "+ExtendedDTraceProbes", args[0] };

        try {
            Process proc1 = runtime.exec(awk_args);
            Process proc2 = runtime.exec(jinfo_start_args);
        } catch( IOException e)    {
            e.printStackTrace();
        }

        File file = new File("MethodProfiler.d");
        int pid = Integer.parseInt(args[0]);

        final Consumer consumer = new LocalConsumer();
        consumer.addConsumerListener(new ConsumerAdapter() {

            public void dataReceived(DataEvent e) {
                System.out.println(e.getProbeData());
            }

            public void consumerStopped(ConsumerEvent e) {
                try {
                    Aggregate a = consumer.getAggregate();
                    for (Aggregation agg : a.asMap().values()) {
                        for (AggregationRecord rec : agg.asMap().values()) {
                            System.out.println(rec.getTuple() + " " +
                            rec.getValue());
                        }
                    }
                } catch (Exception x) {
                    x.printStackTrace();
                    System.exit(1);
                }
                consumer.close();
            }

            public void processStateChanged(ProcessEvent e) {
                System.out.println(e.getProcessState());
            }

        });

        try {
            consumer.open();
            // pid replaces $target variable in D script
            consumer.grabProcess(pid);
            consumer.compile(file);
            consumer.enable();
            consumer.go();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}

