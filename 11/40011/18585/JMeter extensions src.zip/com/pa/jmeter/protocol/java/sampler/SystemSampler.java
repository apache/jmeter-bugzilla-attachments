package com.pa.jmeter.protocol.java.sampler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.jmeter.config.Argument;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestListener;
import org.apache.jmeter.testelement.property.TestElementProperty;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * A sampler for executing a System function. 
 * @author Geoff Willingham, PA Consulting Group.
 */
public class SystemSampler extends AbstractSampler implements TestListener {
    private static final long serialVersionUID = 1;
    
    public static final String COMMAND = "SystemSampler.command";
    
    public static final String ARGUMENTS = "SystemSampler.arguments";
    
    public static final String CHECK_RETURN_CODE = "SystemSampler.checkReturnCode";
    
    public static final String EXPECTED_RETURN_CODE = "SystemSampler.expectedReturnCode";

    /**
     * Logging
     */
    private static transient Logger log = LoggingManager.getLoggerForClass();

    /**
     * Create a SystemSampler.
     */
    public SystemSampler() {
        setArguments(new Arguments());
    }

    /**
     * Set the arguments (parameters) for the JavaSamplerClient to be executed
     * with.
     * 
     * @param args
     *            the new arguments. These replace any existing arguments.
     */
    public void setArguments(Arguments args) {
        setProperty(new TestElementProperty(ARGUMENTS, args));
    }

    /**
     * Get the arguments (parameters) for the JavaSamplerClient to be executed
     * with.
     * 
     * @return the arguments
     */
    public Arguments getArguments() {
        return (Arguments) getProperty(ARGUMENTS).getObjectValue();
    }

    /**
     * Sets the Command attribute of the JavaConfig object
     * 
     * @param command
     *            the new Command value
     */
    public void setCommand(String command) {
        setProperty(COMMAND, command);
    }

    /**
     * Gets the Command attribute of the JavaConfig object
     * 
     * @return the Command value
     */
    public String getCommand() {
        return getPropertyAsString(COMMAND);
    }
    
    public void setCheckReturnCode(boolean checkit) {
        setProperty(CHECK_RETURN_CODE, (new Boolean(checkit)).toString());
    }
    
    public boolean getCheckReturnCode() {
        return getPropertyAsBoolean(CHECK_RETURN_CODE);
    }
    
    public void setExpectedReturnCode(int code) {
        setProperty(EXPECTED_RETURN_CODE, Integer.toString(code));
    }
    
    public int getExpectedReturnCode() {
        return getPropertyAsInt(EXPECTED_RETURN_CODE);
    }

    /**
     * Performs a test sample.
     * 
     * @param entry
     *            the Entry for this sample
     * @return test SampleResult
     */
    public SampleResult sample(Entry entry) {
        SampleResult results = new SampleResult();
        results.setDataType(SampleResult.TEXT);
        
        try {
            Arguments args = getArguments();
            String command = getCommand();
            boolean checkReturnCode = getCheckReturnCode();
            int expectedReturnCode = getExpectedReturnCode();
            
            String[] cmds = new String[args.getArgumentCount()+1];
            StringBuffer cmdLine = new StringBuffer((null == command) ? "" : command);
            cmds[0] = command;
            for (int i=0;i<args.getArgumentCount();i++) {
                Argument arg = args.getArgument(i);
                cmdLine.append(" ");
                cmds[i+1] = arg.getPropertyAsString(Argument.VALUE);
                cmdLine.append(cmds[i+1]);
            }
            results.setSamplerData(cmdLine.toString());
            
            Process proc = null;
            BufferedReader bis = null;
            String responseData = null;
            try {
                ProcessBuilder procBuild = new ProcessBuilder(cmds);
                procBuild.redirectErrorStream(true);
                
                results.sampleStart();
                proc = procBuild.start();
                bis = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                int returnCode = proc.waitFor();
                results.sampleEnd();

                if (checkReturnCode && (returnCode != expectedReturnCode)) {
                    results.setSuccessful(false);
                    responseData = "System did not return expected return code.  Expected ["+expectedReturnCode+"]. Returned ["+returnCode+"].";
                    results.setSampleLabel("FAILED: " + getName());
                } else {
                    results.setSuccessful(true);
                    responseData = "System Call Complete.";
                    results.setSampleLabel(getName());
                }
            } catch (IOException ioe) {
                results.setSuccessful(false);
                responseData = "Exception occured whilst executing System Call: "+ioe;
                results.setSampleLabel("ERROR: " + getName());
            } catch (InterruptedException ie) {
                results.setSuccessful(false);
                responseData = "System Sampler Interupted whilst executing System Call: "+ie;
                results.setSampleLabel("ERROR: " + getName());
            }
    
            StringBuffer procOutput = new StringBuffer();
            if (null != proc && null != bis) {
                String line = null;
                while ((line = bis.readLine()) != null) {
                    procOutput.append(line);
                }
            }
            results.setResponseData((responseData+"\nProcess Output:\n"+procOutput.toString()).getBytes());
            
        } catch (Exception e) {
            results.setSuccessful(false);
            results.setResponseData(("Unknown Exception caught: "+e).getBytes());
            results.setSampleLabel("ERROR: " + getName());
        }
        return results;
    }

    // TestListener implementation
    /* Implements TestListener.testStarted() */
    public void testStarted() {
        log.debug("SystemSampler ["+getName()+"]: testStarted");
    }

    /* Implements TestListener.testStarted(String) */
    public void testStarted(String host) {
        log.debug("SystemSampler ["+getName()+"]: testStarted ("+host+")");
    }

    /* Implements TestListener.testEnded() */
    public void testEnded() {
      log.debug("SystemSample ["+getName()+"]: testEnded");
    }

    /* Implements TestListener.testEnded(String) */
    public void testEnded(String host) {
      log.debug("SystemSample ["+getName()+"]: testEnded ("+host+")");
    }

    /* Implements TestListener.testIterationStart(LoopIterationEvent) */
    public void testIterationStart(LoopIterationEvent event) {
    }
}
