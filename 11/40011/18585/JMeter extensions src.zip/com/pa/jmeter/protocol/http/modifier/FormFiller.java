/*
 * Copyright 2001-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.protocol.http.modifier;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.apache.jmeter.config.Argument;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.ConfigElement;
import org.apache.jmeter.processor.PreProcessor;
import org.apache.jmeter.protocol.http.parser.HtmlParsingUtils;
import org.apache.jmeter.protocol.http.sampler.HTTPSampleResult;
import org.apache.jmeter.protocol.http.sampler.HTTPSamplerBase;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.samplers.Sampler;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.property.PropertyIterator;
import org.apache.jmeter.threads.JMeterContext;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.pa.jmeter.extractor.ResultStore;

// For Unit tests, @see TestAnchorModifier

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class FormFiller extends AbstractTestElement implements PreProcessor, Serializable {
    private static final long serialVersionUID = 1;
    
    transient private static Logger log = LoggingManager.getLoggerForClass();

    private static Random rand = new Random();
    
    public static final String RESULT_STORE_NAME = "FormFiller.nameOfResultStore";
    public static final String CURRENT_VALUE_FLAG = "FormFiller.currentValueFlag";
    public static final String RANDOM_VALUE_FLAG = "FormFiller.randomValueFlag";    
    
    public FormFiller() {
    }

    public void setNameOfResultStore(String name) {
        setProperty(RESULT_STORE_NAME, name);
    }
    
    public String getNameOfResultStore() {
        return getPropertyAsString(RESULT_STORE_NAME);
    }
    
    public String getCurrentValueFlag() {
        return getPropertyAsString(CURRENT_VALUE_FLAG);
    }
    
    public String getRandomValueFlag() {
        return getPropertyAsString(RANDOM_VALUE_FLAG);
    }
    
    private HTTPSampleResult getSource(JMeterContext context) {
        SampleResult res = context.getPreviousResult();
        HTTPSampleResult result = null;
        String nameOfResultStore = getNameOfResultStore();
        if (null != nameOfResultStore && !"".equals(nameOfResultStore)) {
            Object resultStore = context.getVariables().getObject(nameOfResultStore);
            if (null == resultStore) {
                log.info("Can't apply Form Filler when no ResultStore can be found matching the name: "+nameOfResultStore);
            }
            if (resultStore instanceof ResultStore) {
                SampleResult aResult = ((ResultStore)resultStore).fetchStoredResult();
                if (aResult instanceof HTTPSampleResult) {
                    result = (HTTPSampleResult)aResult;
                } else {
                    log.info("Can't apply Form Filler when the previous sampler run is not an HTTP Request.");
                }
            } else {
                log.info("Can't apply Form Filler when the Object matching the name: "+nameOfResultStore+", is not a ResultStore Ojbect.");
            }
        } else if (res == null || !(res instanceof HTTPSampleResult)) {
            log.info("Can't apply Form Filler when the previous" + " sampler run is not an HTTP Request.");
        } else {
            result = (HTTPSampleResult) res;
        }
        return result;
    }
    
    private HTTPSamplerBase getTarget(JMeterContext context) {
        HTTPSamplerBase sampler = null;
        Sampler sam = context.getCurrentSampler();
        if (! (sam instanceof HTTPSamplerBase)) {
            log.info("Can't apply Form Filler to a sampler that is not a HTTP Sampler Base object.");
        } else {
            sampler = (HTTPSamplerBase) sam;
        }
        return sampler;
    }
    
    private Document parseHTML(HTTPSampleResult result) {
        String responseText = "";
        try {
            responseText = new String(result.getResponseData(), "8859_1");
        } catch (UnsupportedEncodingException e) {
        }
        Document html = null;
        try {
            int index = responseText.indexOf("<");
            if (index == -1) {
                index = 0;
            }
            html = (Document) HtmlParsingUtils.getDOM(responseText.substring(index));
        } catch (SAXException e) {
            log.info("Unable to parse HTML Result.  Exception: "+e);
            //no return - function will return a null object, causing parent function to abort
        }
        return html;
    }
    
    /**
     * Modifies an Entry object based on HTML response text.
     */
    public void process() {
        JMeterContext context = getThreadContext();
        
        //logging of cause handled by getSource and getTarget methods
        //return handled here to ensure both source and target are validated
        HTTPSampleResult result = getSource(context);
        HTTPSamplerBase sampler = getTarget(context);
        if (null == result || null == sampler) return;
                
        //null object indicates inability to parse HTML - parse function 
        //will have already logged cause - we just need to terminate processing
        Document html = parseHTML(result);
        if (null == html) return;
        
        //process the HTML to locate all the potential form elements
        //if no form elements found, return - no work to do
        List potentialLinks = getFormElements(html, result, sampler);
        if (null == potentialLinks || 0 == potentialLinks.size()) return;

        //retrieve the flag values for use as constants.  Implemented
        //in this manner to allow redefinition in case flag value clashes
        //with specific value needed to be sent to the server.
        final String CurrentValueFlag = getCurrentValueFlag();
        final String RandomValueFlag = getRandomValueFlag();

        //Iterate over each argument in the Target Sampler.  If the argument value
        //matches either the CURRENT_VALUE_FLAG or the RANDOM_VALUE_FLAG then the
        //'potential links' list will be checked for a matching form element.  If 
        //found, the value in the Target Sampler will be replaced with the appropriate
        //value from the form element.
        PropertyIterator argIter = sampler.getArguments().iterator();
        while (argIter.hasNext()) {
            Argument arg = (Argument) argIter.next().getObjectValue();
            String value = arg.getValue();
            
            //if not CurrentValueFlag or RandomValueFlag, skip and continue with next arg
            if (! (CurrentValueFlag.equals(value) || RandomValueFlag.equals(value))) continue;
            
            //iterate over the potential form elements until either 
            //a match is found, or all potentials have been tested.
            Iterator formIter = potentialLinks.iterator();
            while (formIter.hasNext()) {
                HTTPSamplerBase url = (HTTPSamplerBase) formIter.next();
                if (modifyArgument(arg, url.getArguments(), CurrentValueFlag, RandomValueFlag)) {
                    //argument has been modified - break out, and move to next arg.
                    break;
                }
            }
        }
    }

//    private void modifyArgument(Argument arg, Arguments args) {
    private boolean modifyArgument(Argument arg, Arguments args, final String currentValueFlag, final String randomValueFlag) {
        boolean argFound = false;
        log.debug("Modifying argument: " + arg);
        List possibleReplacements = new ArrayList();
        PropertyIterator iter = args.iterator();
        Argument replacementArg;
        while (iter.hasNext()) {
            replacementArg = (Argument) iter.next().getObjectValue();
            try {
                if (HtmlParsingUtils.isArgumentMatched(replacementArg, arg)) {
                    possibleReplacements.add(replacementArg);
                }
            } catch (Exception ex) {
                log.error("", ex);
            }
        }

        if (possibleReplacements.size() > 0) {
            if (currentValueFlag.equals(arg.getValue())) {
                Iterator aIter = possibleReplacements.iterator();
                Argument possibleArg = null;
                while (aIter.hasNext()) {
                    possibleArg = (Argument) iter.next().getObjectValue();
                    if (null != possibleArg.getProperty("selected")) {
                        arg.setName(possibleArg.getName());
                        arg.setValue(possibleArg.getValue());
                        log.debug("Just set argument to values: " + arg.getName() + " = " + arg.getValue());
                        args.removeArgument(possibleArg);
                        argFound = true;
                        break;
                    }
                }
                if (!argFound) {
                    //no 'selected' arg found, so use first value in the list
                    //this *should* correspond to the browser's displayed default
                    possibleArg = (Argument) possibleReplacements.get(0); 
                    arg.setName(possibleArg.getName());
                    arg.setValue(possibleArg.getValue());
                    log.debug("Just set argument to values: " + arg.getName() + " = " + arg.getValue());
                    args.removeArgument(possibleArg);
                    argFound = true;
                }
            } else {
                //randomValueFlag:
                replacementArg = (Argument) possibleReplacements.get(rand.nextInt(possibleReplacements.size()));
                arg.setName(replacementArg.getName());
                arg.setValue(replacementArg.getValue());
                log.debug("Just set argument to values: " + arg.getName() + " = " + arg.getValue());
                args.removeArgument(replacementArg);
            }
        } else {
            if (currentValueFlag.equals(arg.getValue())) {
                //no args for this field found, so set to an empty string
                //this *should* correspond to the browser's displayed default
                argFound = true;
                arg.setValue("");
                log.debug("Just set argument to values: " + arg.getName() + " = " + arg.getValue());
            }
        }
        return argFound;
    }

    public void addConfigElement(ConfigElement config) {
    }

    private List getFormElements(Document html, HTTPSampleResult result, HTTPSamplerBase config) {
        List potentialLinks = new ArrayList();
        NodeList rootList = html.getChildNodes();
        List urls = new LinkedList();
        for (int x = 0; x < rootList.getLength(); x++) {
            urls.addAll(HtmlParsingUtils.createURLFromForm(rootList.item(x), result.getURL()));
        }
        Iterator iter = urls.iterator();
        while (iter.hasNext()) {
            HTTPSamplerBase newUrl = (HTTPSamplerBase) iter.next();
            newUrl.setMethod(HTTPSamplerBase.POST);
            potentialLinks.add(newUrl);
        }
        
        return potentialLinks;
    }
}
