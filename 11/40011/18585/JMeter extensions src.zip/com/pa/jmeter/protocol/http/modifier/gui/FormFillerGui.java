// $Header$
/*
 * Copyright 2001-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.protocol.http.modifier.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JPanel;

import org.apache.jmeter.processor.gui.AbstractPreProcessorGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.gui.JLabeledTextField;

import com.pa.jmeter.protocol.http.modifier.FormFiller;

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class FormFillerGui extends AbstractPreProcessorGui {
    private static final long serialVersionUID = 1;
    
    private JLabeledTextField resultStoreField = null;
    private JLabeledTextField currentValueFlagField = null;
    private JLabeledTextField randomValueFlagField = null;
    private static ResourceBundle resources = ResourceBundle.getBundle("com.pa.jmeter.resources.FormFillerResources", JMeterUtils.getLocale());
    
    public FormFillerGui() {
        super();
        init();
    }

    public String getLabelResource() {
        return "form_filler_title";
    }

    public String getStaticLabel() {
        return resources.getString(getLabelResource());
    }
    
    public void configure(TestElement el) {
        super.configure(el);
        resultStoreField.setText(el.getPropertyAsString(FormFiller.RESULT_STORE_NAME));
        currentValueFlagField.setText(el.getPropertyAsString(FormFiller.CURRENT_VALUE_FLAG));
        randomValueFlagField.setText(el.getPropertyAsString(FormFiller.RANDOM_VALUE_FLAG));
    }
    
    public TestElement createTestElement() {
        FormFiller modifier = new FormFiller();
        super.configureTestElement(modifier);
        modifier.setProperty(FormFiller.RESULT_STORE_NAME, "");
        modifier.setProperty(FormFiller.CURRENT_VALUE_FLAG, "SELECTED");
        modifier.setProperty(FormFiller.RANDOM_VALUE_FLAG, ".*");
        return modifier;
    }

    /**
     * Modifies a given TestElement to mirror the data in the gui components.
     * 
     * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
     */
    public void modifyTestElement(TestElement modifier) {
        super.configureTestElement(modifier);
        modifier.setProperty(FormFiller.RESULT_STORE_NAME, resultStoreField.getText());
        modifier.setProperty(FormFiller.CURRENT_VALUE_FLAG, currentValueFlagField.getText());
        modifier.setProperty(FormFiller.RANDOM_VALUE_FLAG, randomValueFlagField.getText());
    }

    private void init() {
        setLayout(new BorderLayout());
        setBorder(makeBorder());

        add(makeTitlePanel(), BorderLayout.NORTH);
        add(makeParameterPanel(), BorderLayout.CENTER);
    }


    private JPanel makeParameterPanel() {

        resultStoreField = new JLabeledTextField(resources.getString("result_store_field"));
        resultStoreField.setToolTipText(resources.getString("result_store_field_tool_tip"));
        currentValueFlagField = new JLabeledTextField(resources.getString("current_value_flag_field"));
        currentValueFlagField.setToolTipText(resources.getString("current_value_flag_field_tool_tip"));
        randomValueFlagField = new JLabeledTextField(resources.getString("random_value_flag_field"));
        randomValueFlagField.setToolTipText(resources.getString("random_value_flag_field_tool_tip"));
        
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        initConstraints(gbc);
        addField(panel, resultStoreField, gbc);
        resetContraints(gbc);
        addField(panel, currentValueFlagField, gbc);
        resetContraints(gbc);
        gbc.weighty = 1;
        addField(panel, randomValueFlagField, gbc);
        
        return panel;
    }

    private void addField(JPanel panel, JLabeledTextField field, GridBagConstraints gbc) {
        List item = field.getComponentList();
        panel.add((Component) item.get(0), gbc.clone());
        gbc.gridx++;
        gbc.weightx = 1;
        ;
        panel.add((Component) item.get(1), gbc.clone());
    }

    private void resetContraints(GridBagConstraints gbc) {
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
    }

    private void initConstraints(GridBagConstraints gbc) {
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.NONE;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.weighty = 0;
    }
}
