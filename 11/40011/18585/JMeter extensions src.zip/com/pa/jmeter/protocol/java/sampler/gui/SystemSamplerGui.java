// $Header$
/*
 * Copyright 2002-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.protocol.java.sampler.gui;

import java.awt.BorderLayout;
import java.util.ResourceBundle;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.config.gui.ArgumentsPanel;
import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.gui.JLabeledTextField;
import org.apache.jorphan.util.JOrphanUtils;

import com.pa.jmeter.protocol.java.sampler.SystemSampler;

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class SystemSamplerGui extends AbstractSamplerGui {
    private static final long serialVersionUID = 1;
    
    private static ResourceBundle resources = ResourceBundle.getBundle("com.pa.jmeter.resources.SystemSamplerResources", JMeterUtils.getLocale());

    private JCheckBox checkReturnCode = null;
    private JLabeledTextField desiredReturnCode = null;
    private JLabeledTextField command = null;
    
    private ArgumentsPanel argsPanel = null;
    
    /**
     * Constructor for JavaTestSamplerGui
     */
    public SystemSamplerGui() {
        super();
        init();
    }

    public String getLabelResource() {
        return "system_sampler_title";
    }

    public String getStaticLabel() {
        return resources.getString(getLabelResource());
    }

    /**
     * Initialize the GUI components and layout.
     */
    private void init() {
        setLayout(new BorderLayout());
        setBorder(makeBorder());

        add(makeTitlePanel(), BorderLayout.NORTH);

        JPanel panela = new JPanel();
        panela.setLayout(new BorderLayout());

        JPanel panelb = new JPanel();
        panelb.setLayout(new BorderLayout());
        panelb.add(makeSourcePanel(), BorderLayout.NORTH);
        panelb.add(makeCommandPanel(), BorderLayout.CENTER);
        
        panela.add(panelb, BorderLayout.NORTH);
        panela.add(makeArgumentsPanel(), BorderLayout.CENTER);
        
        add(panela, BorderLayout.CENTER);
    }

    /* Implements JMeterGuiComponent.createTestElement() */
    public TestElement createTestElement() {
        SystemSampler sampler = new SystemSampler();
        modifyTestElement(sampler);
        return sampler;
    }

    /* Implements JMeterGuiComponent.modifyTestElement(TestElement) */
    public void modifyTestElement(TestElement sampler) {
        super.configureTestElement(sampler);
        sampler.setProperty(SystemSampler.CHECK_RETURN_CODE, JOrphanUtils.booleanToString(checkReturnCode.isSelected()));
        sampler.setProperty(SystemSampler.EXPECTED_RETURN_CODE, desiredReturnCode.getText());
        sampler.setProperty(SystemSampler.COMMAND, command.getText());
        ((SystemSampler)sampler).setArguments((Arguments)argsPanel.createTestElement());
    }

    /* Overrides AbstractJMeterGuiComponent.configure(TestElement) */
    public void configure(TestElement el) {
        super.configure(el);
        checkReturnCode.setSelected(el.getPropertyAsBoolean(SystemSampler.CHECK_RETURN_CODE));
        desiredReturnCode.setText(el.getPropertyAsString(SystemSampler.EXPECTED_RETURN_CODE));
        command.setText(el.getPropertyAsString(SystemSampler.COMMAND));
        argsPanel.configure((Arguments)el.getProperty(SystemSampler.ARGUMENTS).getObjectValue());
    }

    private JPanel makeSourcePanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(resources.getString("return_code_config_box_title")));
        checkReturnCode = new JCheckBox(resources.getString("check_return_code_title"));
        desiredReturnCode = new JLabeledTextField(resources.getString("expected_return_code_title"));
        desiredReturnCode.setSize(desiredReturnCode.getSize().height, 30);
        panel.add(checkReturnCode);
        panel.add(desiredReturnCode);
        checkReturnCode.setSelected(true);
        return panel;
    }
    
    private JPanel makeCommandPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(resources.getString("command_config_box_title")));
        command = new JLabeledTextField(resources.getString("command_field_title"));
        panel.add(command);
        return panel;
    }
    
    private JPanel makeArgumentsPanel() {
        argsPanel = new ArgumentsPanel(resources.getString("arguments_panel_title"));
        return argsPanel;
    }

}
