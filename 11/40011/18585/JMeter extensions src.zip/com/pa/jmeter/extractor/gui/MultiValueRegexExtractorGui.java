/*
 * Copyright 2003-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.extractor.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import org.apache.jmeter.processor.gui.AbstractPostProcessorGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.gui.JLabeledTextField;
import org.apache.jorphan.util.JOrphanUtils;

import com.pa.jmeter.extractor.MultiValueRegexExtractor;

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class MultiValueRegexExtractorGui extends AbstractPostProcessorGui {
    private static final long serialVersionUID = 1;

    private JLabeledTextField regexField;
    private JLabeledTextField templateField;   
    private JLabeledTextField templateSeparatorField;
    private JLabeledTextField defaultField;
    private JLabeledTextField matchLimitField;
    private JLabeledTextField refNameField;

    // NOTUSED private JCheckBox scanHeader;
    private JRadioButton useBody;
    private JRadioButton useHeaders;
    private static ResourceBundle resources = ResourceBundle.getBundle("com.pa.jmeter.resources.MultiValueRegexExtractorResources", JMeterUtils.getLocale());
    
    public MultiValueRegexExtractorGui() {
        super();
        init();
    }

    public String getLabelResource() {
        return "multi_value_regex_extractor_title";
    }

    public String getStaticLabel() {
        return resources.getString(getLabelResource());
    }
    
    public void configure(TestElement el) {
        super.configure(el);
        useHeaders.setSelected(el.getPropertyAsBoolean(MultiValueRegexExtractor.USEHEADERS));
        useBody.setSelected(!el.getPropertyAsBoolean(MultiValueRegexExtractor.USEHEADERS));
        regexField.setText(el.getPropertyAsString(MultiValueRegexExtractor.REGEX));
        templateField.setText(el.getPropertyAsString(MultiValueRegexExtractor.TEMPLATE));
        templateSeparatorField.setText(el.getPropertyAsString(MultiValueRegexExtractor.TEMPLATE_SEPARATOR));
        defaultField.setText(el.getPropertyAsString(MultiValueRegexExtractor.DEFAULT));
        matchLimitField.setText(el.getPropertyAsString(MultiValueRegexExtractor.MATCH_LIMIT));
        refNameField.setText(el.getPropertyAsString(MultiValueRegexExtractor.REFNAME));
    }

    /**
     * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
     */
    public TestElement createTestElement() {
        MultiValueRegexExtractor extractor = new MultiValueRegexExtractor();
        modifyTestElement(extractor);
        return extractor;
    }

    /**
     * Modifies a given TestElement to mirror the data in the gui components.
     * 
     * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
     */
    public void modifyTestElement(TestElement extractor) {
        super.configureTestElement(extractor);
        extractor.setProperty(MultiValueRegexExtractor.USEHEADERS, JOrphanUtils.booleanToString(useHeaders.isSelected()));
        extractor.setProperty(MultiValueRegexExtractor.MATCH_LIMIT, matchLimitField.getText());
        if (extractor instanceof MultiValueRegexExtractor) {
            MultiValueRegexExtractor regex = (MultiValueRegexExtractor) extractor;
            regex.setRefName(refNameField.getText());
            regex.setRegex(regexField.getText());
            regex.setTemplate(templateField.getText());
            regex.setTemplateSeparator(templateSeparatorField.getText());
            regex.setDefaultValue(defaultField.getText());
        }
    }

    private void init() {
        setLayout(new BorderLayout());
        setBorder(makeBorder());

        Box box = Box.createVerticalBox();
        box.add(makeTitlePanel());
        box.add(makeSourcePanel());
        add(box, BorderLayout.NORTH);
        add(makeParameterPanel(), BorderLayout.CENTER);
    }

    private JPanel makeSourcePanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(resources.getString("regex_source")));

        useBody = new JRadioButton(resources.getString("regex_src_body"));
        useHeaders = new JRadioButton(resources.getString("regex_src_hdrs"));

        ButtonGroup group = new ButtonGroup();
        group.add(useBody);
        group.add(useHeaders);

        panel.add(useBody);
        panel.add(useHeaders);

        useBody.setSelected(true);
        return panel;
    }

    private JPanel makeParameterPanel() {
        regexField = new JLabeledTextField(resources.getString("regex_field"));
        templateField = new JLabeledTextField(resources.getString("template_field"));
        templateSeparatorField = new JLabeledTextField(resources.getString("template_separator_field"));
        defaultField = new JLabeledTextField(resources.getString("default_value_field"));
        refNameField = new JLabeledTextField(resources.getString("ref_name_field"));
        matchLimitField = new JLabeledTextField(resources.getString("match_limit_field"));

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        initConstraints(gbc);
        addField(panel, refNameField, gbc);
        resetContraints(gbc);
        addField(panel, regexField, gbc);
        resetContraints(gbc);
        addField(panel, templateField, gbc);
        resetContraints(gbc);
        addField(panel, templateSeparatorField, gbc);
        resetContraints(gbc);
        addField(panel, matchLimitField, gbc);
        resetContraints(gbc);
        gbc.weighty = 1;
        addField(panel, defaultField, gbc);
        return panel;
    }

    private void addField(JPanel panel, JLabeledTextField field, GridBagConstraints gbc) {
        List item = field.getComponentList();
        panel.add((Component) item.get(0), gbc.clone());
        gbc.gridx++;
        gbc.weightx = 1;
        ;
        panel.add((Component) item.get(1), gbc.clone());
    }

    private void resetContraints(GridBagConstraints gbc) {
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.weightx = 0;
    }

    private void initConstraints(GridBagConstraints gbc) {
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.NONE;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;
        gbc.weighty = 0;
    }
}
