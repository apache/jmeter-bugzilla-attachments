/*
 * Copyright 2003-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.extractor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.jmeter.processor.PostProcessor;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.property.IntegerProperty;
import org.apache.jmeter.threads.JMeterContext;
import org.apache.jmeter.threads.JMeterVariables;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.apache.oro.text.MalformedCachePatternException;
import org.apache.oro.text.PatternCacheLRU;
import org.apache.oro.text.regex.MatchResult;
import org.apache.oro.text.regex.Pattern;
import org.apache.oro.text.regex.PatternMatcher;
import org.apache.oro.text.regex.PatternMatcherInput;
import org.apache.oro.text.regex.Perl5Compiler;
import org.apache.oro.text.regex.Perl5Matcher;
import org.apache.oro.text.regex.Util;

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class MultiValueRegexExtractor extends AbstractTestElement implements PostProcessor, Serializable {
    private static final long serialVersionUID = 1;

    private static final Logger log = LoggingManager.getLoggerForClass();

    public static final String USEHEADERS = "MultiValueRegexExtractor.useHeaders"; // $NON-NLS-1$

    public static final String REGEX = "MultiValueRegexExtractor.regex"; // $NON-NLS-1$

    public static final String REFNAME = "MultiValueRegexExtractor.refname"; // $NON-NLS-1$

    public static final String MATCH_LIMIT = "MultiValueRegexExtractor.match_limit"; // $NON-NLS-1$

    public static final String DEFAULT = "MultiValueRegexExtractor.default"; // $NON-NLS-1$

    public static final String TEMPLATE = "MultiValueRegexExtractor.template"; // $NON-NLS-1$
    
    public static final String TEMPLATE_SEPARATOR = "MultiValueRegexExtractor.template_separator";

    private Object[] template = null;
    
    private String templateSeparator = null;

    private static PatternCacheLRU patternCache = new PatternCacheLRU(1000, new Perl5Compiler());

    private static ThreadLocal localMatcher = new ThreadLocal() {
        protected Object initialValue() {
            return new Perl5Matcher();
        }
    };

    /**
     * Parses the response data using regular expressions and saving the results
     * into variables for use later in the test.
     * 
     * @see org.apache.jmeter.processor.PostProcessor#process()
     */
    public void process() {
        initTemplate();
        JMeterContext context = getThreadContext();
        if (context.getPreviousResult() == null || context.getPreviousResult().getResponseData() == null) {
            return;
        }
        log.debug("MultiValueRegexExtractor processing result");

        // Fetch some variables
        JMeterVariables vars = context.getVariables();
        String refName = getRefName();
        int matchLimit = getMatchLimit();

        final String defaultValue = getDefaultValue();
        if (defaultValue.length() > 0){// Only replace default if it is provided
            vars.put(refName, defaultValue);
        }

        Perl5Matcher matcher = (Perl5Matcher) localMatcher.get();
        PatternMatcherInput input = new PatternMatcherInput(
                useHeaders() 
                        ? context.getPreviousResult().getResponseHeaders()
                        : context.getPreviousResult().getResponseDataAsString()); // Bug 36898
        log.debug("MultiValueRegex = " + getRegex());
        try {
            Pattern pattern = patternCache.getPattern(getRegex(), Perl5Compiler.READ_ONLY_MASK);
            List matches = new ArrayList();
            int x = 0;
            boolean done = false;
            do {
                if (matcher.contains(input, pattern)) {
                    log.debug("MultiValueRegexExtractor: Match found!");
                    matches.add(matcher.getMatch());
                } else {
                    done = true;
                }
                x++;
            } while (x != matchLimit && !done);

            try {
                MatchResult match;
                if (matchLimit <=0) matchLimit = matches.size();
                
                String generatedResult = "";
                for (int i=1;i<=matchLimit;i++) {
                    match = getCorrectMatch(matches, i);
                    if (match != null) {
                        if (!"".equals(generatedResult)) {
                            generatedResult += templateSeparator;
                        }
                        generatedResult += generateResult(match);
                    }
                }
                
                if (null != generatedResult) {
                    vars.put(refName, generatedResult);
                }
            } catch (RuntimeException e) {
                log.warn("Error while generating result");
            }
        } catch (MalformedCachePatternException e) {
            log.warn("Error in pattern: " + getRegex());
        }
    }

    public Object clone() {
        MultiValueRegexExtractor cloned = (MultiValueRegexExtractor) super.clone();
        cloned.template = this.template;
        return cloned;
    }

    private String generateResult(MatchResult match) {
        StringBuffer result = new StringBuffer();
        for (int a = 0; a < template.length; a++) {
            log.debug("MultiValueRegexExtractor: Template piece #" + a + " = " + template[a]);
            if (template[a] instanceof String) {
                result.append(template[a]);
            } else {
                result.append(match.group(((Integer) template[a]).intValue()));
            }
        }
        log.debug("MultiValueRegexExtractor result = " + result.toString());
        return result.toString();
    }

    private void initTemplate() {
        if (template != null) {
            return;
        }
        List pieces = new ArrayList();
        List combined = new LinkedList();
        String rawTemplate = getTemplate();
        PatternMatcher matcher = (Perl5Matcher) localMatcher.get();
        Pattern templatePattern = patternCache.getPattern("\\$(\\d+)\\$"  // $NON-NLS-1$
                , Perl5Compiler.READ_ONLY_MASK
                & Perl5Compiler.SINGLELINE_MASK);
        log.debug("Pattern = " + templatePattern);
        log.debug("template = " + rawTemplate);
        Util.split(pieces, matcher, templatePattern, rawTemplate);
        PatternMatcherInput input = new PatternMatcherInput(rawTemplate);
        boolean startsWith = isFirstElementGroup(rawTemplate);
        log.debug("template split into " + pieces.size() + " pieces, starts with = " + startsWith);
        if (startsWith) {
            pieces.remove(0);// Remove initial empty entry
        }
        Iterator iter = pieces.iterator();
        while (iter.hasNext()) {
            boolean matchExists = matcher.contains(input, templatePattern);
            if (startsWith) {
                if (matchExists) {
                    combined.add(new Integer(matcher.getMatch().group(1)));
                }
                combined.add(iter.next());
            } else {
                combined.add(iter.next());
                if (matchExists) {
                    combined.add(new Integer(matcher.getMatch().group(1)));
                }
            }
        }
        if (matcher.contains(input, templatePattern)) {
            log.debug("Template does end with template pattern");
            combined.add(new Integer(matcher.getMatch().group(1)));
        }
        template = combined.toArray();
        templateSeparator = getTemplateSeparator();
    }

    private boolean isFirstElementGroup(String rawData) {
        try {
            Pattern pattern = patternCache.getPattern("^\\$\\d+\\$" // $NON-NLS-1$
                    , Perl5Compiler.READ_ONLY_MASK
                    & Perl5Compiler.SINGLELINE_MASK);
            return ((Perl5Matcher) localMatcher.get()).contains(rawData, pattern);
        } catch (RuntimeException e) {
            log.error("", e);
            return false;
        }
    }

    /**
     * Grab the appropriate result from the list.
     * 
     * @param matches
     *            list of matches
     * @param entry
     *            the entry number in the list
     * @return MatchResult
     */
    private MatchResult getCorrectMatch(List matches, int entry) {
        int matchSize = matches.size();

        if (matchSize <= 0 || entry > matchSize)
            return null;

        return (MatchResult) matches.get(entry - 1);
    }

    public void setRegex(String regex) {
        setProperty(REGEX, regex);
    }

    public String getRegex() {
        return getPropertyAsString(REGEX);
    }

    public void setRefName(String refName) {
        setProperty(REFNAME, refName);
    }

    public String getRefName() {
        return getPropertyAsString(REFNAME);
    }
    
    public void setTemplateSeparator(String separator) {
        setProperty(TEMPLATE_SEPARATOR, separator);
    }
    
    public String getTemplateSeparator() {
        return getPropertyAsString(TEMPLATE_SEPARATOR);
    }

    /**
     * Set which Match to use. This can be any positive number, indicating the
     * exact match to use, or 0, which is interpreted as meaning random.
     * 
     * @param matchNumber
     */
    public void setMatchLimit(int matchNumber) {
        setProperty(new IntegerProperty(MATCH_LIMIT, matchNumber));
    }

    public int getMatchLimit() {
        return getPropertyAsInt(MATCH_LIMIT);
    }

    /**
     * Sets the value of the variable if no matches are found
     * 
     * @param defaultValue
     */
    public void setDefaultValue(String defaultValue) {
        setProperty(DEFAULT, defaultValue);
    }

    public String getDefaultValue() {
        return getPropertyAsString(DEFAULT);
    }

    public void setTemplate(String template) {
        setProperty(TEMPLATE, template);
    }

    public String getTemplate() {
        return getPropertyAsString(TEMPLATE);
    }

    boolean useHeaders() {
        return "true".equalsIgnoreCase(getPropertyAsString(USEHEADERS));
    }
}
