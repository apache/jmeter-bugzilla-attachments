/*
 * Copyright 2003-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 */

package com.pa.jmeter.extractor.gui;

import java.awt.BorderLayout;
import java.util.ResourceBundle;

import org.apache.jmeter.processor.gui.AbstractPostProcessorGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;

import com.pa.jmeter.extractor.ResultStore;

/**
 * @author Geoff Willingham, PA Consulting Group.
 */
public class ResultStoreGui extends AbstractPostProcessorGui {
    private static final long serialVersionUID = 1;
    
    private static ResourceBundle resources = ResourceBundle.getBundle("com.pa.jmeter.resources.ResultStoreResources", JMeterUtils.getLocale());

    public ResultStoreGui() {
        super();
        init();
    }

    public String getLabelResource() {
        return "result_store_title";
    }
    
    public String getStaticLabel() {
        return resources.getString(getLabelResource());
    }    

    public void configure(TestElement el) {
        super.configure(el);
    }

    /**
     * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
     */
    public TestElement createTestElement() {
        ResultStore extractor = new ResultStore();
        modifyTestElement(extractor);
        return extractor;
    }

    /**
     * Modifies a given TestElement to mirror the data in the gui components.
     * 
     * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
     */
    public void modifyTestElement(TestElement extractor) {
        super.configureTestElement(extractor);
    }

    private void init() {
        setLayout(new BorderLayout());
        setBorder(makeBorder());

        add(makeTitlePanel(), BorderLayout.NORTH);
    }
}
