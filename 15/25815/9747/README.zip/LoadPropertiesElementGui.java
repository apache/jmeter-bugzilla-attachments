/*
 * ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001,2003 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in
 * the documentation and/or other materials provided with the
 * distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 * if any, must include the following acknowledgment:
 * "This product includes software developed by the
 * Apache Software Foundation (http://www.apache.org/)."
 * Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 * "Apache JMeter" must not be used to endorse or promote products
 * derived from this software without prior written permission. For
 * written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 * "Apache JMeter", nor may "Apache" appear in their name, without
 * prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package org.apache.jmeter.config.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.util.Properties;
import java.util.Enumeration;
import java.util.Collection;


import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.apache.jmeter.config.Argument;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.JMeterProperty;
import org.apache.jmeter.testelement.property.PropertyIterator;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jmeter.util.JMeterUtils;

/**
 * Default config gui for Configuration Element.
 *
 * @author     S.Chauhan (sonam.chauhan@ce.com.au)
 * @version    $Revision: 1.0 $
 */
public class LoadPropertiesElementGui extends AbstractConfigGui 
{

    /** 
     * This text field holds the input from the user, who enters 
     * the common starting part of the name of certain properties he wants
     * to load. For e.g., to load acme.user1.name and acme.user1.password, 
     * the user can enter 'acme.user1'. 
     */
    private JTextField propsPrefixField = new JTextField(15);

    private String previousPropsPrefix = ""; // Set to empty string

    /**
     * Boolean indicating whether this component is a standalong component or
     * it is intended to be used as a subpanel for another component.
     */
    private boolean standalone = true;

    /**
     * Create a new LoadPropertiesElementGui as a standalone component. 
     */
    public LoadPropertiesElementGui ()
    {
        standalone = true;
	  init();
    }

    /**
     * Create a new LoadPropertiesElementGui as an embedded component, using the 
     * specified title. Currently, label does nothing.
     *
     * @param label        the title for the component.
     */
    public LoadPropertiesElementGui (String label)
    {
        standalone = false;
        init();
    }

    /**
     * This is the list of menu categories this gui component will be available
     * under.
     *
     * @return   a Collection of Strings, where each element is one of the
     *           constants defined in MenuFactory
     */
    public Collection getMenuCategories()
    {
        if (standalone)
        {
            return super.getMenuCategories();
        }
        else
        {
            return null;
        }
    }


    /* Implements JMeterGUIComponent.getStaticLabel() */
    public String getStaticLabel()
    {
        return JMeterUtils.getResString("load_properties_element");
    }

   /* Implements JMeterGUIComponent.createTestElement() */
    public TestElement createTestElement()
    {
        Arguments args = new Arguments();
        modifyTestElement(args);
        return args;
    }

    /* Implements JMeterGUIComponent.modifyTestElement(TestElement) */
    public void modifyTestElement(TestElement args)
    {
	// The class variable 'previousPropsPrefix' stores the old prefix value
	// The automatic variable 'propsPrefix' references the modified prefix value
	String propsPrefix = propsPrefixField.getText();

	//Return if there is nothing to do
	if ( propsPrefix.equals(previousPropsPrefix) ) {
		return;
	}

	//Now carry out processing...
      args.setProperty(
          new StringProperty("property_prefix", propsPrefix));

      Arguments arguments = null;

	if (args instanceof Arguments)
   	{
	  arguments = (Arguments) args;
	  Properties jp = JMeterUtils.getJMeterProperties();

	  //First remove previous properties, 
	  removePropertiesWithPrefixFromArguments (jp, previousPropsPrefix, arguments);
   	  // then remove any 'old copies' of the new properties
	  removePropertiesWithPrefixFromArguments (jp, propsPrefix, arguments);
	  // finally, add new properties
	  addPropertiesWithPrefixToArguments (jp, propsPrefix, arguments);
	}

	// update class variable to store the new prefix value
	previousPropsPrefix = propsPrefix;

	this.configureTestElement(args);
    }

    /**
     * A newly created component can be initialized with the contents of
     * a Test Element object by calling this method.  The component is
     * responsible for querying the Test Element object for the
     * relevant information to display in its GUI.
     * 
     * @param el the TestElement to configure 
     */
    public  void configure(TestElement el)
    {
        // Somehow this causes all sorts of glitches... commenting out.
        //super.configure(el);

        propsPrefixField.setText( el.getPropertyAsString("property_prefix") );
        this.configureTestElement(el);
    }

     /**
     * Create a panel containing the propsPrefixField field and corresponding label.
     *
     * @return a GUI panel containing the propsPrefixField  field
     */
    private JPanel createPropsPrefixPanel()
    {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        JLabel label = new JLabel(JMeterUtils.getResString
		("property_names_begin_with"));
        label.setLabelFor(propsPrefixField);
        panel.add(label, BorderLayout.WEST);
        panel.add(propsPrefixField, BorderLayout.CENTER);
        return panel;
    }



   /**
    * Initialize the components and layout of this component.
    */
   private void init()
   {
       JPanel p= this;

        if (standalone)
        {
		 setLayout(new BorderLayout(0, 5));
		 setBorder(makeBorder());
	       add(makeTitlePanel(), BorderLayout.NORTH);
		 p = new JPanel();
	  }

        p.setLayout(new BorderLayout());
        p.add(createPropsPrefixPanel(), BorderLayout.NORTH);

        if (standalone)
        {
            add(p, BorderLayout.CENTER);
        }
   }




    private void addPropertiesWithPrefixToArguments (Properties p, 
		String prefix, Arguments arguments) 
    {
	  // The empty string is not a valid prefix - add nothing when it is passed
	  if (prefix.equals(""))
		return;	

	  Enumeration e = p.propertyNames();
	  while (e.hasMoreElements()) 
	  {
		String propName = (String) e.nextElement();

		// Add properties that begin with prefix.
		// This operates how the user expects because the prefix cannot be
		// an empty string present at this point. 
		if ( propName.startsWith(prefix) ) 
		{
			Argument arg = new Argument(propName.toString(), 
				p.getProperty(propName), "=") ;
            	arguments.addArgument(arg);
		}
	  }
    }
	
    private void removePropertiesWithPrefixFromArguments (Properties p, 
		String prefix, Arguments arguments) 
    {
	  // The empty string is not a valid prefix - remove nothing when it is passed
	  if (prefix.equals(""))
		return;	

	  Enumeration e = p.propertyNames();
	  while (e.hasMoreElements()) 
	  {
		String propName = (String) e.nextElement();

		// Remove properties that begin with prefix.
		// This operates how the user expects because the prefix cannot be
		// an empty string present at this point. 
		if ( propName.startsWith(prefix) ) 
		{
			Argument arg = new Argument(propName.toString(), 
				p.getProperty(propName), "=") ;
            	arguments.removeArgument(arg);
		}
	  }
    }


 
}