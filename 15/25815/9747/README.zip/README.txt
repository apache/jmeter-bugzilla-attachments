Steps for using the software.


1. Edit this file:
        jakarta-jmeter/src/core/org/apache/jmeter/resources/messages.properties
Add the following two lines below:
---------------------------------------
load_properties_element=Load Properties Element
property_names_begin_with=Property Names Begin With
---------------------------------------

2. In this directory:
	jakarta-jmeter/src/core/org/apache/jmeter/config/gui/
Install the attached file: LoadPropertiesElementGui.java


Notes: 

There is one issue I know of that I could not fix... the title of the Config element is always stuck at �Load Properties Element�
