/* 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jmeter.gui.util;

import org.apache.jorphan.util.JMeterException;

public class IconToolbarBean {
    //new=new;ActionNames.CLOSE;org/apache/jmeter/images/toolbar/new.png
    private String i18nKey = null;
    
    private String actionName = null;
    
    private String iconPath = null;
    
    private String iconPathPressed = null;

    public IconToolbarBean(String strToSplit) throws JMeterException {
        if (strToSplit == null) {
            throw new JMeterException("No icon definition"); //$NON-NLS-1$
        }
        String tmp[] = strToSplit.split(";"); //$NON-NLS-1$
        if (tmp.length > 2) {
            this.i18nKey = tmp[0];
            this.actionName = tmp[1];
            if (tmp[2].matches(" ")) { //$NON-NLS-1$
                String icons[] = tmp[2].split(" "); //$NON-NLS-1$
                this.iconPath = icons[0];
                this.iconPathPressed = icons[1];
            } else {
                this.iconPath = tmp[2];
            }
        } else {
            throw new JMeterException();
        }
    }

    /**
     * @return the i18nKey
     */
    public synchronized String getI18nKey() {
        return i18nKey;
    }

    /**
     * @param i18nKey the i18nKey to set
     */
    public synchronized void setI18nKey(String i18nKey) {
        this.i18nKey = i18nKey;
    }

    /**
     * @return the actionName
     */
    public synchronized String getActionName() {
        return actionName;
    }

    /**
     * @param actionName the actionName to set
     */
    public synchronized void setActionName(String actionName) {
        this.actionName = actionName;
    }

    /**
     * @return the iconPath
     */
    public synchronized String getIconPath() {
        return iconPath;
    }

    /**
     * @param iconPath the iconPath to set
     */
    public synchronized void setIconPath(String iconPath) {
        this.iconPath = iconPath;
    }

    /**
     * @return the iconPathPressed
     */
    public synchronized String getIconPathPressed() {
        return iconPathPressed;
    }

    /**
     * @param iconPathPressed the iconPathPressed to set
     */
    public synchronized void setIconPathPressed(String iconPathPressed) {
        this.iconPathPressed = iconPathPressed;
    }

}
