/* 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jmeter.gui.util;

import java.net.URL;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import org.apache.jmeter.gui.action.ActionNames;
import org.apache.jmeter.gui.action.ActionRouter;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.jorphan.util.JMeterException;
import org.apache.log.Logger;

/**
 * The JMeter main toolbar class
 *
 */
public class JMeterToolBar {
    
    private static final Logger log = LoggingManager.getLoggerForClass();

    // protected fields: JMeterToolBar class can be use to create another toolbar (plugin, etc.)
    protected static final String DEFAULT_ORDER = "new,open,close,save,save_as_testplan,|," + //$NON-NLS-1$
    		"cut,copy,paste,|,expand,collapse,toggle,|,test_start,test_stop,test_shutdown,|," + //$NON-NLS-1$
    		"test_start_remote_all,test_stop_remote_all,test_shutdown_remote_all,|," + //$NON-NLS-1$
    		"test_clear,test_clear_all,|,search,search_reset,|,function_helper,help"; //$NON-NLS-1$
    
    protected static final LinkedHashMap<String, IconToolbarBean> DEFAULT_ICONS = 
            new LinkedHashMap<String, IconToolbarBean>();
    
    protected static final String defaultIconProp = "org/apache/jmeter/images/toolbar/icons-toolbar.properties"; //$NON-NLS-1$
    
    protected static final String keyIconProp = "jmeter.toolbar.icons"; //$NON-NLS-1$
    
    /**
     * Create the default JMeter toolbar
     * @return the JMeter toolbar
     */
    public static JToolBar createToolbar(boolean visible) {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setVisible(visible);

        LinkedHashMap<String, IconToolbarBean> icons = getIconMappings();
        Collection<IconToolbarBean> enumIcons = icons.values();
        
        for (IconToolbarBean iconToolbarBean : enumIcons) {
            if (iconToolbarBean == null) {
                toolBar.addSeparator();
            } else {
                toolBar.add(makeButtonItemRes(iconToolbarBean));
            }
        }
        return toolBar;
    }
    
    /**
     * Generate a button component from icon bean
     * @param iconBean contains I18N key, ActionNames, icon path, optional icon path pressed
     * @return a button for toolbar
     */
    private static JButton makeButtonItemRes(IconToolbarBean iconBean) {
        final URL imageURL = JMeterUtils.class.getClassLoader().getResource(iconBean.getIconPath());
        JButton button = new JButton(new ImageIcon(imageURL));
        button.setToolTipText(JMeterUtils.getResString(iconBean.getI18nKey()));
        String iconPathPressed = iconBean.getIconPathPressed();
        if (iconPathPressed != null && iconPathPressed.length() > 0) {
            final URL imageURLPressed = JMeterUtils.class.getClassLoader().getResource(iconPathPressed);
            button.setPressedIcon(new ImageIcon(imageURLPressed));
        }
        button.addActionListener(ActionRouter.getInstance());
        String aName = null;
        try {
            aName = (String) (ActionNames.class.getField(iconBean.getActionName()).get(null));
        } catch (Exception e) {
            log.warn("Toolbar icon Action names error, use undefined action"); //$NON-NLS-1$
            aName = "NOT DEFINED"; //$NON-NLS-1$
        }
        button.setActionCommand(aName);
        return button;
    }
    
    private static LinkedHashMap<String, IconToolbarBean> getIconMappings() {
        String iconProp = JMeterUtils.getPropDefault(keyIconProp, defaultIconProp); //$NON-NLS-1$
        Properties p = JMeterUtils.loadProperties(iconProp);
        if (p == null && !iconProp.equals(defaultIconProp)) {
            log.info(iconProp + " not found - using " + defaultIconProp);
            iconProp = defaultIconProp;
            p = JMeterUtils.loadProperties(defaultIconProp);
        }
        if (p == null) {
            log.info(iconProp + " not found - using inbuilt icon set"); //$NON-NLS-1$
            return DEFAULT_ICONS;
        }
        log.info("Loading toolbar icons properties from " + iconProp); //$NON-NLS-1$
        
        String order = p.getProperty("toolbar", DEFAULT_ORDER); //$NON-NLS-1$
        p.remove("toolbar"); //$NON-NLS-1$
        String[] oList = order.split(","); //$NON-NLS-1$
        
        LinkedHashMap<String, IconToolbarBean> listIcons = new LinkedHashMap<String, IconToolbarBean>();
        int ctr = 1;
        for (String key : oList) {
            log.debug("Toolbar icon key: " + key); //$NON-NLS-1$
            if (key.trim().equals("|")) { //$NON-NLS-1$
                listIcons.put("space" + ctr++, null); //$NON-NLS-1$
            } else {
                try {
                    IconToolbarBean itb = new IconToolbarBean(p.getProperty(key));
                    listIcons.put(key, itb);
                } catch (JMeterException je) {
                    log.error("Toolbar icon loading error - key: " + key); //$NON-NLS-1$
                }
            }
        }
        return listIcons;
    }

    static {
        try {
            DEFAULT_ICONS.put("new", new IconToolbarBean("new;CLOSE;org/apache/jmeter/images/toolbar/new.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("open", new IconToolbarBean("menu_open;OPEN;org/apache/jmeter/images/toolbar/open.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("close", new IconToolbarBean("menu_close;CLOSE;org/apache/jmeter/images/toolbar/close.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("save", new IconToolbarBean("save;SAVE;org/apache/jmeter/images/toolbar/save.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("save_as_testplan", new IconToolbarBean("save_as;SAVE_AS;org/apache/jmeter/images/toolbar/saveastp.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space1", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("cut", new IconToolbarBean("cut;CUT;org/apache/jmeter/images/toolbar/cut.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("copy", new IconToolbarBean("copy;COPY;org/apache/jmeter/images/toolbar/copy.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("paste", new IconToolbarBean("paste;PASTE;org/apache/jmeter/images/toolbar/paste.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space2", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("expand", new IconToolbarBean("menu_expand_all;EXPAND_ALL;org/apache/jmeter/images/toolbar/expand.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("collapse", new IconToolbarBean("menu_collapse_all;COLLAPSE_ALL;org/apache/jmeter/images/toolbar/collapse.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("toggle", new IconToolbarBean("toggle;TOGGLE;org/apache/jmeter/images/toolbar/toggle.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space3", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_start", new IconToolbarBean("start;ACTION_START;org/apache/jmeter/images/toolbar/start.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_stop", new IconToolbarBean("stop;ACTION_STOP;org/apache/jmeter/images/toolbar/stop.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_shutdown", new IconToolbarBean("shutdown;ACTION_SHUTDOWN;org/apache/jmeter/images/toolbar/shutdown.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space4", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_start_remote_all", new IconToolbarBean("remote_start_all;REMOTE_START_ALL;org/apache/jmeter/images/toolbar/startremoteall.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_stop_remote_all", new IconToolbarBean("remote_stop_all;REMOTE_STOP_ALL;org/apache/jmeter/images/toolbar/stopremoteall.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_shutdown_remote_all", new IconToolbarBean("remote_shut_all;REMOTE_SHUT_ALL;org/apache/jmeter/images/toolbar/shutdownremoteall.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space5", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_clear", new IconToolbarBean("clear;CLEAR;org/apache/jmeter/images/toolbar/clear.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("test_clear_all", new IconToolbarBean("clear_all;CLEAR_ALL;org/apache/jmeter/images/toolbar/clearall.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space6", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("search", new IconToolbarBean("menu_search;SEARCH_TREE;org/apache/jmeter/images/toolbar/search.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("search_reset", new IconToolbarBean("menu_search_reset;SEARCH_RESET;org/apache/jmeter/images/toolbar/searchreset.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("space7", null); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("function_helper", new IconToolbarBean("function_dialog_menu_item;FUNCTIONS;org/apache/jmeter/images/toolbar/function.png")); //$NON-NLS-1$ $NON-NLS-2$
            DEFAULT_ICONS.put("help", new IconToolbarBean("help;HELP;org/apache/jmeter/images/toolbar/help.png")); //$NON-NLS-1$ $NON-NLS-2$
        } catch (JMeterException je) {
            log.error("Toolbar default icons loading error"); //$NON-NLS-1$
        }
    }

}
