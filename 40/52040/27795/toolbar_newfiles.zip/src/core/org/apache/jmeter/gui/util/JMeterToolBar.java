/* 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 * 
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jmeter.gui.util;

import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JToolBar;

import org.apache.jmeter.gui.action.ActionNames;
import org.apache.jmeter.gui.action.ActionRouter;
import org.apache.jmeter.util.JMeterUtils;

/**
 * The JMeter main toolbar class
 *
 */
public class JMeterToolBar {
    
    private static String ICON_NEW = "org/apache/jmeter/images/toolbar/new.png";
    
    private static String ICON_OPEN = "org/apache/jmeter/images/toolbar/open.png";
    
    private static String ICON_CLOSE = "org/apache/jmeter/images/toolbar/close.png";
    
    private static String ICON_SAVE = "org/apache/jmeter/images/toolbar/save.png";
    
    private static String ICON_SAVE_AS_TESTPLAN = "org/apache/jmeter/images/toolbar/saveastp.png";
    
    private static String ICON_CUT= "org/apache/jmeter/images/toolbar/cut.png";
    
    private static String ICON_COPY = "org/apache/jmeter/images/toolbar/copy.png";
    
    private static String ICON_PASTE = "org/apache/jmeter/images/toolbar/paste.png";
    
    private static String ICON_TEST_START = "org/apache/jmeter/images/toolbar/start.png";
    
    private static String ICON_TEST_STOP = "org/apache/jmeter/images/toolbar/stop.png";
    
    private static String ICON_TEST_SHUTDOWN = "org/apache/jmeter/images/toolbar/shutdown.png";
    
    private static String ICON_TEST_START_REMOTE_ALL = "org/apache/jmeter/images/toolbar/startremoteall.png";
    
    private static String ICON_TEST_STOP_REMOTE_ALL = "org/apache/jmeter/images/toolbar/stopremoteall.png";
    
    private static String ICON_TEST_SHUTDOWN_REMOTE_ALL = "org/apache/jmeter/images/toolbar/shutdownremoteall.png";
    
    private static String ICON_TEST_CLEAR = "org/apache/jmeter/images/toolbar/clear.png";
    
    private static String ICON_TEST_CLEAR_ALL = "org/apache/jmeter/images/toolbar/clearall.png";

    private static String ICON_TOGGLE = "org/apache/jmeter/images/toolbar/toggle.png";
    
    private static String ICON_EXPAND = "org/apache/jmeter/images/toolbar/expand.png";
    
    private static String ICON_COLLAPSE = "org/apache/jmeter/images/toolbar/collapse.png";
    
    private static String ICON_SEARCH = "org/apache/jmeter/images/toolbar/search.png";
    
    private static String ICON_SEARCH_RESET = "org/apache/jmeter/images/toolbar/searchreset.png";
    
    private static String ICON_FUNCTION_HELPER = "org/apache/jmeter/images/toolbar/function.png";

    private static String ICON_HELP = "org/apache/jmeter/images/toolbar/help.png";

    /**
     * @return the JMeter toolbar
     */
    public static JToolBar createToolbar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);

        toolBar.add(makeButtonItemRes("new", ActionNames.CLOSE, ICON_NEW)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("menu_open", ActionNames.OPEN, ICON_OPEN)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("menu_close", ActionNames.CLOSE, ICON_CLOSE)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("save", ActionNames.SAVE, ICON_SAVE)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("save_as", ActionNames.SAVE_AS, ICON_SAVE_AS_TESTPLAN)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("cut", ActionNames.CUT, ICON_CUT)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("copy", ActionNames.COPY, ICON_COPY)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("paste", ActionNames.PASTE, ICON_PASTE)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("menu_collapse_all", ActionNames.COLLAPSE_ALL, ICON_COLLAPSE)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("menu_expand_all", ActionNames.EXPAND_ALL, ICON_EXPAND)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("toggle", ActionNames.TOGGLE, ICON_TOGGLE)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("start", ActionNames.ACTION_START, ICON_TEST_START)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("stop", ActionNames.ACTION_STOP, ICON_TEST_STOP)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("shutdown", ActionNames.ACTION_SHUTDOWN, ICON_TEST_SHUTDOWN)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("remote_start_all", ActionNames.REMOTE_START_ALL, ICON_TEST_START_REMOTE_ALL)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("remote_stop_all", ActionNames.REMOTE_STOP_ALL, ICON_TEST_STOP_REMOTE_ALL)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("remote_shut_all", ActionNames.REMOTE_SHUT_ALL, ICON_TEST_SHUTDOWN_REMOTE_ALL)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("clear", ActionNames.CLEAR, ICON_TEST_CLEAR)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("clear_all", ActionNames.CLEAR_ALL, ICON_TEST_CLEAR_ALL)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("menu_search", ActionNames.SEARCH_TREE, ICON_SEARCH)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("menu_search_reset", ActionNames.SEARCH_RESET, ICON_SEARCH_RESET)); //$NON-NLS-1$
        toolBar.addSeparator();
        toolBar.add(makeButtonItemRes("function_dialog_menu_item", ActionNames.FUNCTIONS, ICON_FUNCTION_HELPER)); //$NON-NLS-1$
        toolBar.add(makeButtonItemRes("help", ActionNames.HELP, ICON_HELP)); //$NON-NLS-1$

        return toolBar;
    }
    
    private static JButton makeButtonItemRes(String resource, String actionCommand, String icon) {
        final URL imageURL = JMeterUtils.class.getClassLoader().getResource(icon);
        JButton button = new JButton(new ImageIcon(imageURL));
        button.setToolTipText(JMeterUtils.getResString(resource));
        button.setActionCommand(actionCommand);
        button.addActionListener(ActionRouter.getInstance());
        return button;
    }
}
