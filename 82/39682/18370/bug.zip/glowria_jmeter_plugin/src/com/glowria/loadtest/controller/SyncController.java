package com.glowria.loadtest.controller;

import org.apache.jmeter.control.GenericController;
import org.apache.jmeter.engine.util.NoThreadClone;
import org.apache.jmeter.samplers.Sampler;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * The sync controller is a special controller which wait that all
 * thread are at him before starting the inner sub test, and which
 * wait that the inner test stop before continuing.
 * 
 * It ensure that only one thread do the inner thread, and only this
 * thread ends up the controller. It is a workaround of bug #39675
 * 
 * @bugs http://issues.apache.org/bugzilla/show_bug.cgi?id=39675
 * @author glhez
 * 
 */
public class SyncController extends GenericController implements NoThreadClone {
  private static Logger log = LoggingManager.getLoggerForClass();
  private static final long serialVersionUID = 4350478640447863088L;

  @Override
  public void initialize() {
    log.debug(toString() + "." + Thread.currentThread().getName()
        + "::initialize()");
    super.initialize();
  }

  @Override
  public boolean isDone() {
    boolean b = super.isDone();
    log.debug(toString() + "." + Thread.currentThread().getName()
        + "::isDone() = " + b);
    return b;
  }

  @Override
  public Sampler next() {
    try {
      Sampler n = super.next();
      log.debug(toString() + "." + Thread.currentThread().getName()
          + "::next() = " + n);
      return n;
    } catch (ClassCastException e) {
      log.debug("CCE", e);
      return null;
    }
  }

}
