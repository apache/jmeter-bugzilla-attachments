package com.glowria.loadtest.gui;

import org.apache.jmeter.control.gui.LogicControllerGui;
import org.apache.jmeter.testelement.TestElement;

import com.glowria.loadtest.controller.SyncController;

public class SyncControllerGui extends LogicControllerGui {
  private static final long serialVersionUID = -6476282704860884740L;

  @Override
  public TestElement createTestElement() {
    SyncController sc = new SyncController();
    configureTestElement(sc);
    return sc;
  }

  @Override
  public String getStaticLabel() {
    return "Synchronizer Controller";
  }

  
}
