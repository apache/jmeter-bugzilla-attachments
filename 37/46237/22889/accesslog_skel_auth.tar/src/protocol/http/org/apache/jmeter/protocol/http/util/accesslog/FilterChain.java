package org.apache.jmeter.protocol.http.util.accesslog;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Vector;

import org.apache.jmeter.testelement.TestCloneable;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Chains all filter Filter specified by the values of the "accesslog.sampler.filterchain.*" properties.
 * @author ej
 */
public class FilterChain implements Filter, Serializable, TestCloneable
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = LoggingManager.getLoggerForClass();
  private Vector filters;
	
	/**
	 * Instantiate Filters in chain.
	 */
  public FilterChain()
  {
		filters = JMeterUtils.instantiate(JMeterUtils.getVector(JMeterUtils.getJMeterProperties(), 
    																												"accesslog.sampler.filterchain."), 
																			"org.apache.jmeter.protocol.http.util.accesslog.Filter");  	
  }

  /**
   * clone all filters in chain
   */
  public Object clone()
  {
  	// Filters require they be cloned...oddly
  	FilterChain f = new FilterChain();
  	f.filters = new Vector(filters.size());
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			f.filters.add(((TestCloneable) elements.nextElement()).clone());
		
  	return f;
  }
  
	public void excludeFiles( String[] filenames )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			((Filter) elements.nextElement()).excludeFiles( filenames );
	}

	public void excludePattern( String[] regexp )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			((Filter) elements.nextElement()).excludePattern( regexp );
	}

	public String filter( String text )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			text = ((Filter) elements.nextElement()).filter( text );
	
		return text;
	}

	public void includeFiles( String[] filenames )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			((Filter) elements.nextElement()).includeFiles( filenames );
	}

	public void includePattern( String[] regexp )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			((Filter) elements.nextElement()).includePattern( regexp );
	}

	public boolean isFiltered( String path, TestElement sampler )
	{
		boolean isFiltered = false;
		
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			isFiltered |= ((Filter) elements.nextElement()).isFiltered( path, sampler );
		
		return isFiltered;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.protocol.http.util.accesslog.Filter#filter()
	 */	
	public void reset()
	{
	}

	public void setReplaceExtension( String oldextension, String newextension )
	{
		for (Enumeration elements = filters.elements(); elements.hasMoreElements();)
			((Filter) elements.nextElement()).setReplaceExtension( oldextension, newextension );
	}

}
