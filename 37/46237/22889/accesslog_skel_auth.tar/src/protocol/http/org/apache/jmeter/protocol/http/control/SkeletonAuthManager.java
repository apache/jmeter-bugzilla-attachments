package org.apache.jmeter.protocol.http.control;

import java.io.Serializable;
import java.net.URL;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * An AuthManager that returns only the single Authorization it was instantiated with.
 * @author ej
 */
public class SkeletonAuthManager extends AuthManager implements Serializable
{
  private static final long serialVersionUID = 1L;
  private static final Logger log = LoggingManager.getLoggerForClass();

	Authorization authorization;
	
	public SkeletonAuthManager()
	{
		authorization = null;
	}
	
	public SkeletonAuthManager(String user, String password)
	{
		authorization = new Authorization(null, user, password, null, null);
	}
	
	public Authorization getAuthForURL(URL url) {
		log.debug("returning auth " + (authorization == null ? "null" : authorization.toBasicHeader()) + " for url " + url);
		return authorization;
	}
}
