/*
 *  ====================================================================
 *  The Apache Software License, Version 1.1
 *
 *  Copyright  (c) 2001-2003 The Apache Software Foundation.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Apache Software Foundation (http://www.apache.org/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Apache" and "Apache Software Foundation" and
 *  "Apache JMeter" must not be used to endorse or promote products
 *  derived from this software without prior written permission. For
 *  written permission, please contact apache@apache.org.
 *
 *  5. Products derived from this software may not be called "Apache",
 *  "Apache JMeter", nor may "Apache" appear in their name, without
 *  prior written permission of the Apache Software Foundation.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of the Apache Software Foundation.  For more
 *  information on the Apache Software Foundation, please see
 *  <http://www.apache.org/>.
 */
package org.apache.jmeter.samplers;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.*;

import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.engine.util.NoThreadClone;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestListener;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.log.Hierarchy;
import org.apache.log.Logger;

/**
 * Applabs Changes for Tuning JMeter Controller CPU
 * These changes provides three different modes for transferring Sample Results from the JMeter Servers to the Controller.
 * The transfer modes are
 * Live mode: Transferring Sample Results soon after receiving.
 * Batch mode: Transferrng Sample Results in batches.
 * End mode: Transferrng Sample Results all at the end of the test.
 *
 * We suggest Batch mode for tuning controller CPU. Tuning can be achieved by changing the values to the following
 * two parameters in the 'jmeter.properties' file
 * property1: remote_result_data_transfer_samples_batch_size(Default value is 200)
 * property2: sleep_between_two_samples_transfer (Default value is 10 milliseconds)
 *
 * Note: All the code lines with the comments '//Applabs:debug' and '//Applabs:info' can be removed
 * before updating the code to CVS. They are used for debugging and inofrmation purpose while running the tests or
 * instead of System.out.println logger can be used.
 *
 */

/**
 * @author unascribed
 * @version $Revision: 1.7 $
 */
public class RemoteListenerWrapper
        extends AbstractTestElement
        implements SampleListener, TestListener, Serializable, NoThreadClone {
    transient private static Logger log =
            Hierarchy.getDefaultHierarchy().getLoggerFor("jmeter.elements");
    RemoteSampleListener listener;

    /**
     * Applabs Changes: Start
     */
    private final static String REMOTE_RESULT_DATA_TRANSFER_MODE = "remote_result_data_transfer_mode";
    private final static String REMOTE_RESULT_DATA_TRANSFER_SAMPLES_BATCH_SIZE = "remote_result_data_transfer_samples_batch_size";
    private final int LIVE = 1;
    private final int PERIODIC = 2;
    private final int END = 3;
    //batch size
    private int SAMPLES_BATCH_SIZE = 100;
    //results transfer mode
    private int RESULTS_TRANSFER_MODE = LIVE;
    //sleep time if the data transfer mode is batch mode
    private int DESIGNED_SLEEP_TIME = 10;
    //Accumulating the results if the transfer mode is batch mode
    private ArrayList sampleEvents = new ArrayList(50);
    private ArrayList samplesToTransmit = new ArrayList();
    //just for debugging purpose. It Can be removed at the end
    private long totalNumberOfSamples = 0;//Applabs:Debug
    //just for debugging purpose. It Can be removed at the end
    private boolean testEnded = false;//Applabs:Debug
    /**
     * Applabs Changes: End
     */

    public RemoteListenerWrapper(RemoteSampleListener l) {
        listener = l;
    }

    public RemoteListenerWrapper() {
    }

    public void testStarted() {
        try {
            listener.testStarted();
        } catch (Exception ex) {
            log.error("", ex);
        }

    }

    public void testEnded() {
        try {
            listener.testEnded();
        } catch (Exception ex) {
            log.error("", ex);
        }
    }

    public void testStarted(String host) {
        /**
         * Applabs Changes: Start
         */
        totalNumberOfSamples = 0;//Applabs:Debug
        testEnded=false;//Applabs:Debug

        sampleEvents.clear();//Applabs:extraCare:when we go for the second round of testing without closing the remote server

        //get the property file values
        RESULTS_TRANSFER_MODE = JMeterUtils.getPropDefault(REMOTE_RESULT_DATA_TRANSFER_MODE, 1);
        DESIGNED_SLEEP_TIME = JMeterUtils.getPropDefault("sleep_between_two_samples_transfer",10);
        SAMPLES_BATCH_SIZE = JMeterUtils.getPropDefault(REMOTE_RESULT_DATA_TRANSFER_SAMPLES_BATCH_SIZE, 100);

        System.out.println("******* RESULTS_TRANSFER_MODE: "+RESULTS_TRANSFER_MODE);//Applabs:info
        System.out.println("******* DESIGNED_SLEEP_TIME : "+DESIGNED_SLEEP_TIME);//Applabs:info
        System.out.println("******* SAMPLES_BATCH_SIZE : "+SAMPLES_BATCH_SIZE);//Applabs:info
        /**
         * Applabs Changes: End
         */

        try {
            listener.testStarted(host);
        } catch (Exception ex) {
            log.error("", ex);
        }
    }

    public void testEnded(String host) {

        /**
         * Applabs Changes: Start
         */
        System.out.println("=========== totalNumberOfSamples at the stop is pressed: " + totalNumberOfSamples);//Applabs:debug
        testEnded=true;//Applabs:Debug
        //Some results might come after clicking the stop button. Then they will be handled as live results
        RESULTS_TRANSFER_MODE = LIVE;
        int numberOfSamplesToTransmit = sampleEvents.size();
        int sleepTime = DESIGNED_SLEEP_TIME;
        if(numberOfSamplesToTransmit>SAMPLES_BATCH_SIZE) sleepTime=0;
        System.out.println(">>>>>>>>>>>> sleepTime at testEnded : " + sleepTime);//Applabs:debug
        for (int i = 0; i < numberOfSamplesToTransmit; i++)
        {
            SampleEvent e = (SampleEvent) sampleEvents.get(i);
            try
            {
                listener.sampleOccurred(e);
                Thread.sleep(sleepTime);
            } catch (Exception excep)
            {
                excep.printStackTrace();
            }
        }

        //Clear all the samples data
        sampleEvents.clear();
        /**
         * Applabs Changes: End
         */

        //inform the controller that the test is ended
        if (listener != null) {
            try {
                listener.testEnded(host);
            } catch (Exception ex) {
                log.error("", ex);
            }
        }
    }

    /**
     * Applabs Changes: Start
     *
     * This method is completely changed
     */
    public void sampleOccurred(SampleEvent e)
    {
        totalNumberOfSamples++;//Applabs:Debug
        if(testEnded) System.out.println("=========== totalNumberOfSamples: " + totalNumberOfSamples);//Applabs:debug

        switch (RESULTS_TRANSFER_MODE) {
            //if the test data transfer mode is live or the stop button is clicked
            case LIVE:
                try {
                    listener.sampleOccurred(e);
                } catch (RemoteException err) {
                    log.error("", err);
                }
                break;

            //if the test data transfer mode is periodic
            case PERIODIC:
                synchronized (sampleEvents)
                {
                    sendResultsToController();
                    sampleEvents.add(e);
                }
                break;

            //if the test data transfer mode is end of the test
            case END:
                sampleEvents.add(e);
        }
    }
    /**
     * Applabs Changes: End
     */

    public void sampleStarted(SampleEvent e) {
        try {
            listener.sampleStarted(e);
        } catch (RemoteException err) {
            log.error("", err);
        }
    }

    public void sampleStopped(SampleEvent e) {
        try {
            listener.sampleStopped(e);
        } catch (RemoteException err) {
            log.error("", err);
        }
    }

    /* (non-Javadoc)
     * @see TestListener#testIterationStart(LoopIterationEvent)
     */
    public void testIterationStart(LoopIterationEvent event) {
    }

    /**
     * Applabs Changes: Start
     *
     * New method added
     */
    private void sendResultsToController() {
        int currentSamplesSize = sampleEvents.size();
        //size can be more than allowed size because of the sleep time
        if (currentSamplesSize >= SAMPLES_BATCH_SIZE) {
            int sleepTime = DESIGNED_SLEEP_TIME;
            synchronized(samplesToTransmit)
            {
                samplesToTransmit = (ArrayList)sampleEvents.clone();
                sampleEvents.clear();//clear and release sampleEvents arrayList
                int numberOfSamplesToTransmit = samplesToTransmit.size();
                //System.out.println(">>>>>>>>>>>> numberOfSamplesToTransmit: " + numberOfSamplesToTransmit );//Applabs:debug
                //if the number of samples are more than the allowed number, so as to avoid the accumulation of samples
                if(numberOfSamplesToTransmit>SAMPLES_BATCH_SIZE) sleepTime=0;
                //System.out.println(">>>>>>>>>>>> sleepTime in sendResultsToController : " + sleepTime);//Applabs:debug
                for (int j = 0; j < numberOfSamplesToTransmit; j++) {
                    SampleEvent se = (SampleEvent) samplesToTransmit.get(j);
                    try {
                        listener.sampleOccurred(se);
                        Thread.sleep(sleepTime);//sleep time before sending the next sample result
                    } catch (Exception excep) {
                        excep.printStackTrace();
                    }
                }
                samplesToTransmit.clear();
            }
        }
    }
    /**
     * Applabs Changes: End
     */

}