JMS Load Test Script

Load Test Folder Contents
---------------------------

    * test_plan/ - Contains JMeter Scripts
    * build.xml launch ant script
    * build.properties environemnt variables template

We need to to specify environment variables in file build.properties, or .build.properties

================================================
Dependencies
================================================
* Java SE 6 
* Apache Jakarta JMeter 2.6
* IBM Performance Harness for Java Message Service 1.20 (http://www.alphaworks.ibm.com/tech/perfharness)
* Apache Ant 1.8.2

================================================
Environment Preparation
================================================
* In Ant ClassPath (jars can be placed in $ANT_HOME/lib) we should add the following dependencies
--> JMeter Ant Task. Found in $JMETER_HOME/extras/ant-jmeter-1.0.9.jar: See http://www.programmerplanet.org/pages/projects/jmeter-ant-task.php.
* Place JMS Provider libraries under $JMETER_HOME/lib and $PERFHARNESS_HOME
* Create necessary queues in JMS Server

================================================
Executing the Ant Load Test
================================================
The load test can be executed from the command line using ant. The following environment variables can be specified passing the parameter "-D<variable>=<name>", or by specify them from the "build.properties" files.

We should placed the  custom enviroment variables in file named "local.properties". We should at least specify the jmeter.home. Default values can be found in file "build.properties"; use this as a template

Targets
jmeter:sender Executes the JMeter script test_plans/Sender.jmx
perfharness:sender Executes the test using Performance Harness for JMS

Main Env Variables
-------------------------------------------
jmeter.home=
perfharness=
duration  Run length in seconds. (default: 60)
threads   Number of WorkerThreads. (default: 1)
rampup   Time period (s) to ramp up to the full rate. (default: 0)
loop     Fixed number of iterations to run. (default: 0). Not used
iu       JNDI providerURL.  May also be set via standard JNDI methods
cf       JNDI name of ConnectionFactory.  Setting this property informs the tool that you intend to use JNDI lookups and any specific settings will be ignored.
ii       JNDI initialContextFactory.  May also be set via standard JNDI methods (see docs). (default: weblogic.jndi.WLInitialContextFactory)
ms       Message size in characters. (default: 1000)
d        JNDI Queue Destination

* Execution Example:
ant <subtarget name> -Dthreads=<number of threads> -Drampup=<jmeter ramp up> -Dduration=duration
ant jmeter:sender
ant perfharness:sender

The results for jmeter:* tasks will be placed in the file "results/<TESTNAME>_<N THREADS>threads_<RAMPUP>rampup_<LOOP>loop.jtl"
The results for perfharness:* tasks are displayed in console
