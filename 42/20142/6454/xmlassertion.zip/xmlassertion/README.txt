author: gottfried szing
email: gottfried@szing.at

goal
====
adding an XML assertion, which checks with the help of the jdom that the HTTP response content is well formed (not valid)

changes
=======
- apply patchfile.txt against the message*.properties; is just adding one additional entry for the xml assertion

- copy the GUI to the src/components/org/apache/jmeter/assertions/gui dir (where all other assertion guis resides) and the XML assertion itself to src/components/org/apache/jmeter/assertions/

