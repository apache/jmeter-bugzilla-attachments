The following is a list of steps to take before building and deploying this sampler in your test environment: 

1. Edit the project pom property "jmeter.home" to reflect the location of your local JMeter installation.

2. Edit the maven-compiler-plugin configuration in the project pom to reflect the desired source and target Java versions. 

3. Merge the contents of src/main/resources/messages.properties into the JMeter messages.properties file located in {jmeter.home}\src\core\org\apache\jmeter\resources.

4. Merge the contents of src/main/resources/saveservice.properties into the JMeter saveservice.properties file located in {jmeter.home}\bin.

5. Executing a Maven "install" will result in the build artifact, ApacheJMeter_amf.jar, being copied to {jmeter.home}\lib\ext\.  In addition, dependent artifacts, such as the requisite BlazeDS jars, are copied to {jmeter.home}\lib.  

NOTE: If while building this project in Eclipse you encounter the following error: "Error copying artifact from ...\classes to ...\\JMeter\lib\ext\ApacheJMeter_amf.jar", open the project properties, select Maven properties and uncheck "Resolve dependencies from Workspace projects".  This is a known issue with the Maven 2.x Dependency Plugin.