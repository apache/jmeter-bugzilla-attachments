The way to get the jmx jar is simple

1. open project.properties
2. change the lib.dir variable to point the jmeter/lib/ext folder.
3. use ant target type compile-jmx_plugin 
4. copy the jar created under dist in to the jmeter/lib/ext folder.
5. Now if you start jmeter you'll see two new things.
	1. jmx -sampler under samplers menu
	2. jmx - data writer under listners menu.

	-Smanya
