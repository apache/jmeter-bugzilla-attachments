package org.apache.jmeter.protocol.jmx.utils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.management.AttributeList;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanInfo;
import javax.management.MBeanServerConnection;
import javax.management.MalformedObjectNameException;
import javax.management.ObjectInstance;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

/**
 * The connector class. Exponses API to connect to any of local or remote mbean
 * servers supporting jmx rmi.
 * 
 * @author smanya.
 * 
 */
public class JMXConnectionAdapter {

	private static final String EMPTY = "";

	private static final String CREDENTIALS = "jmx.remote.credentials";

	private String userName = EMPTY;

	private String passWord = EMPTY;

	private JMXServiceURL jmxURL;

	private MBeanServerConnection connection;

	private static Map connectors = new HashMap();

	/*
	 * Create an instance of JMXAdapter givern the jmxUrl. jmxUrl is the fully
	 * qualified connection Url. @param jmxURL
	 */
	private JMXConnectionAdapter(JMXServiceURL jmxURL) {
		this.jmxURL = jmxURL;
	}

	/*
	 * This one is similer. But supports authentication. @param jmxURL @param
	 * userName @param passWord
	 */
	private JMXConnectionAdapter(JMXServiceURL jmxURL, String userName,
			String passWord) {
		this(jmxURL);
		this.userName = userName;
		this.passWord = passWord;
	}

	/*
	 * 
	 * @param host @param port @param userName @param passWord @throws
	 * JMXConnectionAdapterException
	 */
	private JMXConnectionAdapter(String host, int port, String userName,
			String passWord) throws JMXConnectionAdapterException {
		this.jmxURL = getJMXServiceURL(host, port);
		this.userName = userName;
		this.passWord = passWord;
	}

	/*
	 * Get a qualified service URL given the host and port.
	 */
	private JMXServiceURL getJMXServiceURL(String host, int port)
			throws JMXConnectionAdapterException {

		try {
			return new JMXServiceURL("rmi", host, port, "/jndi/rmi://" + host
					+ ":" + port + "/jmxrmi");
		} catch (MalformedURLException exception) {
			throw new JMXConnectionAdapterException(
					"Invalid host/port syntaxes.");
		}
	}

	/**
	 * Get an instance of the connection Adapter.
	 * 
	 * @param url
	 *            Service url
	 * @param userName
	 *            username
	 * @param passWord
	 *            password.
	 * @return connection adapter instance.
	 */
	public static JMXConnectionAdapter getConnectionAdapter(JMXServiceURL url,
			String userName, String passWord)
			throws JMXConnectionAdapterException {
		return new JMXConnectionAdapter(url, userName, passWord);
	}

	/**
	 * Get an instance of the connection Adapter.
	 * 
	 * @param url
	 *            Service url
	 * @return connection adapter instance.
	 */
	public static JMXConnectionAdapter getConnectionAdapter(JMXServiceURL url)
			throws JMXConnectionAdapterException {
		return new JMXConnectionAdapter(url);
	}

	/**
	 * Get an instance of the connection Adapter.
	 * 
	 * @param host
	 *            Service url
	 * @param port
	 *            Port number.
	 * @param userName
	 *            username
	 * @param passWord
	 *            password.
	 * @return connection adapter instance.
	 */

	public static JMXConnectionAdapter getConnectionAdapter(String host,
			int port, String userName, String passWord)
			throws JMXConnectionAdapterException {
		return new JMXConnectionAdapter(host, port, userName, passWord);
	}

	/*
	 * Get an instance of JMXConnector given the serviceUrl, userName, passWord.
	 */
	private static JMXConnector getConnector(JMXServiceURL jmxUrl,
			String userName, String passWord)
			throws JMXConnectionAdapterException {
		JMXConnector connector = (JMXConnector) JMXConnectionAdapter.connectors
				.get(jmxUrl + userName + passWord);
		try {
			if (connector == null) {
				Map environment = new HashMap();
				String[] credentials = new String[2];
				credentials[0] = userName;
				credentials[1] = passWord;
				environment.put(CREDENTIALS, credentials);
				connector = JMXConnectorFactory.connect(jmxUrl, environment);
				JMXConnectionAdapter.connectors.put(jmxUrl + userName
						+ passWord, connector);
				return connector;
			} else {
				return connector;
			}
		} catch (IOException exception) {
			throw new JMXConnectionAdapterException(
					"Can not create a connection to mbean server " + jmxUrl
							+ " for " + exception.getMessage());
		}
	}

	/*
	 * 
	 * @return and instance of MBeanserver connection. @throws
	 * JMXConnectionAdapterException
	 */
	protected MBeanServerConnection getMBeanServerConnection()
			throws JMXConnectionAdapterException {
		try {
			connection = JMXConnectionAdapter.getConnector(this.jmxURL,
					this.userName, this.passWord).getMBeanServerConnection();
		} catch (IOException exception) {
			try {
				/*
				 * Remove the cache entry and retry with a fresh connection.
				 */
				synchronized (connectors) {
					connectors.remove(jmxURL + userName + passWord);
					connection = JMXConnectionAdapter.getConnector(this.jmxURL,
							this.userName, this.passWord)
							.getMBeanServerConnection();
				}
			} catch (IOException ioexception) {
				throw new JMXConnectionAdapterException(
						"Can not get a new connection. Details "
								+ exception.getMessage());

			}
		}
		return connection;
	}

	/**
	 * Returns the list of domains in which any MBean is currently registered.
	 */
	public String[] getDomains() throws JMXConnectionAdapterException {
		try {
			return getMBeanServerConnection().getDomains();
		} catch (IOException exception) {
			throw new JMXConnectionAdapterException(
					"Can not get domain names for " + exception.getMessage());
		}
	}

	/**
	 * Get all mbean names.
	 * 
	 * @return
	 * @throws JMXConnectionAdapterException
	 */
	public ObjectName[] getMBeans() throws JMXConnectionAdapterException {
		return getMBeans(null);
	}

	/**
	 * Get all mbean names in the domain.
	 * 
	 * @param domain
	 *            name
	 * @return
	 * @throws JMXConnectionAdapterException
	 */
	public ObjectName[] getMBeans(String domain)
			throws JMXConnectionAdapterException {
		try {
			ObjectName objectName = null;
			if (domain != null) {
				objectName = new ObjectName(domain + ":*");
			}
			Set objectInstaceSet = getMBeanServerConnection().queryMBeans(
					objectName, null);
			ObjectName objectNames[] = new ObjectName[objectInstaceSet.size()];
			Iterator setIter = objectInstaceSet.iterator();
			int i = 0;
			while (setIter.hasNext()) {
				objectNames[i++] = ((ObjectInstance) setIter.next())
						.getObjectName();
			}
			return objectNames;
		} catch (MalformedObjectNameException nameException) {
			throw new JMXConnectionAdapterException("Invalid domain name. "
					+ nameException.getMessage());
		} catch (IOException exception) {
			throw new JMXConnectionAdapterException(
					"Unable to get the mbean list." + exception.getMessage());
		}
	}

	/**
	 * 
	 * @param mbeanname
	 *            mbean name.
	 * @return All the attributes of the mbean
	 * @throws JMXConnectionAdapterException
	 */
	public String[] getAttributeNames(ObjectName mbeanname)
			throws JMXConnectionAdapterException {
		MBeanInfo info = getMBeanInfo(mbeanname);
		MBeanAttributeInfo attributeInfo[] = info.getAttributes();
		String attributeNames[] = new String[attributeInfo.length];
		for (int i = 0; i < attributeInfo.length; i++) {
			attributeNames[i] = attributeInfo[i].getName();
		}
		return attributeNames;
	}

	/**
	 * Get MBean Info for a mbean.
	 * 
	 * @param mbeanName
	 * @return
	 * @throws JMXConnectionAdapterException
	 */
	public MBeanInfo getMBeanInfo(ObjectName mbeanName)
			throws JMXConnectionAdapterException {
		try {
			return getMBeanServerConnection().getMBeanInfo(mbeanName);
		} catch (InstanceNotFoundException notFoundException) {
			throw new JMXConnectionAdapterException(
					"Failed to get MBeanInfo. Instance not found."
							+ notFoundException.getMessage());
		} catch (IOException ioexception) {
			throw new JMXConnectionAdapterException(
					"Failed to get MBeanInfo. IO Error occured."
							+ ioexception.getMessage());
		} catch (ReflectionException reflectionException) {
			throw new JMXConnectionAdapterException(
					"Failed to get MBeanInfo.Can not create a local instance of mbean."
							+ reflectionException.getMessage());
		} catch (javax.management.IntrospectionException introspectionException) {
			throw new JMXConnectionAdapterException(
					"Failed to get MBeanInfo. Introspection error."
							+ introspectionException.getMessage());
		}
	}

	/**
	 * Returns a list of attribute values of a named MBean.
	 * 
	 * @param name
	 *            Mbean name.
	 * @param attributes
	 *            attributes whose values are to be read
	 * @return
	 * @throws JMXConnectionAdapterException
	 */
	public AttributeList getAttributes(String name, String[] attributes)
			throws JMXConnectionAdapterException {
		try {
			return getMBeanServerConnection().getAttributes(
					new ObjectName(name), attributes);
		} catch (InstanceNotFoundException instanceNotFoundException) {
			throw new JMXConnectionAdapterException(
					"Can not find the named mbean/attribute. "
							+ instanceNotFoundException.getMessage());
		} catch (ReflectionException reflectionException) {
			throw new JMXConnectionAdapterException(
					"Error in creating the local instance. "
							+ reflectionException.getMessage());
		} catch (IOException exception) {
			throw new JMXConnectionAdapterException(
					"Error in reading in the attributes. "
							+ exception.getMessage());
		} catch (MalformedObjectNameException nameException) {
			throw new JMXConnectionAdapterException(
					"Error in reading in the attributes. Malformed mbean name. Details "
							+ nameException.getMessage());
		}
	}

	/*
	 * Close the connector.
	 */
	private static void closeConnector(JMXConnector connector) {
		if (connector != null) {
			try {
				connector.close();
			} catch (IOException e) {
				/*
				 * Do nothing.
				 */
			}
		}
	}

	/**
	 * Dosconnect from a url.
	 * 
	 * @param url
	 * @param username
	 * @param password
	 */
	public static void disconnect(JMXServiceURL url, String username,
			String password) {
		JMXConnector connector = (JMXConnector) connectors.get(url + username
				+ password);
		closeConnector(connector);
	}

	/**
	 * Destroy all connections in pool.
	 * 
	 */
	public static void disconnectAll() {
		Iterator iterator = connectors.keySet().iterator();
		while (iterator.hasNext()) {
			String key = iterator.next().toString();
			JMXConnector connector = (JMXConnector) connectors.get(key);
			closeConnector(connector);
		}
	}

	/**
	 * Close all connections before destruction.
	 */
	protected void finalize() throws Throwable {
		super.finalize();
		disconnectAll();
	}

	/*
	 * Getters.
	 */
	public JMXServiceURL getJmxURL() {
		return jmxURL;
	}

	public String getPassWord() {
		return passWord;
	}

	public String getUserName() {
		return userName;
	}
}
