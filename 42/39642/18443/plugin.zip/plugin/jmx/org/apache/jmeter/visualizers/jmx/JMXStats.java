package org.apache.jmeter.visualizers.jmx;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.jmeter.protocol.jmx.sampler.JMXSampler;
import org.apache.jmeter.testelement.AbstractTestElement;

/**
 * Wrapper around JMX data.
 * 
 * @author smanya
 * 
 */
public class JMXStats extends AbstractTestElement implements Serializable {

	private static final long serialVersionUID = -7638286461432304984L;

	private static final String EMPTY = "";

	private List attributes;

	/**
	 * Default Constructor.
	 * 
	 */
	public JMXStats() {
		super();
		attributes = new ArrayList();
	}

	/**
	 * Create a JMXStats given an attribute string and timestamp
	 * 
	 * @param attributeString
	 * @param timeStamp
	 */
	public JMXStats(String attributeString) {
		this();
		loadAttributes(attributeString);
	}

	/**
	 * 
	 * @param key
	 *            Set attribute with key 'key'
	 * @param value
	 *            value 'value'
	 */
	public void setAttribute(String key, String value) {
		setProperty(key, value);
	}

	/**
	 * 
	 * @param key
	 * @return return attrib value for key.
	 */
	public String getAttribute(String key) {
		return getProperty(key).getStringValue();
	}

	/**
	 * 
	 * @param data
	 *            JMX sample result data.
	 * @param timeStamp
	 *            timestamp for the sample.
	 */
	public void loadAttributes(String data) {
		String[] stmts = data.split(JMXSampler.STMTSEPARATOR);
		for (int i = 0; i < stmts.length; i++) {
			String[] fields = stmts[i].split(JMXSampler.ASSIGN);
			if (fields.length == 0) {
				continue;
			} else if (fields[0].equalsIgnoreCase(JMXSampler.PROTOCOL)
					|| fields[0].equalsIgnoreCase(JMXSampler.GLOBAL_MBEAN_NAME)
					|| fields[0].equalsIgnoreCase(JMXSampler.LOCAL_MBEAN_NAME)) {
				continue;
			} else {
				String value = EMPTY;
				for (int j = 1; j < fields.length; j++) {
					value += fields[j];
				}
				setAttribute(fields[0], value);
				attributes.add(fields[0]);
			}
		}
	}

	/**
	 * Return all the attribute names for JMXStats.
	 * 
	 * @return
	 */
	public List getAttributeKeys() {
		return attributes;
	}
}
