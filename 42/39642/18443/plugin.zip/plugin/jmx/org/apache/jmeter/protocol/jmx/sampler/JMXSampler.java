package org.apache.jmeter.protocol.jmx.sampler;

import java.lang.reflect.Array;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.openmbean.CompositeData;
import javax.management.openmbean.TabularData;

import org.apache.jmeter.protocol.jmx.utils.JMXConnectionAdapter;
import org.apache.jmeter.protocol.jmx.utils.JMXConnectionAdapterException;
import org.apache.jmeter.samplers.AbstractSampler;
import org.apache.jmeter.samplers.Entry;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.IntegerProperty;
import org.apache.jmeter.testelement.property.ObjectProperty;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import com.thoughtworks.xstream.XStream;

public class JMXSampler extends AbstractSampler {

	private static final String EMPTY = "";

	public static final String LOCAL_MBEAN_NAME = "local_mbean_name";

	public static final String GLOBAL_MBEAN_NAME = "global_mbean_name";

	public static final String SERVER_NAME = "servername";

	public static final String PROTOCOL = "protocol";

	public static final String JMX = "jmx";

	public static final String ASSIGN = "==";

	public static final String STMTSEPARATOR = ";;";

	private static final long serialVersionUID = 3315471300025436045L;

	private static final Logger log = LoggingManager.getLoggerForClass();

	public static final String HOST = "JMXSampler.host";

	public static final String PORT = "JMXSampler.port";

	public static final String USERNAME = "JMXSampler.userName";

	public static final String PASSWORD = "JMXSampler.PassWord";

	public static final String MBEANS = "JMXSampler.mBeans";

	/**
	 * Constructor.
	 * 
	 */
	public JMXSampler() {
		setProperty(new StringProperty(TestElement.NAME, "JMX Request"));
	}

	/**
	 * Do a jmx sample
	 * 
	 * @return sample so sampled. :O
	 */
	public SampleResult sample() {
		return sample(null);
	}

	/**
	 * Get all the mbean names to be read from server
	 * 
	 * @return
	 */
	public String[] getMBeanKeys() {
		Map mbeanMap = (Map) getProperty(MBEANS).getObjectValue();
		if (mbeanMap == null) {
			return new String[0];
		}
		Iterator mbeanIter = mbeanMap.keySet().iterator();
		String names[] = new String[mbeanMap.size()];
		for (int i = 0; i < names.length; i++) {
			names[i] = mbeanIter.next().toString();
		}
		return names;
	}

	/**
	 * 
	 * @param key
	 *            name of mbean of which the attributes are to be read.
	 * @return the selected attributes.
	 */
	public String[] getAttributesForKey(String key) {
		Map mbeanMap = (Map) getProperty(MBEANS).getObjectValue();
		if (mbeanMap == null) {
			log.debug("Zero mbeans to sample.");
			return new String[0];
		}
		AbstractMBean abstraction = (AbstractMBean) mbeanMap.get(key);
		Set attrs = abstraction.getAttributes();
		Iterator iterator = attrs.iterator();
		String strattr[] = new String[attrs.size()];
		for (int i = 0; i < strattr.length; i++) {
			strattr[i] = iterator.next().toString();
		}
		return strattr;
	}

	/**
	 * Get the local name.
	 * 
	 * @param mbeanName
	 *            mbean name for the mbean.
	 * @return
	 */
	public String getLocalMBeanNameForKey(String key) {
		Map mbeanMap = (Map) getProperty(MBEANS).getObjectValue();
		if (mbeanMap == null) {
			log.debug("Zero mbeans to sample.");
			return null;
		}
		AbstractMBean abstraction = (AbstractMBean) mbeanMap.get(key);
		return abstraction.getLocalName();
	}

	/**
	 * Given the key get corresponding mbean name.
	 * @param key
	 * @return
	 */
	public String getMBeanNameForKey(String key) {
		Map mbeanMap = (Map) getProperty(MBEANS).getObjectValue();
		if (mbeanMap == null) {
			log.debug("Zero mbeans to sample.");
			return null;
		}
		AbstractMBean abstraction = (AbstractMBean) mbeanMap.get(key);
		return abstraction.getMBeanName();
	}

	/**
	 * Sample.
	 * 
	 * @param entry
	 *            not used.
	 * @return Sample Result.
	 */
	public SampleResult sample(Entry entry) {

		JMXSampleResult result = new JMXSampleResult();
		String responseData = EMPTY;
		String keys[] = getMBeanKeys();
		try {
			JMXConnectionAdapter adapter = JMXConnectionAdapter
					.getConnectionAdapter(getHost(), getPort(), getUserName(),
							getPassWord());
			result.sampleStart();
			for (int i = 0; i < keys.length; i++) {
				String mbeanLocalName = getLocalMBeanNameForKey(keys[i]);
				String attributes[] = getAttributesForKey(keys[i]);
				AttributeList attributeList = adapter.getAttributes(
						getMBeanNameForKey(keys[i]), attributes);
				Iterator attribIterator = attributeList.iterator();
				while (attribIterator.hasNext()) {
					Attribute attribute = (Attribute) attribIterator.next();
					responseData = getStringValue(attribute, mbeanLocalName)
							+ responseData;
				}
				responseData = SERVER_NAME + ASSIGN + getHost() + STMTSEPARATOR
						+ responseData;
				responseData = LOCAL_MBEAN_NAME + ASSIGN + mbeanLocalName
						+ STMTSEPARATOR + responseData;
				responseData = GLOBAL_MBEAN_NAME + ASSIGN
						+ getMBeanNameForKey(keys[i]) + STMTSEPARATOR
						+ responseData;
			}
			responseData = PROTOCOL + "==" + JMX + ";;" + responseData;
			result.sampleEnd();
			result.setResponseData(responseData.getBytes());
			result.setSuccessful(true);
			return result;
		} catch (JMXConnectionAdapterException adapterException) {
			log
					.error("Sample failed. Details "
							+ adapterException.getMessage());
			result.setSuccessful(false);
			return result;
		}
	}

	/*
	 * Below are routines that convert a complex mbean attribute into simple
	 * datatype components. And get a hierarchical name for the same.
	 */

	/*
	 * Get string value of the attribute name.
	 */
	protected String getStringValue(Attribute attribute, String prefixVal) {
		Object attributeValue = attribute.getValue();
		String prefix;
		if (prefixVal.length() > 0) {
			prefix = prefixVal + "." + attribute.getName();
		} else {
			prefix = attribute.getName();
		}
		return getStringValue(attributeValue, prefix);
	}

	// TODO : Support tabular type mbeans also.

	/*
	 * Get the string value of the attribute.
	 * 
	 * @param attributeValue The value returned for attrib. @param prefix prefix
	 * for the attribute name derived sofar. @return
	 */
	protected String getStringValue(Object attributeValue, String prefix) {
		if (attributeValue instanceof CompositeData) {
			return getCompositeStringValue((CompositeData) attributeValue,
					prefix);
		} else {
			if (attributeValue instanceof TabularData) {
				log
						.warn("The attribute "
								+ prefix
								+ " is of tabular type and this is not currently supported");
				log.info("Details : \n" + new XStream().toXML(attributeValue));
			}
			return getStringValueOfSimpleType(attributeValue, prefix);
		}
	}

	/*
	 * Get values for simple Type.
	 * 
	 * @param attributeValue Value of attribute @param prefix prefix string
	 * derived sofar. @return
	 */
	protected String getStringValueOfSimpleType(Object attributeValue,
			String prefix) {

		if (attributeValue.getClass().isArray()) {
			int arrayLength = Array.getLength(attributeValue);
			String response = EMPTY;
			for (int i = 0; i < arrayLength; i++) {
				response = response
						+ getStringValueOfSimpleType(Array.get(attributeValue,
								i), prefix + "." + i);
			}
			return response;
		} else {
			return prefix + ASSIGN + attributeValue.toString() + STMTSEPARATOR;
		}
	}

	/*
	 * Get the composite attribute components.
	 * 
	 * @param data Attribute data @param prefix prefix string derived sofar.
	 * @return
	 */
	protected String getCompositeStringValue(CompositeData data, String prefix) {
		Iterator iterator = data.getCompositeType().keySet().iterator();
		String response = EMPTY;
		while (iterator.hasNext()) {
			Object key = iterator.next();
			Object val = data.get(key.toString());
			response += getStringValue(val, prefix + "." + key);
		}
		return response;
	}

	/**
	 * Get the label.
	 * 
	 * @return
	 */
	public String getLabel() {
		return ("JMX Request");
	}

	/**
	 * 
	 * @param mbeanName
	 *            mbean name.
	 * @return attributes for the mbean in a ';' separated string.
	 */
	public String getAttributsAsString(String mbeanName, String localName) {
		return getAttributsAsStringForKey(mbeanName + localName);
	}

	public String getAttributsAsStringForKey(String key) {
		String response = EMPTY;
		String attributes[] = getAttributesForKey(key);
		for (int i = 0; i < attributes.length; i++) {
			response += attributes[i] + ";";
		}
		return response;
	}

	/*
	 * Getters
	 * 
	 */
	public String getHost() {
		return getPropertyAsString(JMXSampler.HOST);
	}

	public int getPort() {
		return getPropertyAsInt(JMXSampler.PORT);
	}

	public String getUserName() {
		return getPropertyAsString(JMXSampler.USERNAME);
	}

	public String getPassWord() {
		return getPropertyAsString(JMXSampler.PASSWORD);
	}

	public Map getMBeanMap() {
		return (Map) getProperty(JMXSampler.MBEANS);
	}

	/*
	 * Setters
	 * 
	 */
	public void setHost(String host) {
		setProperty(new StringProperty(JMXSampler.HOST, host));
	}

	public void setPort(int port) {
		setProperty(new IntegerProperty(JMXSampler.PORT, port));
	}

	public void setUserName(String userName) {
		setProperty(new StringProperty(JMXSampler.USERNAME, userName));
	}

	public void setPassword(String password) {
		setProperty(new StringProperty(JMXSampler.PASSWORD, password));
	}

	/**
	 * Add a mbean to sampler.
	 * 
	 * @param abstraction
	 */
	public void addMBean(AbstractMBean abstraction) {
		Map mbeanMap = (Map) getProperty(JMXSampler.MBEANS).getObjectValue();
		if (mbeanMap == null) {
			mbeanMap = new HashMap();
		}
		mbeanMap.put(abstraction.getMBeanName() + abstraction.getLocalName(),
				abstraction);
		setProperty(new ObjectProperty(JMXSampler.MBEANS, mbeanMap));
	}

	/**
	 * Clear all mbeans in the sampler.
	 * 
	 */
	public void clearMBeans() {
		Map mbeanMap = (Map) getProperty(MBEANS).getObjectValue();
		if (mbeanMap != null) {
			mbeanMap.clear();
			mbeanMap = null;
		}
	}
}
