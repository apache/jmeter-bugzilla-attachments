package org.apache.jmeter.visualizers.jmx;

import org.apache.jmeter.testelement.AbstractTestElementBeanInfo;

/**
 * @author smanya
 * 
 */
public class JMXDataCollectorBeanInfo extends AbstractTestElementBeanInfo {

}