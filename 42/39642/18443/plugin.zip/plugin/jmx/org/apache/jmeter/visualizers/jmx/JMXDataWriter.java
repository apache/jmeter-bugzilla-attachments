package org.apache.jmeter.visualizers.jmx;

import java.awt.BorderLayout;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.apache.jmeter.gui.AbstractJMeterGuiComponent;
import org.apache.jmeter.gui.UnsharedComponent;
import org.apache.jmeter.gui.util.FilePanel;
import org.apache.jmeter.gui.util.MenuFactory;
import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.protocol.jmx.sampler.JMXSampler;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.visualizers.Printable;
import org.apache.jmeter.visualizers.Visualizer;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Visualizer class for JMX. It understands JMX protocol info and dumps it to a
 * file in XML.
 * 
 * @author smanya.
 * 
 */
public class JMXDataWriter extends AbstractJMeterGuiComponent implements
		Visualizer, ChangeListener, UnsharedComponent, Printable {

	JMXDataCollector collector;

	private static final long serialVersionUID = -4912163369021908282L;

	private static final Logger log = LoggingManager.getLoggerForClass();

	private FilePanel filePanel;

	PrintWriter outWriter;

	/**
	 * Slave mode. Just to write the results of collector.
	 * 
	 * @param collector
	 */
	public JMXDataWriter(boolean slave) {
		filePanel = new FilePanel(JMeterUtils
				.getResString("file_visualizer_output_file"), ".jtl");
		if (!slave) {
			filePanel.addChangeListener(this);
			createTestElement();
			init();
		}
	}

	/**
	 * set the target file name.
	 * 
	 * @param name
	 */
	public void setFileName(String name) {
		filePanel.setFilename(name);
	}

	/**
	 * Creates JMXDataWriter in master mode. i.e controls the Collector.
	 * 
	 */
	public JMXDataWriter() {
		this(false);
	}

	public void add(SampleResult result) {
		try {
			JMXStats stats = new JMXStats(new String(result.getResponseData()));
			writeStats(stats, result.getTimeStamp());
		} catch (Exception exception) {
			/*
			 * Ignore for now.
			 */
			log
					.warn("Error while adding collector data for the jmx sampler. Details "
							+ exception.getMessage());
		}

	} /*
		 * Create a gui header. (with a title and a file panel.)
		 */

	protected JPanel makeDataWriterHeader() {
		JPanel panel = new VerticalPanel();
		panel.add(makeTitlePanel());
		panel.add(filePanel);
		return panel;
	}

	/**
	 * Initialize the component in the UI
	 */
	private void init() {
		setLayout(new BorderLayout());
		setBorder(makeBorder());
		add(makeDataWriterHeader(), BorderLayout.NORTH);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getLabelResource()
	 */
	public String getLabelResource() {
		return "";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getStaticLabel()
	 */
	public String getStaticLabel() {
		return "JMX DataWriter";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.visualizers.Visualizer#isStats()
	 */
	public boolean isStats() {
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.event.ChangeListener#stateChanged(javax.swing.event.ChangeEvent)
	 */
	public void stateChanged(ChangeEvent e) {
		collector = (JMXDataCollector) createTestElement();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		if (collector == null) {
			collector = new JMXDataCollector();
			modifyTestElement(collector);
		}
		return collector;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#configure(org.apache.jmeter.testelement.TestElement)
	 */
	public void configure(TestElement el) {
		super.configure(el);
		filePanel
				.setFilename(el.getPropertyAsString(JMXDataCollector.FILENAME));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(org.apache.jmeter.testelement.TestElement)
	 */
	public void modifyTestElement(TestElement element) {
		super.configureTestElement(element);
		if (element instanceof JMXDataCollector) {
			JMXDataCollector collector = (JMXDataCollector) element;
			collector.setFilename(filePanel.getFilename());
			collector.setListener(this);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createPopupMenu()
	 */
	public JPopupMenu createPopupMenu() {
		return MenuFactory.getDefaultVisualizerMenu();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#getMenuCategories()
	 */
	public Collection getMenuCategories() {
		return Arrays.asList(new String[] { MenuFactory.LISTENERS });
	}

	/*
	 * Record stats.
	 */
	protected synchronized void writeStats(JMXStats stats, long timeStamp)
			throws IOException {
		if (null == outWriter) {
			initializeFileOutput();
		}
		String servname = stats.getAttribute(JMXSampler.SERVER_NAME);
		if (outWriter != null) {
			Iterator keyIter = stats.getAttributeKeys().iterator();
			while (keyIter.hasNext()) {
				String prop = keyIter.next().toString();
				if (prop.equalsIgnoreCase(JMXSampler.SERVER_NAME)) {
					continue;
				}
				String val = stats.getPropertyAsString(prop);
				/*
				 * Filter failed requests.
				 */
				if (prop.length() == 0 && val.length() == 0) {
					return;
				}
				outWriter.println("<sample servername=\"" + servname
						+ "\" name=\"" + prop + "\" value=\"" + val + "\" "
						+ "timeStamp=\"" + timeStamp + "\"/>");
			}
		}
	}

	/**
	 * Initialize the out stream for data records.
	 * 
	 * @throws IOException
	 */
	public synchronized void initializeFileOutput() throws IOException {
		String filename = filePanel.getFilename();
		if (null == outWriter && null != filename) {
			if (null == outWriter) {
				try {
					outWriter = new PrintWriter(filename);
					outWriter.println("<monitorResults>");
				} catch (FileNotFoundException e) {
					outWriter = null;
					log
							.error("Can not initialize file out put stream. Details "
									+ e.getMessage());
				}
			}
		}
	}

	/**
	 * Close the data dump stream.
	 * 
	 */
	public synchronized void finalizeFileOutput() {
		if (outWriter != null) {
			outWriter.println("</monitorResults>");
			outWriter.close();
			outWriter = null;
		}
	}

}