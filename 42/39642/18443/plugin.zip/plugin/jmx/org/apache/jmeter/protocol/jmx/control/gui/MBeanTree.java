package org.apache.jmeter.protocol.jmx.control.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.Rectangle;
import java.awt.event.ActionListener;
import java.util.Enumeration;

import javax.management.ObjectName;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.border.LineBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import org.apache.jmeter.gui.util.PowerTableModel;
import org.apache.jmeter.protocol.jmx.utils.JMXConnectionAdapter;
import org.apache.jmeter.protocol.jmx.utils.JMXConnectionAdapterException;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Tree to display the mbeans available and select the ones that are to be
 * monitored.
 * 
 * @author smanya.
 * 
 */
public class MBeanTree extends JDialog implements TreeSelectionListener {

	public static final String ADD_ATTRIBUTES = "add_attributes";

	private static final long serialVersionUID = -6005714514648263615L;

	private static final Logger log = LoggingManager.getLoggerForClass();

	private static final String ATTR_HDR = "Attributes";

	private JTree mbeanTree;

	private JTable attributeTable;

	private PowerTableModel attributeTablemodel;

	private DefaultTreeModel mbeanTreeModel;

	private String host;

	private int port;

	private String username;

	private String password;

	private JMXConnectionAdapter connection;

	private ActionListener listener;

	public MBeanTree(ActionListener listener) {
		this.listener = listener;
		initgui();

	}

	/*
	 * Intialize the gui for mbean dialog.
	 * 
	 */
	private void initgui() {
		setModal(true);
		setDimentions();
		JPanel all = new JPanel(new BorderLayout());
		JSplitPane mainSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
		mainSplit.setDividerLocation(250);
		mainSplit.setLeftComponent(createTreePanel());
		mainSplit.setRightComponent(createAttributePanel());
		all.add(mainSplit, BorderLayout.CENTER);
		all.add(createButtonPanel(), BorderLayout.SOUTH);
		this.add(all);
	}

	/*
	 * The Mbean add button.
	 */
	private JPanel createButtonPanel() {
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		JButton button = new JButton("Add");
		button.setActionCommand(ADD_ATTRIBUTES);
		button.addActionListener(this.listener);
		buttonPanel.add(button);
		return buttonPanel;
	}

	/*
	 * The TreePanel that displays all mbeans.
	 */
	private JScrollPane createTreePanel() {
		JPanel treePanel = new JPanel(new BorderLayout());
		treePanel.setBorder(new LineBorder(Color.BLACK));
		treePanel.setBackground(Color.WHITE);
		mbeanTreeModel = new DefaultTreeModel(new DefaultMutableTreeNode(
				new String("MBeans")));
		mbeanTree = new JTree(mbeanTreeModel);
		mbeanTree.addTreeSelectionListener(this);
		treePanel.add(mbeanTree, BorderLayout.CENTER);
		return new JScrollPane(treePanel);
	}

	/*
	 * Table to show attributes of selected mbean.
	 */
	private JPanel createAttributePanel() {
		JPanel attributePanel = new JPanel(new BorderLayout());
		attributePanel.setBorder(new LineBorder(Color.BLACK));
		attributeTablemodel = new PowerTableModel(new String[] { ATTR_HDR },
				new Class[] { String.class });
		attributeTable = new JTable(attributeTablemodel);
		attributePanel
				.add(new JScrollPane(attributeTable), BorderLayout.CENTER);
		return attributePanel;
	}

	/*
	 * Intialze data in gui.
	 */
	private void initdata() throws JMXConnectionAdapterException {
		initTreeData();
	}

	/*
	 * Populate tree with mbeans available.
	 */
	private void initTreeData() throws JMXConnectionAdapterException {
		connection = JMXConnectionAdapter.getConnectionAdapter(host, port,
				username, password);
		String domains[] = connection.getDomains();
		DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode) mbeanTreeModel
				.getRoot();
		rootNode.removeAllChildren();
		for (int i = 0; i < domains.length; i++) {
			DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode(
					domains[i]);
			rootNode.add(treeNode);
			ObjectName[] objectNames = connection.getMBeans(domains[i]);
			for (int j = 0; j < objectNames.length; j++) {
				log.error(objectNames[j].getCanonicalKeyPropertyListString());
				addNode(treeNode, objectNames[j]);
			}
		}
		mbeanTree.clearSelection();
		attributeTablemodel.clearData();
		mbeanTreeModel.reload();
	}

	/*
	 * Add an object name to the given tree node.
	 */
	private void addNode(DefaultMutableTreeNode node, ObjectName name) {
		String categories[] = name.getKeyPropertyListString().split(",");
		MBeanObjectNameWrapper wrapper = new MBeanObjectNameWrapper(name);
		for (int j = categories.length - 1; j >= 0; j--) {
			String fields[] = categories[j].split("=");
			Enumeration childEnum = node.children();
			boolean childExists = false;
			while (childEnum.hasMoreElements()) {
				DefaultMutableTreeNode childNode = (DefaultMutableTreeNode) childEnum
						.nextElement();
				if (!fields[1].equalsIgnoreCase(wrapper.toString())) {
					if (childNode.toString().equalsIgnoreCase(fields[1])) {
						node = childNode;
						childExists = true;
						break;
					}
				}
			}
			if (!childExists) {
				if (!fields[1].equalsIgnoreCase(wrapper.toString())) {
					DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(
							fields[1]);
					node.add(childNode);
					node = childNode;
				}
			}
		}
		node.add(new DefaultMutableTreeNode(wrapper));
	}

	/*
	 * Dimensions for dialog.
	 */
	private void setDimentions() {
		this.setBounds(new Rectangle(500, 400));
	}

	/*
	 * Update attributes if a selection changes in gui. @param node
	 */
	private void updateAttributes(DefaultMutableTreeNode node) {
		try {
			attributeTablemodel.clearData();
			if (node.isLeaf()) {
				String attributes[] = connection
						.getAttributeNames(((MBeanObjectNameWrapper) node
								.getUserObject()).getObjectName());
				for (int i = 0; i < attributes.length; i++) {
					attributeTablemodel.addRow(new String[] { attributes[i] });
					log.debug(attributes[i]);
				}
				if (attributes.length == 0) {
					log.debug("No attributes for "
							+ ((MBeanObjectNameWrapper) node.getUserObject())
									.getObjectName());
				}
				attributeTablemodel.fireTableDataChanged();
			} else {
				log.debug("Not a leaf");
			}
		} catch (JMXConnectionAdapterException exception) {
			attributeTablemodel.clearData();
			log.debug(exception.getMessage());
			exception.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.event.TreeSelectionListener#valueChanged(javax.swing.event.TreeSelectionEvent)
	 */
	public void valueChanged(TreeSelectionEvent e) {
		TreePath path[] = mbeanTree.getSelectionPaths();
		if (path.length <= 0)
			return;
		for (int i = 0; i < (path.length - 1); i++) {
			mbeanTree.removeSelectionPath(path[i]);
		}
		updateAttributes((DefaultMutableTreeNode) path[path.length - 1]
				.getLastPathComponent());
	}

	/**
	 * 
	 * @return all the selected attributes.
	 */
	public String[] getSelectedAttributes() {
		int rows[] = attributeTable.getSelectedRows();
		String attributes[] = new String[rows.length];
		for (int i = 0; i < rows.length; i++) {
			attributes[i] = attributeTablemodel.getRowData(rows[i])[0]
					.toString();
		}
		return attributes;
	}

	/**
	 * 
	 * @return all selected mbeans.
	 */
	public ObjectName getSelectedMBean() {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) mbeanTree
				.getSelectionPath().getLastPathComponent();
		if (node.isLeaf()) {
			return ((MBeanObjectNameWrapper) node.getUserObject())
					.getObjectName();
		} else {
			log.debug("None selected");
			return null;
		}
	}

	/**
	 * Show mbean tree with the below config.
	 * 
	 * @param host
	 * @param port
	 * @param username
	 * @param password
	 */
	public void show(String host, int port, String username, String password) {

		this.host = host;
		this.port = port;
		this.username = username;
		this.password = password;
		/*
		 * Launch the mbeanTree if a valid hostname and port is present.
		 */
		try {
			if (host.length() > 0 && port >= 0) {
				initdata();
				setVisible(true);
			} else {
				JOptionPane.showMessageDialog(null, "Invalid host name and port.",
						"Error", JOptionPane.ERROR_MESSAGE);
				log.error("Invalid host name and port");
			}
		} catch (Exception exception) {
			JOptionPane.showMessageDialog(null, "Can not create the connection.",
					"Error", JOptionPane.ERROR_MESSAGE);
			log.error("Failed to create a new connection. Details "
					+ exception.getMessage());
		}
	}

	/**
	 * This wrapper is particularly for to separate what we want to show a mbean
	 * in the gui.
	 * 
	 * @author smanya
	 * 
	 */
	class MBeanObjectNameWrapper {

		ObjectName name;

		public MBeanObjectNameWrapper(ObjectName name) {
			this.name = name;
		}

		public ObjectName getObjectName() {
			return this.name;
		}

		public String toString() {
			String nameProp = name.getKeyProperty("name");
			if (nameProp == null) {
				return name.getKeyProperty("type");
			} else {
				return nameProp;
			}
		}
	}
}
