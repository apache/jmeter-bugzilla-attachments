package org.apache.jmeter.protocol.jmx.control.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.gui.util.PowerTableModel;
import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.protocol.jmx.sampler.AbstractMBean;
import org.apache.jmeter.protocol.jmx.sampler.JMXSampler;
import org.apache.jmeter.samplers.gui.AbstractSamplerGui;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * JMX Gui element. Assosiated test element JMXSampler.
 * 
 * @author smanya.
 * 
 */
public class JMXTestSamplerGui extends AbstractSamplerGui {

	private static final long serialVersionUID = -1502043756516012284L;

	/*
	 * MBean table header attributes.
	 */
	private static final String MBEAN_TABLE_HEADERS[] = { "Local Name",
			"MBean Name", "Attribute Value" };

	private static final Logger log = LoggingManager.getLoggerForClass();

	private static final String mbean_table_title = "MBeans";

	private static final String ADD_MBEAN = "Add Mbean";

	private static final String DEL_MBEAN = "Delete Mbean";

	/*
	 * Vital gui components.
	 */
	private JTextField host;

	private JTextField port;

	private JTextField userName;

	private JTextField passWord;

	private PowerTableModel mbeanTableModel;

	private MBeanTree mbeanTree;

	private JTable mbeanTable;

	private CommandListner commandListner = new CommandListner();

	/**
	 * Constructor.
	 * 
	 */
	public JMXTestSamplerGui() {
		init();
	}

	/**
	 * Not used. So empty.
	 */
	public String getLabelResource() {
		return "";
	}

	/**
	 * As resource label is not used, this one returns the label string for the
	 * gui element.
	 */
	public String getStaticLabel() {
		return "JMX Request";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(org.apache.jmeter.testelement.TestElement)
	 */
	public void modifyTestElement(TestElement element) {
		super.configureTestElement(element);
		int portNo = 0;
		try {
			portNo = Integer.parseInt(port.getText());
		} catch (NumberFormatException exception) {
			portNo = 0;
		}
		JMXSampler sampler = (JMXSampler) element;
		sampler.setHost(host.getText());
		sampler.setPort(portNo);
		sampler.setUserName(userName.getText());
		sampler.setPassword(passWord.getText());
		loadMBeanConfig(sampler);
	}

	/**
	 * Load selected mbeans into the test element.
	 * 
	 * @param element
	 */
	protected void loadMBeanConfig(TestElement element) {
		JMXSampler sampler = (JMXSampler) element;
		String[] mbeanNames = getMBeanNames();
		String[] localMBeanNames = getLocalMBeanNames();
		String[][] attributes = getMBeanAttributes();
		sampler.clearMBeans();
		for (int i = 0; i < mbeanNames.length; i++) {
			log.debug("Adding mbean " + mbeanNames[i]);
			AbstractMBean abstraction = new AbstractMBean(mbeanNames[i],
					localMBeanNames[i]);
			for (int j = 0; j < attributes[i].length; j++) {
				log.debug("Adding attribute " + attributes[i][j]);
				abstraction.addAttribute(attributes[i][j]);
			}
			sampler.addMBean(abstraction);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#createTestElement()
	 */
	public TestElement createTestElement() {
		JMXSampler sampler = new JMXSampler();
		super.configureTestElement(sampler);
		return sampler;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#configure(org.apache.jmeter.testelement.TestElement)
	 */
	public void configure(TestElement element) {
		super.configure(element);
		JMXSampler sampler = (JMXSampler) element;
		host.setText(sampler.getHost());
		port.setText(new Integer(sampler.getPort()).toString());
		userName.setText(sampler.getUserName());
		passWord.setText(sampler.getPassWord());
		mbeanTableModel.clearData();
		String[] keys = sampler.getMBeanKeys();
		for (int i = 0; i < keys.length; i++) {
			mbeanTableModel.addRow(new String[] {
					sampler.getLocalMBeanNameForKey(keys[i]),
					sampler.getMBeanNameForKey(keys[i]),
					sampler.getAttributsAsStringForKey(keys[i]) });
		}
	}

	/**
	 * Init gui.
	 */
	protected void init() {

		setLayout(new BorderLayout(0, 5));
		setBorder(makeBorder());
		VerticalPanel panel = new VerticalPanel();
		add(makeTitlePanel(), BorderLayout.NORTH);
		panel.add(getTextFieldPanel());
		panel.add(getBrowsingPanel());
		add(panel, BorderLayout.CENTER);
	}

	/**
	 * Get the server conf panels.
	 * 
	 * @return Panel with all conf panels.
	 */
	protected JPanel getTextFieldPanel() {
		VerticalPanel panel = new VerticalPanel();
		host = createTextPanel("HostName  :", panel, 50);
		port = createTextPanel("HostPort  :", panel, 6);
		userName = createTextPanel("UserName  :", panel, 20);
		passWord = createTextPanel("Password  :", panel, 20);
		return panel;
	}

	/**
	 * creates a readable textfield component in gui with a label
	 * 
	 * @param labelText
	 *            label for the textfield.
	 * @param parentPanel
	 *            parent panel.
	 * @param size
	 *            size of the text field
	 * @return the so created text component.
	 */
	protected JTextField createTextPanel(String labelText, JPanel parentPanel,
			int size) {
		JTextField field = new JTextField(size);
		HorizontalPanel panel = new HorizontalPanel();
		JLabel label = new JLabel(labelText);
		panel.add(label);
		panel.add(field);
		parentPanel.add(panel);
		return field;
	}

	/*
	 * Browsing panel has the table. And the AddMbean & Delete Mbean buttons.
	 * 
	 * @return
	 */
	private JPanel getBrowsingPanel() {

		mbeanTableModel = new PowerTableModel(MBEAN_TABLE_HEADERS, new Class[] {
				String.class, String.class, String.class });
		mbeanTable = new JTable(mbeanTableModel);
		mbeanTable.setPreferredScrollableViewportSize(new Dimension(100, 50));
		JPanel panel = new JPanel(new BorderLayout());
		panel.setBorder(BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), mbean_table_title));
		panel.add(new JScrollPane(mbeanTable), BorderLayout.CENTER);
		panel.add(createTableButtonPanel(new String[] { ADD_MBEAN, DEL_MBEAN },
				commandListner), BorderLayout.SOUTH);
		return panel;
	}

	/**
	 * Create a ButtonPanel for the commands.
	 * 
	 * @param commands
	 *            commands for which we need buttons.
	 * @param listner
	 *            listner for button events.
	 * @return the jpanel with the command buttons.
	 */
	protected JPanel createTableButtonPanel(String[] commands,
			CommandListner listner) {
		JPanel buttonPanel = new JPanel(new GridBagLayout());
		for (int i = 0; i < commands.length; i++) {
			JButton button = new JButton(commands[i]);
			button.setActionCommand(commands[i]);
			button.addActionListener(listner);
			buttonPanel.add(button);
		}
		return buttonPanel;
	}

	/**
	 * 
	 * @return all the mbean names in the table.
	 */
	public String[] getMBeanNames() {
		List mbeanNamesList = mbeanTableModel
				.getColumnData(MBEAN_TABLE_HEADERS[1]);
		Iterator listIter = mbeanNamesList.iterator();
		String[] objectNames = new String[mbeanNamesList.size()];
		for (int i = 0; i < objectNames.length; i++) {
			objectNames[i] = (listIter.next().toString());
			log.debug("Reading mbean " + objectNames[i]);
		}
		return objectNames;
	}

	/**
	 * 
	 * @return all local mbean names
	 */
	public String[] getLocalMBeanNames() {
		List mbeanNamesList = mbeanTableModel
				.getColumnData(MBEAN_TABLE_HEADERS[0]);
		Iterator listIter = mbeanNamesList.iterator();
		String[] localNames = new String[mbeanNamesList.size()];
		for (int i = 0; i < localNames.length; i++) {
			localNames[i] = listIter.next().toString();
			log.debug("Reading mbean local name" + localNames[i]);
		}
		return localNames;
	}

	/**
	 * 
	 * @return All attributes selected.
	 */
	public String[][] getMBeanAttributes() {
		List attributeList = mbeanTableModel
				.getColumnData(MBEAN_TABLE_HEADERS[2]);
		Iterator listIter = attributeList.iterator();
		String[][] attribs = new String[attributeList.size()][];
		for (int i = 0; i < attribs.length; i++) {
			attribs[i] = listIter.next().toString().split(";");
			if (log.isDebugEnabled()) {
				for (int j = 0; j < attribs[i].length; j++) {
					log.debug("Reading mbean attribute " + attribs[i][j]);
				}
			}
		}
		return attribs;
	}

	/**
	 * Destroy the dialog at the end.
	 */
	protected void finalize() throws Throwable {
		super.finalize();
		mbeanTree.dispose();
	}

	/**
	 * To handle th gui commands.
	 * 
	 * @author smanya.
	 * 
	 */
	class CommandListner implements ActionListener {

		private int validatePort(String port) {
			try {
				int value = Integer.parseInt(port);
				return value;
			} catch (Exception exception) {
				return -1;
			}
		}

		public void actionPerformed(ActionEvent event) {

			if (event.getActionCommand().equalsIgnoreCase(ADD_MBEAN)) {
				int portNo = validatePort(port.getText());
				if (portNo < 0) {
					JOptionPane.showMessageDialog(null, "Error",
							"Invalid port number.", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if (mbeanTree == null) {
					mbeanTree = new MBeanTree(this);
					mbeanTree
							.setLocation((Toolkit.getDefaultToolkit()
									.getScreenSize().width - mbeanTree
									.getWidth()) / 2,
									(Toolkit.getDefaultToolkit()
											.getScreenSize().height - mbeanTree
											.getHeight()) / 2);
				}
				if (log.isDebugEnabled()) {
					log.debug("loading mbean tree with params "
							+ host.getText() + " " + portNo + " "
							+ userName.getText() + " " + passWord.getText());
				}
				mbeanTree.show(host.getText(), portNo, userName.getText(),
						passWord.getText());
			} else if (event.getActionCommand().equalsIgnoreCase(DEL_MBEAN)) {
				mbeanTableModel.removeRow(mbeanTable.getSelectedRow());
				mbeanTableModel.fireTableDataChanged();
			} else if (event.getActionCommand().equalsIgnoreCase(
					MBeanTree.ADD_ATTRIBUTES)) {
				log.debug("Adding the attributes to the table.");
				String row[] = new String[3];
				row[0] = "";
				row[1] = mbeanTree.getSelectedMBean().toString();
				String attributes[] = mbeanTree.getSelectedAttributes();
				if (attributes.length > 0)
					row[2] = attributes[0];
				else
					row[2] = "";
				for (int i = 1; i < attributes.length; i++) {
					row[2] = row[2] + ";" + attributes[i];
				}
				mbeanTableModel.addRow(row);
				mbeanTableModel.fireTableDataChanged();
			}
		}
	}
}