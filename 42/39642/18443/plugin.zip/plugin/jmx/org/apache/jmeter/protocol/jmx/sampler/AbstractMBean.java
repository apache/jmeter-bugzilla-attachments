package org.apache.jmeter.protocol.jmx.sampler;

import java.util.HashSet;
import java.util.Set;

import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.property.ObjectProperty;

/**
 * Wrapper around mbeans.
 * 
 * @author smanya
 * 
 */
public class AbstractMBean extends AbstractTestElement {

	private static final long serialVersionUID = -558767766251825398L;

	private static final String LOCALNAME = "AbstractMBean.localName";

	private static final String MBEANNAME = "AbstractMBean.mbeanName";

	private static final String ATTRIBUTES = "AbstractMBean.attributes";

	/**
	 * Default constructor.
	 * 
	 */
	public AbstractMBean() {
		this("");
	}

	/**
	 * Constructor
	 * 
	 * @param mBeanName
	 */
	public AbstractMBean(String mBeanName) {
		this(mBeanName, "");
	}

	/**
	 * Constructor.
	 * 
	 * @param mBeanName
	 * @param localName
	 */
	public AbstractMBean(String mBeanName, String localName) {
		setLocalName(localName);
		setMBeanName(mBeanName);
	}

	/**
	 * 
	 * @param attribute
	 *            add the attribute to list of attributes in the abstraction.
	 */
	public void addAttribute(String attribute) {
		Set attributes = (Set) (getProperty(ATTRIBUTES).getObjectValue());
		if (attributes == null) {
			attributes = new HashSet();
		}
		attributes.add(attribute);
		setProperty(new ObjectProperty(ATTRIBUTES, attributes));
	}

	/*
	 * Getters and Setters.
	 */

	public Set getAttributes() {
		return (Set) (getProperty(ATTRIBUTES).getObjectValue());
	}

	public String getLocalName() {
		return getPropertyAsString(LOCALNAME);
	}

	public String getMBeanName() {
		return getPropertyAsString(MBEANNAME);
	}

	public void setLocalName(String name) {
		setProperty(LOCALNAME, name);
	}

	public void setMBeanName(String name) {
		setProperty(MBEANNAME, name);
	}

}
