package org.apache.jmeter.protocol.jmx.utils;

/**
 * Encapsulate JMX errors.
 * 
 * @author smanya
 * 
 */
public class JMXConnectionAdapterException extends Exception {

	private static final long serialVersionUID = -385915281350042316L;

	public JMXConnectionAdapterException() {
		super("JMX Connection failure for unknown reasons.");
	}

	public JMXConnectionAdapterException(String message) {
		super("JMX Connection failed. " + message);
	}
}
