package org.apache.jmeter.protocol.jmx.sampler;

import org.apache.jmeter.testelement.AbstractTestElementBeanInfo;

/**
 * @author smanya
 * 
 */
public class JMXSamplerBeanInfo extends AbstractTestElementBeanInfo {

}