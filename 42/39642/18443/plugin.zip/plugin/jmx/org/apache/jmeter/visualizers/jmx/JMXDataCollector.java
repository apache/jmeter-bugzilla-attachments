package org.apache.jmeter.visualizers.jmx;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.engine.util.NoThreadClone;
import org.apache.jmeter.reporters.AbstractListenerElement;
import org.apache.jmeter.samplers.Clearable;
import org.apache.jmeter.samplers.Remoteable;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleListener;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.TestListener;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jmeter.visualizers.Visualizer;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Listens to JMX Samples. And Communicates the data to JMXDatawriter. Unlike
 * other collectors this will not hold the file writing capabilities. Author did
 * this to avoid potential synchronization problems. However the filename
 * property is still in the collector.
 * 
 * @author smanya
 * 
 */
public class JMXDataCollector extends AbstractListenerElement implements
		SampleListener, Clearable, Serializable, TestListener, Remoteable,
		NoThreadClone {

	private static final long serialVersionUID = -615892843806602051L;

	private static final Logger log = LoggingManager.getLoggerForClass();

	public final static String FILENAME = "filename";

	/*
	 * For distributed testing.
	 */
	private Set hosts;

	public JMXDataCollector() {
		hosts = new HashSet();
		setProperty(new StringProperty(TestElement.NAME, "JMX Data Collector"));
	}

	// TODO: This is not good design need to replace this logic asap.
	public Visualizer getVisualizer() {
		Visualizer visualizer = super.getVisualizer();
		if (visualizer == null) {
			log.warn("Creating a jmx data writer in slave mode.");
			setListener(new JMXDataWriter(true));
			((JMXDataWriter) getVisualizer()).setFileName(getFilename());
		}
		return super.getVisualizer();
	}

	/**
	 * New Sample Occured. Communicate this to Visualizer.
	 */
	public void sampleOccurred(SampleEvent event) {
		SampleResult result = event.getResult();
		getVisualizer().add(result);
	}

	/*
	 * Set the collector out file name as property.
	 * 
	 * @param f
	 */
	private void setFilenameProperty(String f) {
		setProperty(FILENAME, f);
	}

	/**
	 * Get the file name.
	 * 
	 * @return
	 */
	public String getFilename() {
		return getPropertyAsString(FILENAME);
	}

	/**
	 * Set the file name.
	 * 
	 * @param fileName
	 */
	public void setFilename(String fileName) {
		setFilenameProperty(fileName);
	}

	public void sampleStarted(SampleEvent event) {
	}

	public void sampleStopped(SampleEvent event) {
	}

	public void testStarted() {
		try {
			((JMXDataWriter) getVisualizer()).initializeFileOutput();
		} catch (Exception e) {
			log.error("Could not initialize the the file stream. Details "
					+ e.getMessage());
		}
	}

	/**
	 * Test ended.
	 */
	public void testEnded() {
		try {
			if (hosts.size() == 0) {
				((JMXDataWriter) getVisualizer()).finalizeFileOutput();
			}
		} catch (Exception e) {
			log.error("Could not finalize the the file stream. Details "
					+ e.getMessage());
		}
	}

	/**
	 * test started.
	 * 
	 * @param host
	 *            not used.
	 */
	public synchronized void testStarted(String host) {
		hosts.add(host);
		testStarted();
	}

	/**
	 * test ended.
	 * 
	 * @param host
	 *            not used.
	 */
	public synchronized void testEnded(String host) {
		hosts.remove(host);
		testEnded();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.jmeter.testelement.TestListener#testIterationStart(org.apache.jmeter.engine.event.LoopIterationEvent)
	 */
	public void testIterationStart(LoopIterationEvent arg0) {
	}

	/**
	 * Clear the visualizer.
	 */
	public void clear() {
		if (getVisualizer() != null) {
			((JMXDataWriter) getVisualizer()).finalizeFileOutput();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#clone()
	 */
	public Object clone() {
		AbstractListenerElement collector = (AbstractListenerElement) super
				.clone();
		collector.setListener(this.getVisualizer());
		((JMXDataCollector) collector).setFilename(this.getFilename());
		return collector;
	}

	/**
	 * Get the label string.
	 */
	public String getLabel() {
		return ("JMX Data Collector");
	}

}
