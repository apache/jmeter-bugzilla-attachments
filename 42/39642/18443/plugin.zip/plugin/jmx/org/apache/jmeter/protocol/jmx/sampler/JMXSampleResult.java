package org.apache.jmeter.protocol.jmx.sampler;

import org.apache.jmeter.samplers.SampleResult;

/**
 * The JMXSample result. Currently just a good child of SampleResult.
 * 
 * @author smanya.
 * 
 */
public class JMXSampleResult extends SampleResult {

	private static final long serialVersionUID = -8800989259909063916L;

	public JMXSampleResult() {
		super();
	}

	public JMXSampleResult(JMXSampleResult result) {
		super(result);
	}
}
