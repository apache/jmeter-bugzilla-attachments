/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright 2005 by DSA - all rights reserved                     *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *      Author      ok
 *      Created on  08.11.2005
 *
 ************************************************************************/
package jmetertest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.util.Date;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.remoting.httpinvoker.CommonsHttpInvokerRequestExecutor;
import org.springframework.remoting.httpinvoker.HttpInvokerClientConfiguration;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

/**
 * This subclass passes the current HTTP session id ("JSESSIONID") with the
 * request if available.
 */
public class JMeterTestHttpRequestExecutor extends
		CommonsHttpInvokerRequestExecutor {

	/**
	 * Flag to indicate if a proxy server should be used
	 */

	public static boolean MIT_PROXY = true;

	/**
	 * Proxy Host Name
	 */
	private static String proxyHost = "pchl.dsa-ac.de";

	/**
	 * Proxya Port
	 */
	private static int proxyPort = 9090;

	// --- other settings ---

	/** Local logger instance for logging network performance values. */
	private static final Log NETWORK_LOGGER = LogFactory
			.getLog("NetworkLogger");

	/** HTTP header for content enconding. */
	private static final String HTTP_HEADER_CONTENT_ENCODING = "Content-Encoding";

	/**
	 * HTTP header is boolean flag denoting compression support of this client.
	 * Value is: true/false.
	 */
	private static final String HTTP_HEADER_COMPRESSION_SUPPORTED = "Compression-Supported";

	/** HTTP encoding for zipped payload. */
	private static final String HTTP_CONTENT_ENCODING_ZIPPED = "gzip";

	/** Constant value for 'percent'. */
	private static final int PER_CENT = 100;

	/**
	 * Buffer size in bytes.
	 */
	private static final int BUFFER_SIZE = 4096;

	/** Local logger instance. */
	private transient Log log;

	/** Indicating whether response compression is enabled. */
	private boolean compressionEnabled;

	/** No-arg constructor. Calls parent. */
	public JMeterTestHttpRequestExecutor() {
		super();
	}

	/**
	 * No-arg constructor. Calls parent.
	 *
	 * @param httpClient
	 *            the http client responsible for the http request/response
	 *            handling.
	 */
	public JMeterTestHttpRequestExecutor(HttpClient httpClient) {
		super(httpClient);
	}

	/**
	 * Enables compression of request payload.
	 *
	 * @param enabled
	 *            true if paylad is to be compressed.
	 */
	public void setCompressionEnabled(boolean enabled) {
		getLog().debug("Payload compression feature enabled: " + enabled);
		this.compressionEnabled = enabled;
	}

	/**
	 * Logs the HTTP response headers of the specified method.
	 *
	 * @param httpMethod
	 *            The HTTP method to be investigated for response headers.
	 */
	private void logRequestHeaders(HttpMethod httpMethod) {

		if (!getLog().isDebugEnabled()) {
			return;
		}
		String strHeaders = getHeadersAsString(httpMethod.getRequestHeaders());
		getLog().debug("HTTP REQUEST HEADERS: " + strHeaders);
	}

	/**
	 * Logs the HTTP response headers of the specified method.
	 *
	 * @param httpMethod
	 *            The HTTP method to be investigated for response headers.
	 */
	private void logResponseHeaders(HttpMethod httpMethod) {

		if (!getLog().isDebugEnabled()) {
			return;
		}
		String strHeaders = getHeadersAsString(httpMethod.getResponseHeaders());
		getLog().debug("HTTP RESPONSE HEADERS: " + strHeaders);
	}

	/**
	 * Returns all headers as one string.
	 *
	 * @param headers
	 *            An array of Header objects.
	 * @return All headers as one string.
	 */
	private String getHeadersAsString(Header[] headers) {

		String strHeaders = "";
		for (int i = 0; i < headers.length; i++) {
			Header header = headers[i];
			String headerName = header.getName();
			String headerValue = header.getValue();
			strHeaders += "\n        " + headerName + ": " + headerValue;
		}
		return strHeaders;
	}

	/**
	 * Sets credentials into the HTTP header.
	 *
	 * @param httpClient
	 *            The HTTP client used to set credentials.
	 */
	protected void setCredentials(HttpClient httpClient) {
		// empty template method:
		// is to be overwritten in sub class HttpLoginRequestExecutor.
	}

	protected RemoteInvocationResult doExecuteRequest(
			HttpInvokerClientConfiguration config, ByteArrayOutputStream baos)
			throws IOException, ClassNotFoundException {

		HttpClient client = getHttpClient();
		client.getState().setCookiePolicy(CookiePolicy.COMPATIBILITY);
		if (MIT_PROXY){
			client.getHostConfiguration().setProxy(proxyHost, proxyPort);
		}

		if (MIT_PROXY) {
			getLog().debug("");
			getLog().debug("INFO: Yes, a PROXY used on server side: Host="+proxyHost+", Port="+proxyPort);
			getLog().debug("");
		} else {
			getLog().debug("");
			getLog().debug("INFO: NO proxy used on server side.");
			getLog().debug("");
		}

		setCredentials(client);

		if (getLog().isDebugEnabled()) {
			getLog().debug("Before request:");
		}

		PostMethod postMethod = createPostMethod(config);

		if (MIT_PROXY) {
			postMethod.getHostConfiguration().setProxy(proxyHost, proxyPort);
		}

		// Next statement is responsible for serialization and compression;
		setRequestBody(config, postMethod, baos);
		try {

			Date beforeExecution = new Date();

			// Executes remote invocation using commons http client.
			// Note: executePostMethod will anyway use this.httpClient, instead
			// of client argument
			super.executePostMethod(config, client, postMethod);

			Date afterExecution = new Date();

			logRequestHeaders(postMethod);

			int statusCode = postMethod.getStatusCode();
			if (getLog().isDebugEnabled()) {
				getLog().debug("After request: Status Code =" + statusCode);
			}

			logResponseHeaders(postMethod);

			validateResponse(config, postMethod);

			RemoteInvocationResult result = postProcessResponse(config,
					postMethod, beforeExecution, afterExecution);

			return result;

		} finally {
			// need to explicitly release because it might be pooled
			postMethod.releaseConnection();
		}

	}

	/**
	 * Returns the remote invocation result extracted from the response.
	 *
	 * @param config
	 *            The HttpInvokerClientConfiguration.
	 * @param postMethod
	 *            The HTTP POST method object.
	 * @param beforeExecution
	 *            the date before execution of the remote method.
	 * @param afterExecution
	 *            the date after execution of the remote method.
	 * @return The result of the remote invocation.
	 * @throws IOException
	 *             if a IO operation fails.
	 * @throws ClassNotFoundException
	 *             if a class for object deserialization cannot be found.
	 */
	private RemoteInvocationResult postProcessResponse(
			HttpInvokerClientConfiguration config, PostMethod postMethod,
			Date beforeExecution, Date afterExecution) throws IOException,
			ClassNotFoundException {

		if (NETWORK_LOGGER.isDebugEnabled()) {
			NETWORK_LOGGER.debug("Execution of http request: "
					+ (afterExecution.getTime() - beforeExecution.getTime())
					+ " ms. (total network transfer + server execution)");
		}

		JMeterTestByteCountingInputStream grossResponseStream;
		JMeterTestByteCountingInputStream netResponseStream;
		Date beforeDecompression;
		Date afterDecompression;

		byte[] responsePayload;
		if (isResponsePayloadZipCompressed(postMethod)) {
			grossResponseStream = new JMeterTestByteCountingInputStream(
					postMethod.getResponseBodyAsStream());
			beforeDecompression = new Date();
			responsePayload = GZipUtil.deflate(grossResponseStream);
			afterDecompression = new Date();
			netResponseStream = new JMeterTestByteCountingInputStream(
					new ByteArrayInputStream(responsePayload));

			if (NETWORK_LOGGER.isDebugEnabled()) {
				NETWORK_LOGGER.debug("Response is zip-compressed.");
				NETWORK_LOGGER.debug("Decompression and reading of response: "
						+ (afterDecompression.getTime() - beforeDecompression
								.getTime()) + " ms. (decompression only)");
			}

		} else {
			grossResponseStream = new JMeterTestByteCountingInputStream(
					postMethod.getResponseBodyAsStream());
			beforeDecompression = new Date();
			byte[] responseData = deflate(grossResponseStream);
			afterDecompression = new Date();
			netResponseStream = new JMeterTestByteCountingInputStream(
					new ByteArrayInputStream(responseData));

			if (NETWORK_LOGGER.isDebugEnabled()) {
				NETWORK_LOGGER.debug("Response is not compressed.");
				NETWORK_LOGGER.debug("Decompression and reading of response: "
						+ (afterDecompression.getTime() - beforeDecompression
								.getTime()) + " ms. (decompression only)");
			}
		}

		Date beforeDeserialization = new Date();
		RemoteInvocationResult result = readRemoteInvocationResult(
				netResponseStream, config.getCodebaseUrl());
		Date afterDeserialization = new Date();

		long netPayload = netResponseStream.bytesRead();
		long grossPayload = grossResponseStream.bytesRead();
		float tmpFloat = (float) (netPayload - grossPayload) / netPayload
				* PER_CENT;
		int responseCompressionRate = new Float(tmpFloat).intValue();

		if (NETWORK_LOGGER.isDebugEnabled()) {
			NETWORK_LOGGER.debug("Response payload (gross)  : " + netPayload
					+ " bytes.");
			NETWORK_LOGGER.debug("Response payload (net): "
					+ grossResponseStream.bytesRead() + " bytes.");
			NETWORK_LOGGER.debug("Compression rate: " + responseCompressionRate
					+ "%.");
			NETWORK_LOGGER.debug("Deserialization of response: "
					+ (afterDeserialization.getTime() - beforeDeserialization
							.getTime()) + " ms. (object instantiation)");
		}

		return result;
	}

	/**
	 * Reads raw data from input stream into a large byte array.
	 *
	 * @param in
	 *            the input stream to read data from
	 * @return a byte array with contents read from the input stream.
	 * @exception IOException
	 *                in case an I/O error occurs.
	 */
	public static byte[] deflate(InputStream in) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] temp = new byte[BUFFER_SIZE];
		int len = 0;
		while ((len = in.read(temp, 0, temp.length)) != -1) {
			out.write(temp, 0, len);
		}
		out.flush();
		return out.toByteArray();
	}

	/**
	 * Set the given serialized remote invocation as request body.
	 * <p>
	 * The default implementation simply sets the serialized invocation as the
	 * PostMethod's request body. This can be overridden, for example, to write
	 * a specific encoding and potentially set appropriate HTTP request headers.
	 *
	 * @param config
	 *            the HTTP invoker configuration that specifies the target
	 *            service
	 * @param postMethod
	 *            the PostMethod to set the request body on
	 * @param baos
	 *            the ByteArrayOutputStream that contains the serialized
	 *            RemoteInvocation object
	 * @throws IOException
	 *             if thrown by I/O methods
	 * @see org.apache.commons.httpclient.methods.PostMethod#setRequestBody(java.io.InputStream)
	 * @see org.apache.commons.httpclient.methods.PostMethod#setRequestEntity
	 * @see org.apache.commons.httpclient.methods.InputStreamRequestEntity
	 */
	protected void setRequestBody(HttpInvokerClientConfiguration config,
			PostMethod postMethod, ByteArrayOutputStream baos)
			throws IOException {

		if (NETWORK_LOGGER.isDebugEnabled()) {
			NETWORK_LOGGER
					.debug("Serializing request payload to calculate payload size.");
		}

		if (compressionEnabled) {
			getLog().debug("Client supports compression.");
			postMethod.setRequestHeader(HTTP_HEADER_COMPRESSION_SUPPORTED,
					new Boolean(compressionEnabled).toString());
		}

		Date beforeSerialization = new Date();
		byte[] content = baos.toByteArray();
		Date afterSerialization = new Date();

		if (NETWORK_LOGGER.isDebugEnabled()) {
			NETWORK_LOGGER.debug("Serialization of request: "
					+ (afterSerialization.getTime() - beforeSerialization
							.getTime()) + " ms.");
		}

		if (compressionEnabled) {
			getLog().debug("compression enabled --> Zipping http content...");

			Date beforeCompression = new Date();
			byte[] compressed = GZipUtil.compress(content);
			Date afterCompression = new Date();

			float tmpFloat = (float) (content.length - compressed.length)
					/ content.length * PER_CENT;
			int compressionRate = new Float(tmpFloat).intValue();

			if (NETWORK_LOGGER.isDebugEnabled()) {
				NETWORK_LOGGER
						.debug("Request payload will be compressed IN MEMORY.");
				NETWORK_LOGGER.debug("Size of uncompressed payload: "
						+ content.length + " bytes.");
				NETWORK_LOGGER.debug("Size of compressed payload: "
						+ compressed.length + " bytes.");
				NETWORK_LOGGER.debug("Compression rate: " + compressionRate
						+ "%.");
				NETWORK_LOGGER.debug("Compression of request payload: "
						+ (afterCompression.getTime() - beforeCompression
								.getTime()) + " ms.");
			}

			if (getLog().isDebugEnabled()) {
				getLog().debug("compressed payload size: " + compressed.length);
				getLog().debug(
						"compression rate: "
								+ ((float) (content.length - compressed.length)
										/ content.length * PER_CENT) + "%");

			}
			postMethod.setRequestHeader(HTTP_HEADER_CONTENT_ENCODING,
					HTTP_CONTENT_ENCODING_ZIPPED);
			postMethod.setRequestHeader(HTTP_HEADER_CONTENT_LENGTH,
					new Integer(compressed.length).toString());
			postMethod.setRequestBody(new ByteArrayInputStream(compressed));

		} else {
			getLog().debug(
					"compression not enabled --> Not zipping http content.");
			if (NETWORK_LOGGER.isDebugEnabled()) {
				NETWORK_LOGGER.debug("Request payload will not be compressed.");
				NETWORK_LOGGER.debug("Size of uncompressed payload: "
						+ content.length + " bytes.");
			}
			postMethod.setRequestBody(new ByteArrayInputStream(content));

		}
	}

	/**
	 * {@inheritDoc}
	 */
	protected PostMethod createPostMethod(HttpInvokerClientConfiguration config)
			throws IOException {
		PostMethod postMethod = new PostMethod(config.getServiceUrl()) {
			protected boolean isConnectionCloseForced() {
				// We want to avoid connection reset exception on idle
				// connections (Win J2SDK1.4.2_06 vs. WLS 8.1 SP3)
				// Default WLS config closes idle http connections after 30 secs
				// HttpClient default is to retry 3 times until request sent
				// successfully, hence will reestablish connection as necessary
				return false;
			}
		};
		postMethod.setRequestHeader(HTTP_HEADER_CONTENT_TYPE,
				CONTENT_TYPE_SERIALIZED_OBJECT);
		return postMethod;
	}

	/**
	 * Perform the actual writing of the given invocation object to the given
	 * ObjectOutputStream.
	 *
	 * @param invocation
	 *            the RemoteInvocation object
	 * @param oos
	 *            the ObjectOutputStream to write to
	 * @throws IOException
	 *             if thrown by I/O methods
	 * @see org.springframework.remoting.httpinvoker.AbstractHttpInvokerRequestExecutor#doWriteRemoteInvocation(org.springframework.remoting.support.RemoteInvocation,
	 *      java.io.ObjectOutputStream)s
	 */
	protected void doWriteRemoteInvocation(RemoteInvocation invocation,
			ObjectOutputStream oos) throws IOException {

		super.doWriteRemoteInvocation(invocation, oos);
	}

	/**
	 * Checks if a response is zip-compressed The payload is assumed to be
	 * zip-compressed in case the header contains the content-encoding with
	 * value 'gzip'.
	 *
	 * @param method
	 *            the post request object
	 * @return true if content-encoding is 'gzip'
	 */
	private boolean isResponsePayloadZipCompressed(PostMethod method) {
		Header encoding = method
				.getResponseHeader(HTTP_HEADER_CONTENT_ENCODING);
		if (encoding != null
				&& encoding.getValue() != null
				&& encoding.getValue().equalsIgnoreCase(
						HTTP_CONTENT_ENCODING_ZIPPED)) {
			getLog().debug("Response content is zip-compressed. ");
			return true;
		} else {
			getLog().debug("Response content is not zip-compressed. ");
			return false;
		}
	}

	/**
	 * Returns the assigned logger instance.
	 *
	 * @return the assigned logger or a new log instance retrieved from the
	 *         LogFactory, in case not logger was assigned by the
	 *         setLog()-method
	 */
	protected Log getLog() {
		// no need to synchronize here
		if (this.log == null) {
			this.log = LogFactory.getLog(getClass());
		}
		return log;
	}

}