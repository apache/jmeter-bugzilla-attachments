/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      hl
 *    Created on  15.04.2008
 *
 ************************************************************************/
package jmetertest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimpleClient {

    /** Local logger instance. */
    private static final Log log = LogFactory.getLog(SimpleClient.class);

	public static void main(String[] args) {

		// Note: you can set log4j properties in the file "log4j.properties"
		// The logging output is sent to console and to file "log/jmetertest_clientside.log"

		log.debug("MAIN...BEGIN");

		String configFileLocation="jmetertest/clientConfig.xml";
		ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(configFileLocation);
		BeanFactory factory = (BeanFactory) appContext;

		Object obj = factory.getBean("httpInvokerProxy", JMeterTestService.class);
		JMeterTestService service = (JMeterTestService) obj;

		String result= service.helloWorld();

		log.debug("");
		log.debug("result='"+result+"'");
		log.debug("");
		log.debug("MAIN...END");

	}

}
