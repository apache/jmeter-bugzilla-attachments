/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      gbe
 *    Created on  13.03.2007
 *
 ************************************************************************/
package jmetertest;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

/**
 * This InputStream counts the number of bytes read from the stream.
 * @see java.io.FilterInputStream
 * @see java.io.InputStream
 */
public class JMeterTestByteCountingInputStream extends FilterInputStream implements Serializable {

    
	static final long serialVersionUID = -2338170938307933652L;
    /** Total number of bytes read from the input stream. */
    private long counter;

    /**
     * Creates a <code>JMeterTestByteCountingInputStream</code>.
     *
     * @param in the underlying input stream, not null.
     */
    public JMeterTestByteCountingInputStream(InputStream in) {
        super(in);
    }

    /**
     *  {@inheritDoc}
     */
    public int read() throws IOException {
        int aByte = super.in.read();
        counter++;
        return aByte;
    }

    /** {@inheritDoc} */
    public int read(byte[] aB, int aOff, int aLen) throws IOException {
        int bytesRead = super.in.read(aB, aOff, aLen);
        counter += bytesRead;
        return bytesRead;
    }

    /** {@inheritDoc} */
    public int read(byte[] aB) throws IOException {
        int bytesRead = super.in.read(aB);
        counter += bytesRead;
        return bytesRead;
    }

    /**
     * Returns the number of bytes read from the stream.
     * @return total number of bytes read.
     */
    public long bytesRead() {
        return counter;
    }

    /** Resets the counter to 0. */
    public void resetCounter() {
        this.counter = 0;
    }
}
