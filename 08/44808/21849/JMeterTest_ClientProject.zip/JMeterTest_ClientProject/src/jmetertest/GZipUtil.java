/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      gbe
 *    Created on  23.04.2007
 *
 ************************************************************************/
package jmetertest;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Utility class that compresses and deflates byte arrays in memory using the GZIP algortihm.
 */
public final class GZipUtil  {

    /** buffer size in bytes. */
    private static final int BUFFER_SIZE = 4096;

    /** No-arg constructor. Does nothing. */
    private GZipUtil() {
    }

    /**
     * Compresses a byte array using gzip compression.
     * @param content the content to be compressed
     * @return the compressed contenz
     * @throws IOException if an I/O error has occured.
     */
    public static byte[] compress(byte[] content) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        GZIPOutputStream zos = new GZIPOutputStream(baos);
        zos.write(content, 0, content.length);
        zos.finish();
        zos.close();
        byte[] compressedBytes = baos.toByteArray();
        return compressedBytes;
    }

    /**
     * Defaltes a gzip-compressed byte array.
     * @param compressed the compressed data
     * @return the uncompressed data
     * @throws IOException if an I/O error has occured.
     */
    public static byte[] deflate(byte[] compressed) throws IOException {
        return deflate(new ByteArrayInputStream(compressed));
    }

    /**
     * Defaltes a gzip-compressed byte array.
     * @param in Inputstream to load the compressed data from
     * @return the uncompressed data
     * @throws IOException if an I/O error has occured.
     */
    public static byte[] deflate(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPInputStream zipIn = new GZIPInputStream(in);
        byte[] temp = new byte[BUFFER_SIZE];
        int len = 0;
        while ((len = zipIn.read(temp, 0, temp.length)) != -1) {
            out.write(temp, 0, len);
        }
        out.flush();
        return out.toByteArray();
    }
}
