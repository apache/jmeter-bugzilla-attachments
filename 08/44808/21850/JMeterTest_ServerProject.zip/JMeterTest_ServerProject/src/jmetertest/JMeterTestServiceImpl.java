/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      hl
 *    Created on  15.04.2008
 *
 ************************************************************************/
package jmetertest;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class JMeterTestServiceImpl implements JMeterTestService {

    /** Local logger instance. */
    private static final Log log = LogFactory.getLog(JMeterTestServiceImpl.class);

	public String helloWorld(){
		String msg="Hello world. Date="+new Date();

		log.debug("logging in Class JMeterTestServiceImpl.helloWorld: msg="+msg);

		return msg;
	}

}
