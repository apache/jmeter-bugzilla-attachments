/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      hl
 *    Created on  16.04.2008
 *
 ************************************************************************/
package jmetertest;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter;
import org.springframework.web.servlet.ModelAndView;


/**
 * Common Base Class for all HttpInvokerServiceExporter classes:
 * JMeterTestHttpServiceExporter, LoginHttpInvokerServiceExporter and LogoutHttpInvokerServiceExporter.
 * The common functionality is using a JMeterTestRemoteInvocationTraceInterceptor
 * which is capable to suppress specific Exceptions.
 *
 * @see JMeterTestRemoteInvocationTraceInterceptor
 */
public class JMeterTestAbstractHttpInvokerServiceExporter extends HttpInvokerServiceExporter  {

    /** Local logger instance. */
    private static final Log LOG = LogFactory.getLog(JMeterTestAbstractHttpInvokerServiceExporter.class);

    /**
     * no-args c'tor.
     */
    public JMeterTestAbstractHttpInvokerServiceExporter() {
    }


    /**
     * Get a proxy for the given service object, implementing the specified
     * service interface.
     * <p>Used to export a proxy that does not expose any internals but just
     * a specific interface intended for remote access. Furthermore, a
     * JMeterTestRemoteInvocationTraceInterceptor gets registered (by default).
     * This method overrides RemoteExporter.getProxyForService in order to
     * allow us to use our own {@link de.dsa.authoring.service.server.rmihttp.JMeterTestRemoteInvocationTraceInterceptor}
     * @return the proxy
     * @see #setServiceInterface
     * @see #setRegisterTraceInterceptor
     * @see de.dsa.authoring.service.server.rmihttp.JMeterTestRemoteInvocationTraceInterceptor
     */
    protected Object getProxyForService() {
        checkService();
        checkServiceInterface();
        ProxyFactory proxyFactory = new ProxyFactory();
        proxyFactory.addInterface(getServiceInterface());
        proxyFactory.setTarget(getService());
        return proxyFactory.getProxy();
    }


    /** {@inheritDoc} */
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ClassNotFoundException {

        logHttpRequestHeaders(request);
        return super.handleRequest(request, response);
    }

    /**
     * Logs the HTTP headers of the specified request.
     *
     * @param request The HttpServletRequest to be investigated for headers.
     */
    private void logHttpRequestHeaders(HttpServletRequest request) {

        Enumeration names = request.getHeaderNames();
        String strHeaders = "";
        while ( names.hasMoreElements() ) {
            String headerName = (String)names.nextElement();
            String headerValue = request.getHeader(headerName);
            strHeaders += "\n        " + headerName + ": " + headerValue;
        }

        String msg="HTTP REQUEST HEADERS: " + strHeaders;

        LOG.debug(msg);

    }
}
