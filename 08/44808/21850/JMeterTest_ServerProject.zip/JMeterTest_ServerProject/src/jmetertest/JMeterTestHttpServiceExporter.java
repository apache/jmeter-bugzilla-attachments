/************************************************************************
 *                                                                      *
 *  DDDD     SSSS    AAA        Daten- und Systemtechnik Aachen GmbH    *
 *  D   D   SS      A   A       Pascalstrasse 28                        *
 *  D   D    SSS    AAAAA       52076 Aachen-Oberforstbach, Germany     *
 *  D   D      SS   A   A       Telefon: +49 (0)2408 / 9492-0           *
 *  DDDD    SSSS    A   A       Telefax: +49 (0)2408 / 9492-92          *
 *                                                                      *
 *                                                                      *
 *  (c) Copyright by DSA - all rights reserved                          *
 *                                                                      *
 ************************************************************************
 *
 * Initial Creation:
 *    Author      hl
 *    Created on  16.04.2008
 *
 ************************************************************************/
package jmetertest;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;


/**
 * Web controller that exports the specified service bean as HTTP invoker service endpoint, accessible via an HTTP invoker proxy.
 * Deserializes remote invocation objects and serializes remote invocation result objects. The result objects are wrapped in
 * {@link JMeterTestRemoteInvocationResultWrapper} which must be deserialized by the client to retrieve the actual result object.
 * The wrapper class encloses a transfer object that holds network statistics which are captured for each method invocation
 * by this service exporter.
 *
 * Uses Java serialization just like RMI.
 * @see org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter
 */
public class JMeterTestHttpServiceExporter extends JMeterTestAbstractHttpInvokerServiceExporter  {

    /** Local logger instance. */
    /** Local logger instance. */
    private static final Log LOG = LogFactory.getLog(JMeterTestHttpServiceExporter.class);

//    /** HTTP header for content type. */
//    private static final String HTTP_HEADER_CONTENT_TYPE = "Content-Type";
//
//    /** HTTP header for content length. */
//    private static final String HTTP_HEADER_CONTENT_LENGTH = "Content-Length";
//
//    /** HTTP header for content enconding. */
//    private static final String HTTP_HEADER_CONTENT_ENCODING = "Content-Encoding";
//
//    /** HTTP encoding for zipped payload. */
//    private static final String HTTP_CONTENT_ENCODING_ZIPPED = "gzip";
//
//    /** HTTP header indicating if compression supported. */
//    private static final String HTTP_HEADER_COMPRESSION_SUPPORTED = "Compression-Supported";

//    /** UTC Timezone. */
//    private static final TimeZone UTC_TIMEZONE = new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC");
//
//    /** Timeformat for logged timestamps.*/
//    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("HH:mm:ss S");

//    /** Indicating whether response compression is enabled. */
//    private boolean compressionEnabled;

    /** No-arg constructor. Does nothing. */
    public JMeterTestHttpServiceExporter() {
        LOG.debug("JMeterTestHttpServiceExporter initalized.");
    }
//
//    /**
//     * Enables compression of response payload.
//     * @param enabled true if paylad is to be compressed.
//     */
//    public void setCompressionEnabled(boolean enabled) {
//        this.compressionEnabled = enabled;
//    }

    /***
     * Read a remote invocation from the request, execute it, and write the remote invocation result to the response.
     * In addition, the execution time is logged and stored in ThreadLocal object.
     *
     * @param request the HTTP request that contains the method invocation parameters
     * @param response the HTTP response send to the client
     * @return the ModelAndView instance returned by the default implementation of org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter() .
     * @throws IOException if thrown by operations on the response
     * @throws ClassNotFoundException if thrown by operations on the response
     * @see org.springframework.remoting.httpinvoker.HttpInvokerServiceExporter#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws IOException, ClassNotFoundException {
        ModelAndView mv = super.handleRequest(request, response);
        return mv;
    }

//    /***
//     * Writes the given RemoteInvocationResult to the given HTTP response.
//     *
//     * @param request current HTTP request
//     * @param response current HTTP response
//     * @param result the RemoteInvocationResult object
//     * @throws IOException if thrown by operations on the response
//     */
//    /** {@inheritDoc} */
//    protected void writeRemoteInvocationResult(HttpServletRequest request, HttpServletResponse response, RemoteInvocationResult result) throws IOException {
//
//        boolean isResponsePayloadCompressed = isResponsePayloadZipCompressed(request);
//        byte[] resultArray = writeResultToByteArray(result, isResponsePayloadCompressed);
//
//        writeResponseFromByteArray(response, resultArray, isResponsePayloadCompressed);
//    }

//    /**
//     * Writes the result of the remote invocation to a byte array (either compressed or uncompressed).
//     *
//     * @param result The remote invocation result to write to the byte array.
//     * @param isResponsePayloadCompressed boolean flag that indicates whether
//     *        the result in the array must be compressed or not.
//     * @return The byte array containing the (compressed or uncompressed) result data.
//     * @throws IOException if an I/O error occurs.
//     */
//    private byte[] writeResultToByteArray(RemoteInvocationResult result, boolean isResponsePayloadCompressed) throws IOException {
//
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        ObjectOutputStream oos;
//        if ( isResponsePayloadCompressed ) {
//            oos = new ObjectOutputStream(new GZIPOutputStream(baos));
//        } else {
//            oos = new ObjectOutputStream(baos);
//        }
//        byte[] resultArray = baos.toByteArray();
//        return resultArray;
//    }



//    /**
//     * Sets the HTTP headers and writes the byte array containing result data
//     * (either compressed or uncompressed) back to the client.
//     *
//     * @param response The HttpServletResponse object.
//     * @param resultArray The result array to be written to the client.
//     * @param isResponsePayloadCompressed boolean flag that indicates whether
//     *        response data in the result array are compressed or not.
//     * @throws IOException if an I/O error occurs.
//     */
//    private void writeResponseFromByteArray(HttpServletResponse response, byte[] resultArray, boolean isResponsePayloadCompressed) throws IOException {
//
//        String strHeaders = "";
//
//        response.setContentType(CONTENT_TYPE_SERIALIZED_OBJECT);
//        strHeaders += "\n        " + HTTP_HEADER_CONTENT_TYPE + ": " + CONTENT_TYPE_SERIALIZED_OBJECT;
//
//        if ( isResponsePayloadCompressed ) {
//            response.setHeader(HTTP_HEADER_CONTENT_ENCODING, HTTP_CONTENT_ENCODING_ZIPPED);
//            strHeaders += "\n        " + HTTP_HEADER_CONTENT_ENCODING + ": " + HTTP_CONTENT_ENCODING_ZIPPED;
//        }
//
//        response.setContentLength(resultArray.length);
//        strHeaders += "\n        " + HTTP_HEADER_CONTENT_LENGTH + ": " + resultArray.length;
//
//        LOG.debug("HTTP RESPONSE HEADERS: " + strHeaders);
//        response.getOutputStream().write(resultArray);
//    }

//    /**
//     * Return the InputStream to use for reading remote invocations, potentially decorating the given original InputStream with
//     * a ZipInputStream in case the expected payload is zip-compressed.
//     *  @param request current HTTP request
//     *  @param in the original InputStream
//     *  @return If the payload is potentially zip-compressed as indicated by the corresponding marker in the request header, a ZipInputStream.
//     *  In case the payload is not zip-compressed, the passed InputStream as is.
//     *  @exception IOException
//     */
//    /** {@inheritDoc} */
//    protected InputStream decorateInputStream(HttpServletRequest request, InputStream in) throws IOException {
//        if (isRequestPayloadZipCompressed(request)) {
//            return new GZIPInputStream(in);
//        } else {
//            return in;
//        }
//    }

//    /**
//     * Checks if a http request contains zip-compressed payload.
//     * The payload is assumed to be zip-compressed in case the HTTP-header content-encoding is equal to "gzip".
//     *
//     * @param request the http request of the remote method invocation
//     * @return true if content-encoding specified in the HTTP header of <code>request</code> is equal to "gzip".
//     */
//    private boolean isRequestPayloadZipCompressed(HttpServletRequest request) {
//        String encoding = request.getHeader(HTTP_HEADER_CONTENT_ENCODING);
//
//        if (LOG.isDebugEnabled() && encoding != null) {
//            LOG.debug("Encoding is: " + encoding);
//        }
//        if (encoding != null && encoding.equalsIgnoreCase(HTTP_CONTENT_ENCODING_ZIPPED)) {
//            LOG.debug("Request content is zip-compressed. ");
//            return true;
//        } else {
//            LOG.debug("Request content is not zip-compressed. ");
//            return false;
//        }
//    }

//    /**
//     * Checks if a response is to be zip-compressed
//     * The payload is assumed to be zip-compressed in case compression is enabled and
//     * the payload size exceeds the configured threshold.
//     *
//     * @param request the http request send by client application
//     * @return true if compression enabled and the response payload exceeds the
//     * configured threshold.
//     */
//    private boolean isResponsePayloadZipCompressed(HttpServletRequest request) {
//
//        if (!compressionEnabled) {
//            if ( LOG.isDebugEnabled() ) {
//                LOG.debug("Server does not support payload compression. (Feature turned off)");
//            }
//            return false;
//        } else {
//            if ( LOG.isDebugEnabled() ) {
//                LOG.debug("Server supports payload compression. (Feature turned on)");
//            }
//        }
//
//        String headerValue = request.getHeader(HTTP_HEADER_COMPRESSION_SUPPORTED);
//
//        if (headerValue != null && headerValue.equalsIgnoreCase("true")) {
//            if ( LOG.isDebugEnabled() ) {
//                LOG.debug("Client supports payload compression.");
//            }
//            return true;
//        } else {
//            if ( LOG.isDebugEnabled() ) {
//                LOG.debug("Client does not support payload compression.");
//            }
//            return false;
//        }
//    }

}
