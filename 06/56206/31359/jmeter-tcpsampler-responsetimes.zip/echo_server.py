#!/usr/bin/env python

"""
A simple echo server (TCP)
"""

import socket
import time
import datetime

# define server properties
host = ''
port = 9004
backlog = 5
size = 1024

# configure the server socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host,port))
s.listen(backlog)

# handle client requests
while 1:
	client, address = s.accept()
	data = client.recv(size)
	recvtime = datetime.datetime.now()
	if data:
		time.sleep(.5) # delays for .5 seconds
		client.send(data)
		sendtime = datetime.datetime.now()
		responsetime = sendtime - recvtime
		print("recv: " + recvtime.strftime('%H:%M:%S.%f') + 
		"; send: " + sendtime.strftime('%H:%M:%S.%f') + 
		"; response time: " + ("%d.%d sec" % (responsetime.seconds, responsetime.microseconds)))
	client.close() 
