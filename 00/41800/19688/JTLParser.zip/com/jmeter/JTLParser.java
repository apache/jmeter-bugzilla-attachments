package com.jmeter;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;

public class JTLParser
{
	public static String trimDigits(String s,int numPos)
	{
		String number="";
		if(numPos==0)
			number=s.substring(0,s.indexOf("."));
		else
		{
			if(s.substring(s.indexOf(".")+1,s.length()).length()>numPos-1)
				number=s.substring(0,s.indexOf("."))+s.substring(s.indexOf("."),s.indexOf(".")+numPos+1);
			else
				number=s.substring(0,s.indexOf("."))+s.substring(s.indexOf("."),s.indexOf(".")+s.substring(s.indexOf("."),s.length()).length());
		}
		return number;
	}

	private float percentagepass = 0, percentagefail=0;
    	float passCount, failCount, skipCount,totalExecuted;

	public int getPassCount() { return (int)(passCount); }
	public int getFailCount() { return (int) failCount; }
    	public int getSkipCount() { return (int) skipCount; }
    	public int getExecutedCount() { return (int)(passCount + failCount); }


	public void parse(File file)throws Exception
	{
	        String input=file.getName();         
		int outputIndex=input.lastIndexOf(".jtl",input.length());
		String outputFile=input.substring(0,outputIndex)+".html";
		FileWriter fw=new FileWriter(new File(outputFile));
		BufferedWriter bw=new BufferedWriter(fw);
		PrintWriter out=new PrintWriter(bw);
		/*
			Initialize the html page and Set the headers 
		*/
		out.println("<html>");
		out.println("<title> Web-2.0 MT Functional Testing Results </title>");
		out.println("<h2> <center> Web-2.0 MT Functional Testing Results </center> </h2>");
		out.println("<body>");
		out.println("<table cellpadding=1 border=3 align=center>");
		out.println("<th align=left BGCOLOR=\"#CCCCFF\">Http Request</th><th align=left BGCOLOR=\"#CCCCFF\">Response Code</th><th align=left BGCOLOR=\"#CCCCFF\">Response Data</th>");
		out.println("<th align=left BGCOLOR=\"#CCCCFF\">Thread Group</th><th align=left BGCOLOR=\"#CCCCFF\">Response Type</th><th align=left BGCOLOR=\"#CCCCFF\">Assertion Result</th>");
		
                if(!file.exists())
                {
                        System.out.println("No such data file : " + file);
                        return;
                }
		BufferedReader inputReader=new BufferedReader(new FileReader(file));
		String httpRequest=null, resCode=null, resData=null,tempLine=null;
		String thGroup=null, resType=null, assResult=null;
		String omitFirstString=null, omitSecondString=null;
                while((tempLine=inputReader.readLine())!=null)
                {
                 	
			out.println("<tr>");
			int omitIndex1= tempLine.indexOf(",")-1;
			omitFirstString= tempLine.substring(1,omitIndex1);
			int omitIndex2=tempLine.indexOf(",",omitIndex1+2);
			omitSecondString=tempLine.substring(omitIndex1+2,omitIndex2);
		
			// Get data for "Http Request" 	
			int httpRequestIndex=tempLine.indexOf(",",omitIndex2+1);
			httpRequest=tempLine.substring(omitIndex2+1,httpRequestIndex);
		//	//out.println("<td align=\"left\">"+httpRequest+"</td>");
		
			// Get data for "Response Code" 	
			int resCodeIndex=tempLine.indexOf(",",httpRequestIndex+1);
			resCode=tempLine.substring(httpRequestIndex+1,resCodeIndex);
		//	//out.println("<td align=\"left\">"+resCode+"</td>");


			int resDataIndex=tempLine.indexOf(",",resCodeIndex+1);
			resData=tempLine.substring(resCodeIndex+1,resDataIndex);
		//	//out.println("<td align=\"left\">"+resData+"</td>");

			int thGroupIndex=tempLine.indexOf(",",resDataIndex+1);
			thGroup=tempLine.substring(resDataIndex+1,thGroupIndex);
		//	//out.println("<td align=\"left\">"+thGroup+"</td>");

			int resTypeIndex=tempLine.indexOf(",",thGroupIndex+1);
			resType=tempLine.substring(thGroupIndex+1,resTypeIndex);
		//	//out.println("<td align=\"left\">"+resType+"</td>");

			/*No ',' separator at the end of line
			int assResultIndex=tempLine.indexOf(",",resTypeIndex+1); */
			String assColor="green";
        	assResult=tempLine.substring(resTypeIndex+1,tempLine.length());
        	if(assResult.equalsIgnoreCase("false"))
		{
        		assColor="red";
			failCount++;
		}
		else		
			passCount++;
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+httpRequest+"</font></b></td>");
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+resCode+"</font></b></td>");
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+resData+"</font></b></td>");
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+thGroup+"</font></b></td>");
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+resType+"</font></b></td>");
        	
        	out.println("<td align=\"left\" bgcolor=\"#CCCCCC\"><b><font color=" + assColor + ">"+ assResult + "</font></b></td>");
			out.println("</tr>");
		}
		totalExecuted = (passCount+failCount);
		percentagepass = ((passCount/totalExecuted)*100);
		percentagefail = ((failCount/totalExecuted)*100);
		System.out.println("**************Final Result******************");
		System.out.println("	 Total Tests Executed : " + trimDigits((new Float(totalExecuted)).toString(),0));
		System.out.println("	 Total Passed	      : " + trimDigits((new Float(passCount)).toString(),0));
		System.out.println("	 Total Failed	      : " + trimDigits((new Float(failCount)).toString(),0));
		System.out.println("	 Pass Percentage      : " + trimDigits((new Float(percentagepass)).toString(),2) + "%");
		System.out.println("********************************************");
		out.println("</table>");
		out.println("<br>");
		out.println("<h2><center>Summary</center> </h2>");
		out.println("<table cellpadding=1 border=3 align=center width=\"92%\">");
	        out.println("<th align=left BGCOLOR=\"#CCCCFF\">Tests</th><th align=left BGCOLOR=\"#CCCCFF\">Failures</th><th align=left BGCOLOR=\"#CCCCFF\">Success</th><tr>");

//		out.println("<tr>");
        	out.println("<td>" + trimDigits((new Float(totalExecuted)).toString(), 0) + "</td><td>" + trimDigits((new Float(failCount)).toString(), 0) + "</td><td>" + trimDigits((new Float(passCount)).toString(), 0) + "</td>");
		out.println("</tr>");
		out.println("</table>");

		
		out.println("</body>");
		out.println("</html>");
		out.close();


	}
	public float getPercentagePass() {
        	return percentagepass;
    	}

    	public float getPercentageFailure() {
        	return 100 - percentagepass;
    	}
	public static void main(String args[]) throws Exception
	{
		JTLParser jtl=new JTLParser();
		jtl.parse(new File(args[0]));
	}	
}

