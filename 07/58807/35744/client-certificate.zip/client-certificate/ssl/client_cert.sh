# create client key and certificate
openssl genrsa -out client$1.key 2048
openssl req -new -key client$1.key -out client$1.csr -subj "/C=DE/ST=Germany/L=Walldorf/O=SAP SE/OU=Tools/CN=client_$1"
openssl x509 -req -in client$1.csr -CA rootCA.crt -CAkey rootCA.key -CAcreateserial -out client$1.crt -days 500

# generate client.p12 file which can be easily imported to OS.
openssl pkcs12 -export -inkey client$1.key -in client$1.crt -name client$1 -out client$1.p12

# generate a non-encrypt pem file with key and crt files, from p12 files
#openssl pkcs12 -in client$1.p12 -out client$1.pem -nodes -clcerts

