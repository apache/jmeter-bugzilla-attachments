package org.apache.jmeter.protocol.http.control;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.jmeter.assertions.Assertion;
import org.apache.jmeter.assertions.AssertionResult;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.property.CollectionProperty;
import org.apache.jmeter.testelement.property.IntegerProperty;
import org.apache.jmeter.testelement.property.JMeterProperty;
import org.apache.jmeter.testelement.property.NullProperty;
import org.apache.jmeter.testelement.property.PropertyIterator;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.apache.oro.text.MalformedCachePatternException;
import org.apache.oro.text.regex.Pattern;
import org.apache.oro.text.regex.Perl5Compiler;
import org.apache.oro.text.regex.Perl5Matcher;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * Assertion that waits for given amount of time for a network callback and validates
 * the content when it gets one.  If the given amount of time is exceeded or the callback
 * doesn't match the expectation the the assertion fails.
 * 
 * @author Gerard Dougan
 */
public class HttpCallbackAssertion extends AbstractTestElement implements Assertion {

    private static final long serialVersionUID = 1L;

    private static final Logger log = LoggingManager.getLoggerForClass();
    
    private final static int MATCH = 1 << 0;
    private final static int CONTAINS = 1 << 1;
    private final static int NOT = 1 << 2;
    private final static int EQUALS = 1 << 3;

    private final static int TYPE_MASK = CONTAINS | EQUALS | MATCH;
    
    public static final String TIMEOUT = "HttpCallbackAssertion.timeout";
    public static final String PORT = "HttpCallbackAssertion.port";
    private final static String TEST_TYPE = "HttpCallbackAssertion.testType";
    private final static String TEST_STRINGS = "HttpCallbackAssertion.testStrings";
    
    private static final int  EQUALS_SECTION_DIFF_LEN = JMeterUtils.getPropDefault("assertion.equals_section_diff_len", 100);
    private static final String EQUALS_DIFF_TRUNC = "...";

    private static final String RECEIVED_STR = "****** received  : ";
    private static final String COMPARISON_STR = "****** comparison: ";
    private static final String DIFF_DELTA_START = JMeterUtils.getPropDefault("assertion.equals_diff_delta_start", "[[[");
    private static final String DIFF_DELTA_END = JMeterUtils.getPropDefault("assertion.equals_diff_delta_end", "]]]");
    
    public static final long DEFAULT_TIMEOUT = 30;
    public static final long DEFAULT_PORT = 0;
    
    private HttpServer server;
    private ExecutorService threadPool;
    
    private String callback;
    
    public HttpCallbackAssertion() {
        setProperty(TIMEOUT, String.valueOf(DEFAULT_TIMEOUT));
        setProperty(PORT, String.valueOf(DEFAULT_PORT));
        setProperty(new CollectionProperty(TEST_STRINGS, new ArrayList<String>()));
    }
    
    @Override
    public void clear() {
        super.clear();
        setProperty(TIMEOUT, String.valueOf(DEFAULT_TIMEOUT));
        setProperty(PORT, String.valueOf(DEFAULT_PORT));
        setProperty(new CollectionProperty(TEST_STRINGS, new ArrayList<String>()));
    }
    
    public long getTimeout() {
        return getPropertyAsLong(TIMEOUT);
    }
    
    public void setTimeout(String timeout) {
        setProperty(TIMEOUT, timeout);
    }
    
    public String getPort() {
        return getPropertyAsString(PORT);
    }
    
    public void setPort(String port) {
        setProperty(PORT, port);
    }

    private void setTestType(int testType) {
        setProperty(new IntegerProperty(TEST_TYPE, testType));
    }

    private void setTestTypeMasked(int testType) {
        int value = getTestType() & ~(TYPE_MASK) | testType;
        setProperty(new IntegerProperty(TEST_TYPE, value));
    }

    public void addTestString(String testString) {
        getTestStrings().addProperty(new StringProperty(String.valueOf(testString.hashCode()), testString));
    }

    public void clearTestStrings() {
        getTestStrings().clear();
    }
    
    public CollectionProperty getTestStrings() {
        return (CollectionProperty) getProperty(TEST_STRINGS);
    }

    public boolean isEqualsType() {
        return (getTestType() & EQUALS) > 0;
    }

    public boolean isContainsType() {
        return (getTestType() & CONTAINS) > 0;
    }

    public boolean isMatchType() {
        return (getTestType() & MATCH) > 0;
    }

    public boolean isNotType() {
        return (getTestType() & NOT) > 0;
    }

    public void setToContainsType() {
        setTestTypeMasked(CONTAINS);
    }

    public void setToMatchType() {
        setTestTypeMasked(MATCH);
    }

    public void setToEqualsType() {
        setTestTypeMasked(EQUALS);
    }

    public void setToNotType() {
        setTestType((getTestType() | NOT));
    }

    public void unsetNotType() {
        setTestType(getTestType() & ~NOT);
    }
    
    public int getTestType() {
        JMeterProperty type = getProperty(TEST_TYPE);
        if (type instanceof NullProperty) {
            return CONTAINS;
        }
        return type.getIntValue();
    }
    
    @Override
    public AssertionResult getResult(SampleResult paramSampleResult) {
        startServer();
        
        long timeout = getTimeout();
        while (timeout > 0) {
            try {
                if (callback != null) {
                    break;
                }
                Thread.sleep(3000);
                timeout -= 3;
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        
        AssertionResult result = null;
        if (callback == null) {
            result = new AssertionResult("Network Callback Listener");
            result.setFailure(true);
            result.setFailureMessage("No callback received");
        } else {
            result = evaluateResponse(callback);
        }
        
        stopServer();
        return result;
    }
    
    private class MockHttpHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            byte[] bytes=new byte[exchange.getRequestBody().available()];
            exchange.getRequestBody().read(bytes);
            String body = new String(bytes);
            callback = body;
            
            Headers responseHeaders = exchange.getResponseHeaders();
            responseHeaders.set("Content-Type", "text/plain");
            exchange.sendResponseHeaders(200, 0);
            exchange.getResponseBody().write("".getBytes());
            exchange.getResponseBody().close();
        }
    }
    
    private void startServer() {
        if (server == null) {
            InetSocketAddress addr = new InetSocketAddress(Integer.parseInt(getPort()));
            try {
                server = HttpServer.create(addr, 0);
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            threadPool = Executors.newCachedThreadPool();
            
            server.createContext("/", new MockHttpHandler());
            server.setExecutor(threadPool);
            server.start();
            log.info("Network callback listener started on port " + getPort());
        }
    }
    
    private void stopServer() {
        if (threadPool != null) {
            threadPool.shutdown();
            threadPool = null;
        }
        if (server != null) {
            server.stop(0);
            server = null;
            log.info("Network callback listener on port " + getPort() + " stopped");
        }
    }
    
    private AssertionResult evaluateResponse(String toCheck) {
        boolean pass = true;
        boolean notTest = (NOT & getTestType()) > 0;
        AssertionResult result = new AssertionResult(getName());

        result.setFailure(false);
        result.setError(false);

        if (toCheck.length() == 0) {
            if (notTest) {
                return result;
            }
            return result.setResultForNull();
        }

        boolean contains = isContainsType(); 
        boolean equals = isEqualsType();
        boolean matches = isMatchType();
        boolean debugEnabled = log.isDebugEnabled();
        if (debugEnabled){
            log.debug("Type:" + (contains?"Contains":"Match") + (notTest? "(not)": ""));
        }

        try {
            Perl5Matcher localMatcher = JMeterUtils.getMatcher();
            PropertyIterator iter = getTestStrings().iterator();
            while (iter.hasNext()) {
                String stringPattern = iter.next().getStringValue();
                Pattern pattern = null;
                if (contains || matches) {
                    pattern = JMeterUtils.getPatternCache().getPattern(stringPattern, Perl5Compiler.READ_ONLY_MASK);
                }
                boolean found;
                if (contains) {
                    found = toCheck.contains(stringPattern);
                } else if (equals) {
                    found = toCheck.equals(stringPattern);
                } else {
                    found = localMatcher.matches(toCheck, pattern);
                }
                pass = notTest ? !found : found;
                if (!pass) {
                    if (debugEnabled){log.debug("Failed: "+stringPattern);}
                    result.setFailure(true);
                    result.setFailureMessage(getFailText(stringPattern,toCheck));
                    break;
                }
                if (debugEnabled){log.debug("Passed: "+stringPattern);}
            }
        } catch (MalformedCachePatternException e) {
            result.setError(true);
            result.setFailure(false);
            result.setFailureMessage("Bad test configuration " + e);
        }
        return result;
    }

    private String getFailText(String stringPattern, String toCheck) {

        StringBuilder sb = new StringBuilder(200);
        sb.append("Test failed: ");

        switch (getTestType()) {
        case CONTAINS:
        case NOT | CONTAINS:
        case MATCH:
            sb.append(" expected to match ");
            break;
        case NOT | MATCH:
            sb.append(" expected not to match ");
            break;
        case EQUALS:
            sb.append(" expected to equal ");
            break;
        case NOT | EQUALS:
            sb.append(" expected not to equal ");
            break;
        default:
            sb.append(" expected something using ");
        }

        sb.append("/");

        if (isEqualsType()){
            sb.append(equalsComparisonText(toCheck, stringPattern));
        } else {
            sb.append(stringPattern);
        }

        sb.append("/");

        return sb.toString();
    }


    private static String trunc(final boolean right, final String str)
    {
        if (str.length() <= EQUALS_SECTION_DIFF_LEN) {
            return str;
        } else if (right) {
            return str.substring(0, EQUALS_SECTION_DIFF_LEN) + EQUALS_DIFF_TRUNC;
        } else {
            return EQUALS_DIFF_TRUNC + str.substring(str.length() - EQUALS_SECTION_DIFF_LEN, str.length());
        }
    }

    /**
     * Returns some helpful logging text to determine where equality between two strings
     * is broken, with one pointer working from the front of the strings and another working
     * backwards from the end.
     *
     * @param received      String received from sampler.
     * @param comparison    String specified for "equals" response assertion.
     * @return  Two lines of text separated by newlines, and then forward and backward pointers
     *      denoting first position of difference.
     */
    private static StringBuilder equalsComparisonText(final String received, final String comparison)
    {
        int                     firstDiff;
        int                     lastRecDiff = -1;
        int                     lastCompDiff = -1;
        final int               recLength = received.length();
        final int               compLength = comparison.length();
        final int               minLength = Math.min(recLength, compLength);
        final String            startingEqSeq;
        String                  recDeltaSeq = "";
        String                  compDeltaSeq = "";
        String                  endingEqSeq = "";

        final StringBuilder text = new StringBuilder(Math.max(recLength, compLength) * 2);
        for (firstDiff = 0; firstDiff < minLength; firstDiff++) {
            if (received.charAt(firstDiff) != comparison.charAt(firstDiff)){
                break;
            }
        }
        if (firstDiff == 0) {
            startingEqSeq = "";
        } else {
            startingEqSeq = trunc(false, received.substring(0, firstDiff));
        }

        lastRecDiff = recLength - 1;
        lastCompDiff = compLength - 1;

        while ((lastRecDiff > firstDiff) && (lastCompDiff > firstDiff)
                && received.charAt(lastRecDiff) == comparison.charAt(lastCompDiff))
        {
            lastRecDiff--;
            lastCompDiff--;
        }
        endingEqSeq = trunc(true, received.substring(lastRecDiff + 1, recLength));
        if (endingEqSeq.length() == 0)
        {
            recDeltaSeq = trunc(true, received.substring(firstDiff, recLength));
            compDeltaSeq = trunc(true, comparison.substring(firstDiff, compLength));
        }
        else
        {
            recDeltaSeq = trunc(true, received.substring(firstDiff, lastRecDiff + 1));
            compDeltaSeq = trunc(true, comparison.substring(firstDiff, lastCompDiff + 1));
        }
        final StringBuilder pad = new StringBuilder(Math.abs(recDeltaSeq.length() - compDeltaSeq.length()));
        for (int i = 0; i < pad.capacity(); i++){
            pad.append(' ');
        }
        if (recDeltaSeq.length() > compDeltaSeq.length()){
            compDeltaSeq += pad.toString();
        } else {
            recDeltaSeq += pad.toString();
        }

        text.append("\n\n");
        text.append(RECEIVED_STR);
        text.append(startingEqSeq);
        text.append(DIFF_DELTA_START);
        text.append(recDeltaSeq);
        text.append(DIFF_DELTA_END);
        text.append(endingEqSeq);
        text.append("\n\n");
        text.append(COMPARISON_STR);
        text.append(startingEqSeq);
        text.append(DIFF_DELTA_START);
        text.append(compDeltaSeq);
        text.append(DIFF_DELTA_END);
        text.append(endingEqSeq);
        text.append("\n\n");
        return text;
    }
}
