package org.apache.jmeter.protocol.http.control.util;

import static org.apache.jmeter.protocol.http.control.bean.ScenarioRequestExpression.ExpressionTarget.*;

import java.io.StringReader;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;

import org.apache.jmeter.protocol.http.control.bean.ScenarioRequestExpression;
import org.apache.jmeter.threads.JMeterVariables;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 * Handles the runtime evaluation of all supported scenario request expressions 
 * 
 * @author Gerard Dougan
 */
public class ExpressionEvaluater {

    public static void evaluateExpressions(List<ScenarioRequestExpression> expressions, String url, String body, 
            JMeterVariables jMeterVariables, Map<String, String> extractedVariables) {
        for (ScenarioRequestExpression expression : expressions) {
            String target = expression.getExpressionTarget().equals(PATH) ? url : body;
            String result = "";
            switch (expression.getExpressionType()) {
                case XPATH : result = evaluateXPath(expression.getExpression(), target); break;
                case JSON_QUERY : result = evaluateJson(expression.getExpression(), target); break;
                case REGEX : result = evaluateRegex(expression.getExpression(), target); break;
            }
            jMeterVariables.put(expression.getResultingJMeterVariableName(), result);
            extractedVariables.put(expression.getResultingJMeterVariableName(), result);
        }
    }
    
    public static String evaluateXPath(String expression, String input) {
        try {
            StringReader reader = new StringReader(input);
            InputSource inputSource = new InputSource(reader);
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputSource);
            reader.close();
        
            return XPathFactory.newInstance().newXPath().evaluate(expression, doc);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
    
    public static String evaluateJson(String expression, String input) {
        try {
            ScriptEngineManager factory = new ScriptEngineManager();
            ScriptEngine engine = factory.getEngineByName("JavaScript");
            String script = "function evaluate(query, input) { " +
            		            "object = eval('(' + input + ')');" +
            		            "return eval('object.' + query);" +
            		        "}";
            engine.eval(script);

            Invocable inv = (Invocable) engine;

            return String.valueOf(inv.invokeFunction("evaluate", expression, input));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ""; 
    }
    
    public static String evaluateRegex(String expression, String target) {
        Pattern pattern = Pattern.compile(expression);
        Matcher matcher = pattern.matcher(target);
        boolean matchFound = matcher.find();

        if (matchFound) {
            return matcher.group(1);
        }
        return "";
    }
}
