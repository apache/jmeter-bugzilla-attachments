package org.apache.jmeter.protocol.http.control.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.apache.jmeter.assertions.gui.AbstractAssertionGui;
import org.apache.jmeter.gui.util.HeaderAsPropertyRenderer;
import org.apache.jmeter.gui.util.PowerTableModel;
import org.apache.jmeter.gui.util.TextAreaCellRenderer;
import org.apache.jmeter.gui.util.TextAreaTableCellEditor;
import org.apache.jmeter.protocol.http.control.HttpCallbackAssertion;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.PropertyIterator;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.gui.JLabeledTextField;

/**
 * Configuration GUI for the network callback listener 
 * 
 * @author Gerard Dougan
 */
public class HttpCallbackAssertionGui extends AbstractAssertionGui {
    
    private static final long serialVersionUID = -9214884465261470761L;
    
    private static final String COL_RESOURCE_NAME = "assertion_patterns_to_test";

    private JLabeledTextField timeout = new JLabeledTextField("Maximum Wait Time (seconds)");
    private JLabeledTextField port = new JLabeledTextField("Port");
    
    private JRadioButton containsBox;
    private JRadioButton matchesBox;
    private JRadioButton equalsBox;
    private JCheckBox notBox;

    private JTable stringTable;
    private JButton addPattern;
    private JButton deletePattern;
    
    private PowerTableModel tableModel;
    
    public HttpCallbackAssertionGui() {
        init();
    }
    
    public TestElement createTestElement() {
        HttpCallbackAssertion networkCallbackListener = new HttpCallbackAssertion();
        configureTestElement(networkCallbackListener);
        return (TestElement) networkCallbackListener.clone();
    }

    // Modifies a given TestElement to mirror the data in the gui components.
    public void modifyTestElement(TestElement el) {
        HttpCallbackAssertion networkCallbackListener = (HttpCallbackAssertion) el;
        networkCallbackListener.setTimeout(timeout.getText());
        networkCallbackListener.setPort(port.getText());
        
        networkCallbackListener.clearTestStrings();
        String[] testStrings = tableModel.getData().getColumn(COL_RESOURCE_NAME);
        for (int i = 0; i < testStrings.length; i++) {
            networkCallbackListener.addTestString(testStrings[i]);
        }

        if (containsBox.isSelected()) {
            networkCallbackListener.setToContainsType();
        } else if (equalsBox.isSelected()) {
            networkCallbackListener.setToEqualsType();
        } else {
            networkCallbackListener.setToMatchType();
        }

        if (notBox.isSelected()) {
            networkCallbackListener.setToNotType();
        } else {
            networkCallbackListener.unsetNotType();
        }
        
        configureTestElement(networkCallbackListener);
    }

    @Override
    public void clearGui() {
        super.clearGui();
        timeout.setText("");
        
        tableModel.clearData();

        containsBox.setSelected(true);
        notBox.setSelected(false);
    }

    @Override
    public void configure(TestElement el) {
        super.configure(el);
        HttpCallbackAssertion networkCallbackListener = (HttpCallbackAssertion) el;
        timeout.setText(String.valueOf(networkCallbackListener.getTimeout()));
        port.setText(networkCallbackListener.getPort());
        
        if (networkCallbackListener.isContainsType()) {
            containsBox.setSelected(true);
        } else if (networkCallbackListener.isEqualsType()) {
            equalsBox.setSelected(true);
        } else {
            matchesBox.setSelected(true);
        }

        notBox.setSelected(networkCallbackListener.isNotType());

        tableModel.clearData();
        PropertyIterator tests = networkCallbackListener.getTestStrings().iterator();
        while (tests.hasNext()) {
            tableModel.addRow(new Object[] { tests.next().getStringValue() });
        }

        if (networkCallbackListener.getTestStrings().size() == 0) {
            deletePattern.setEnabled(false);
        } else {
            deletePattern.setEnabled(true);
        }

        tableModel.fireTableDataChanged();
    }

    @Override
    public String getStaticLabel() {
        return "HTTP Callback Assertion";
    }

    private void init() {
        setLayout(new BorderLayout());
        Box box = Box.createVerticalBox();
        setBorder(makeBorder());

        box.add(makeTitlePanel());
        box.add(createCallbackInfoPanel());
        box.add(createTypePanel());
        add(box, BorderLayout.NORTH);
        add(createStringPanel(), BorderLayout.CENTER);
    }
    
    private JPanel createCallbackInfoPanel() {
        JPanel detailsPanel = new JPanel();
        
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        detailsPanel.setLayout(new GridBagLayout());
        
        GridBagConstraints c = new GridBagConstraints();
        c.fill = 2;
        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new Insets(0, 0, 10, 0);
        c.weightx = 1.0D;
        detailsPanel.add(this.timeout, c);
        timeout.setText(String.valueOf(HttpCallbackAssertion.DEFAULT_TIMEOUT));
        
        c.gridy = 2;
        detailsPanel.add(port, c);
        
        return detailsPanel;
    }
    
    private JPanel createTypePanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Expected Callback Pattern Matching Rules"));

        ButtonGroup group = new ButtonGroup();

        containsBox = new JRadioButton(JMeterUtils.getResString("assertion_contains"));
        group.add(containsBox);
        containsBox.setSelected(true);
        panel.add(containsBox);

        matchesBox = new JRadioButton(JMeterUtils.getResString("assertion_matches"));
        group.add(matchesBox);
        panel.add(matchesBox);

        equalsBox = new JRadioButton(JMeterUtils.getResString("assertion_equals"));
        group.add(equalsBox);
        panel.add(equalsBox);

        notBox = new JCheckBox(JMeterUtils.getResString("assertion_not"));
        panel.add(notBox);

        return panel;
    }

    private JPanel createStringPanel() {
        tableModel = new PowerTableModel(new String[] { COL_RESOURCE_NAME }, new Class[] { String.class });
        stringTable = new JTable(tableModel);
        stringTable.getTableHeader().setDefaultRenderer(new HeaderAsPropertyRenderer());

        TextAreaCellRenderer renderer = new TextAreaCellRenderer();
        stringTable.setRowHeight(renderer.getPreferredHeight());
        stringTable.setDefaultRenderer(String.class, renderer);
        stringTable.setDefaultEditor(String.class, new TextAreaTableCellEditor());
        stringTable.setPreferredScrollableViewportSize(new Dimension(100, 70));

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Expected Callback Patterns to Test"));

        panel.add(new JScrollPane(stringTable), BorderLayout.CENTER);
        panel.add(createButtonPanel(), BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createButtonPanel() {
        addPattern = new JButton(JMeterUtils.getResString("add"));
        addPattern.addActionListener(new AddPatternListener());

        deletePattern = new JButton(JMeterUtils.getResString("delete"));
        deletePattern.addActionListener(new ClearPatternsListener());
        deletePattern.setEnabled(false);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addPattern);
        buttonPanel.add(deletePattern);
        return buttonPanel;
    }

    private class ClearPatternsListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int index = stringTable.getSelectedRow();
            if (index > -1) {
                stringTable.getCellEditor(index, stringTable.getSelectedColumn()).cancelCellEditing();
                tableModel.removeRow(index);
                tableModel.fireTableDataChanged();
            }
            if (stringTable.getModel().getRowCount() == 0) {
                deletePattern.setEnabled(false);
            }
        }
    }

    private class AddPatternListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            tableModel.addNewRow();
            deletePattern.setEnabled(true);
            tableModel.fireTableDataChanged();
        }
    }

    public String getLabelResource() {
        return "user_defined_variables";
    }
}
