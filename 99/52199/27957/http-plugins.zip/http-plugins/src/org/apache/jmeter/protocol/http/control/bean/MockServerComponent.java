package org.apache.jmeter.protocol.http.control.bean;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;

import org.apache.jmeter.threads.JMeterContext;
import org.apache.jmeter.util.StringUtilities;

import com.sun.net.httpserver.HttpServer;

/**
 * Models a single mock server instance i.e. the http server, its thread pool and
 * the JMeterContext for its corresponding GUI component 
 * 
 * @author Gerard Dougan
 */
public class MockServerComponent {

    private HttpServer server;
    private ExecutorService threadPool;
    private JMeterContext context;

    public MockServerComponent(HttpServer server, ExecutorService threadPool, JMeterContext context) {
        this.server = server;
        this.threadPool = threadPool;
        this.context = context;
    }
    public HttpServer getServer() {
        return server;
    }
    public void setServer(HttpServer server) {
        this.server = server;
    }
    public ExecutorService getThreadPool() {
        return threadPool;
    }
    public void setThreadPool(ExecutorService threadPool) {
        this.threadPool = threadPool;
    }
    public JMeterContext getContext() {
        return context;
    }
    public void setContext(JMeterContext context) {
        this.context = context;
    }
    
    public List<MockServerScenario> resolveVariables(List<MockServerScenario> scenarios) {
        List<MockServerScenario> resolvedScenarios = new ArrayList<MockServerScenario>();
        
        for (MockServerScenario scenario : scenarios) {
            MockServerScenario resolvedScenario = new MockServerScenario(scenario);
            
            Iterator<Entry<String, Object>> iter = context.getVariables().entrySet().iterator();
            while (iter.hasNext()) {
                Entry<String, Object> entry = iter.next();
                String key = entry.getKey();
                String value = String.valueOf(entry.getValue());
                
                resolvedScenario.setExpectedRequestBody(StringUtilities.substitute(resolvedScenario.getExpectedRequestBody(), "${" + key + "}", value));
                resolvedScenario.setResponseBody(StringUtilities.substitute(resolvedScenario.getResponseBody(), "${" + key + "}", value));
                resolvedScenario.setExpectedPath(StringUtilities.substitute(resolvedScenario.getExpectedPath(), "${" + key + "}", value));
            }
            resolvedScenarios.add(resolvedScenario);
        }
        return resolvedScenarios;
    }
}
