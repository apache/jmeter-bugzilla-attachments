package org.apache.jmeter.protocol.http.control.bean;

/**
 * Models a mock server scenario request expression i.e. a discrete expression
 * which can be applied to an incoming request to extract some information for
 * use elsewhere 
 * 
 * @author Gerard Dougan
 */
public class ScenarioRequestExpression {

    public enum ExpressionType {
        XPATH,
        JSON_QUERY,
        REGEX;
    }
    
    public enum ExpressionTarget {
        PATH,
        REQUEST_BODY;
    }
    
    private ExpressionTarget expressionTarget;
    private ExpressionType expressionType;
    private String expression;
    private String resultingJMeterVariableName;
    
    public ScenarioRequestExpression() {}
    
    public ScenarioRequestExpression(ScenarioRequestExpression scenarioRequestExpression) { 
        this.expressionTarget = scenarioRequestExpression.getExpressionTarget();
        this.expressionType = scenarioRequestExpression.getExpressionType();
        this.expression = scenarioRequestExpression.getExpression();
        this.resultingJMeterVariableName = scenarioRequestExpression.getResultingJMeterVariableName();
    }
    
    public ExpressionTarget getExpressionTarget() {
        return expressionTarget;
    }
    public void setExpressionTarget(ExpressionTarget expressionTarget) {
        this.expressionTarget = expressionTarget;
    }
    public ExpressionType getExpressionType() {
        return expressionType;
    }
    public void setExpressionType(ExpressionType expressionType) {
        this.expressionType = expressionType;
    }
    public String getExpression() {
        return expression;
    }
    public void setExpression(String expression) {
        this.expression = expression;
    }
    public String getResultingJMeterVariableName() {
        return resultingJMeterVariableName;
    }
    public void setResultingJMeterVariableName(String resultingJMeterVariableName) {
        this.resultingJMeterVariableName = resultingJMeterVariableName;
    }
    @Override
    public String toString() {
        return "ScenarioRequestExpression [expressionTarget="
                + expressionTarget + ", expressionType=" + expressionType
                + ", expression=" + expression
                + ", resultingJMeterVariableName="
                + resultingJMeterVariableName + "]";
    }
}
