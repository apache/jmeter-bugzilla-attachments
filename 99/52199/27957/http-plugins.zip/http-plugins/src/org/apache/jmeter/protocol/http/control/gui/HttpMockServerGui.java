package org.apache.jmeter.protocol.http.control.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import java.util.Locale;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;

import org.apache.jmeter.config.gui.AbstractConfigGui;
import org.apache.jmeter.gui.util.HorizontalPanel;
import org.apache.jmeter.gui.util.VerticalPanel;
import org.apache.jmeter.protocol.http.control.HttpMirrorControl;
import org.apache.jmeter.protocol.http.control.HttpMockServer;
import org.apache.jmeter.protocol.http.control.bean.*;
import org.apache.jmeter.protocol.http.control.bean.MockServerScenario.MatchType;
import org.apache.jmeter.protocol.http.control.bean.ScenarioRequestExpression.ExpressionTarget;
import org.apache.jmeter.protocol.http.control.bean.ScenarioRequestExpression.ExpressionType;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;

/**
 * Configuration GUI for the http mock server 
 * 
 * @author Gerard Dougan
 */
public class HttpMockServerGui extends AbstractConfigGui {
    
    private static final long serialVersionUID = -9214884465261470761L;

    private static final String ADD_COMMAND = "Add";
    private static final String DUPLICATE_COMMAND = "Duplicate";
    private static final String DELETE_COMMAND = "Delete";

    private static final int NUM_SCENARIO_VISIBLE_ROWS = 7;
    private static final int NUM_REQUEST_EXPR_VISIBLE_ROWS = 3;
    
    private static final int NUM_REQUEST_RESPONSE_VISIBLE_ROWS = 7;
    
    private HttpMockServer manager;
    
    // Port
    private JTextField portField;
    
    // Scenario
    private ScenarioTableModel scenarioTableModel;
    private JTable scenarioTable;
    
    private JButton addScenarioButton = new JButton("Add");
    private JButton duplicateScenarioButton = new JButton("Duplicate");
    private JButton deleteScenarioButton = new JButton("Delete");

    // Request Response Info
    private JLabel expectedPathLabel = new JLabel("Expected Path");
    private JTextField expectedPathField = new JTextField();
    
    private JLabel pathMatchingRuleLabel = new JLabel("Path Matching Rule");
    private ButtonGroup pathMatchingRuleGroup = new ButtonGroup();
    private JRadioButton pathEqualsRadio = new JRadioButton("Equals");
    private JRadioButton pathContainsRadio = new JRadioButton("Contains", true);
    private JRadioButton pathMatchesRadio = new JRadioButton("Matches");
    
    private JLabel httpMethodLabel = new JLabel("Expected HTTP Method");
    private JComboBox httpMethodCombo = new JComboBox(new String []{"GET", "POST", "PUT", "DELETE"});
    
    private JLabel requestBodyMatchingRuleLabel = new JLabel("Body Matching Rule");
    private ButtonGroup requestBodyMatchingRuleGroup = new ButtonGroup();
    private JRadioButton requestNoneMatchingRadio = new JRadioButton("None", true);
    private JRadioButton requestEqualsRadio = new JRadioButton("Equals");
    private JRadioButton requestContainsRadio = new JRadioButton("Contains");
    private JRadioButton requestMatchesRadio = new JRadioButton("Matches");
    
    private JLabel expectedRequestBodyLabel = new JLabel("Expected Request Body");
    private JTextArea expectedRequestBodyField = new JTextArea();
    
    private JLabel responseBodyLabel = new JLabel("Response Body");
    private JTextArea responseBodyField = new JTextArea();

    private JTable requestExpressionTable;
    private RequestExpressionTableModel requestExpressionTableModel;
    
    private JButton addRequestExpressionButton = new JButton("Add");
    private JButton deleteRequestExpressionButton = new JButton("Delete");
    
    public static void main(String [] args) {
        JMeterUtils.setJMeterHome("/data/workspace/atf/jmeter-2.4");
        JMeterUtils.setLocale(Locale.getDefault());
        
        JFrame f = new JFrame();
        f.add(new HttpMockServerGui());
        f.setSize(1280, 1024);
        f.setVisible(true);
    }
    
    @Override
    public String getStaticLabel() {
        return "HTTP Mock Server";
    }
    public String getLabelResource() {
        return "user_defined_variables";
    }
    
    public HttpMockServerGui() {
        manager = new HttpMockServer();
        scenarioTableModel = new ScenarioTableModel();
        requestExpressionTableModel = new RequestExpressionTableModel();
        
        init();
    }

    public TestElement createTestElement() {
        configureTestElement(manager);
        return (TestElement) manager.clone();
    }

    // Modifies a given TestElement to mirror the data in the gui components.
    public void modifyTestElement(TestElement el) {
        if (scenarioTable.isEditing()) {
            scenarioTable.getCellEditor().stopCellEditing();
        }
        HttpMockServer mockControl = (HttpMockServer) el;
        mockControl.setPort(portField.getText());
        mockControl.setScenarios(manager.getScenarios());
        configureTestElement(mockControl);
    }

    @Override
    public void configure(TestElement el) {
        super.configure(el);
        HttpMockServer mockControl = (HttpMockServer) el;
        portField.setText(mockControl.getPort());
        manager.setScenarios(mockControl.getScenarios());
        if (scenarioTableModel.getRowCount() != 0) {
            deleteScenarioButton.setEnabled(true);
            duplicateScenarioButton.setEnabled(true);
        }
    }
    
    @Override
    public void clearGui() {
        super.clearGui();
        manager.clear();
        scenarioTableModel.fireTableDataChanged();
        deleteScenarioButton.setEnabled(false);
        duplicateScenarioButton.setEnabled(false);
    }

    private void init() {
        setLayout(new BorderLayout());
        setBorder(makeBorder());

        add(makeTitlePanel(), BorderLayout.NORTH);
        add(createScenarioDetailsPanel(), BorderLayout.CENTER);
    }

    public JPanel createTopPanel() {
        // Scenario Description
        scenarioTable = new JTable(scenarioTableModel);
        scenarioTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        scenarioTable.setPreferredScrollableViewportSize(new Dimension(scenarioTable.getPreferredScrollableViewportSize().width, 
                NUM_SCENARIO_VISIBLE_ROWS * scenarioTable.getRowHeight()));
        scenarioTable.getTableHeader().setReorderingAllowed(false);
        
        scenarioTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                populateSelectedScenario();
            }
        });
        
        JScrollPane scroller = new JScrollPane(scenarioTable);
        scroller.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Scenarios"));
        
        // Port
        portField = new JTextField(HttpMirrorControl.DEFAULT_PORT_S, 8);
        portField.setName(HttpMirrorControl.PORT);

        JLabel label = new JLabel("Mock Server Port");
        label.setLabelFor(portField);

        HorizontalPanel portPanel = new HorizontalPanel();
        portPanel.add(label);
        portPanel.add(portField);
        portPanel.add(Box.createHorizontalStrut(10));
        
        JPanel panel = new JPanel(new BorderLayout(0, 5));
        panel.add(portPanel, BorderLayout.NORTH);
        panel.add(scroller, BorderLayout.CENTER);
        panel.add(createButtonPanel(), BorderLayout.SOUTH);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        return panel;
    }
    
    private JPanel createButtonPanel() {
        boolean tableEmpty = (scenarioTableModel.getRowCount() == 0);

        ActionListener scenarioDescriptionActionListener = new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                String action = e.getActionCommand();
                if (action.equals(DELETE_COMMAND)) {
                    if (scenarioTableModel.getRowCount() > 0) {
                        if (scenarioTable.isEditing()) {
                            TableCellEditor cellEditor = 
                                scenarioTable.getCellEditor(scenarioTable.getEditingRow(), scenarioTable.getEditingColumn());
                            cellEditor.cancelCellEditing();
                        }
                        int selectedRow = scenarioTable.getSelectedRow();

                        if (selectedRow != -1) {
                            manager.remove(selectedRow);
                            scenarioTableModel.fireTableDataChanged();
                            if (scenarioTableModel.getRowCount() == 0) {
                                deleteScenarioButton.setEnabled(false);
                                duplicateScenarioButton.setEnabled(false);
                            } else {
                                int rowToSelect = selectedRow;
                                if (selectedRow >= scenarioTableModel.getRowCount()) {
                                    rowToSelect = selectedRow - 1;
                                }
                                scenarioTable.setRowSelectionInterval(rowToSelect, rowToSelect);
                            }
                        }
                    }
                } else if (action.equals(ADD_COMMAND)) {
                    if (scenarioTable.isEditing()) {
                        TableCellEditor cellEditor = 
                            scenarioTable.getCellEditor(scenarioTable.getEditingRow(), scenarioTable.getEditingColumn());
                        cellEditor.stopCellEditing();
                    }
                    manager.addRequestResponse();
                    scenarioTableModel.fireTableDataChanged();
                    if (!deleteScenarioButton.isEnabled()) {
                        deleteScenarioButton.setEnabled(true);
                    }
                    if (!duplicateScenarioButton.isEnabled()) {
                        duplicateScenarioButton.setEnabled(true);
                    }
                    int rowToSelect = scenarioTableModel.getRowCount() - 1;
                    scenarioTable.setRowSelectionInterval(rowToSelect, rowToSelect);
                } else if (action.equals(DUPLICATE_COMMAND)) {
                    if (scenarioTableModel.getRowCount() > 0) {
                        if (scenarioTable.isEditing()) {
                            TableCellEditor cellEditor = 
                                scenarioTable.getCellEditor(scenarioTable.getEditingRow(), scenarioTable.getEditingColumn());
                            cellEditor.cancelCellEditing();
                        }
                        int selectedRow = scenarioTable.getSelectedRow();

                        if (selectedRow != -1) {
                            MockServerScenario duplicateRequestResponse = manager.duplicateRequestResponse(selectedRow);
                            duplicateRequestResponse.setDescription("Copy of " + duplicateRequestResponse.getDescription());
                            scenarioTableModel.fireTableDataChanged();
                            if (scenarioTableModel.getRowCount() == 0) {
                                deleteScenarioButton.setEnabled(false);
                                duplicateScenarioButton.setEnabled(false);
                            } else {
                                int rowToSelect = selectedRow;
                                if (selectedRow >= scenarioTableModel.getRowCount()) {
                                    rowToSelect = selectedRow - 1;
                                }
                                scenarioTable.setRowSelectionInterval(rowToSelect, rowToSelect);
                            }
                        }
                    }
                }
            }
        };
        addScenarioButton.setActionCommand(ADD_COMMAND);
        addScenarioButton.addActionListener(scenarioDescriptionActionListener);
        
        duplicateScenarioButton.setActionCommand(DUPLICATE_COMMAND);
        duplicateScenarioButton.addActionListener(scenarioDescriptionActionListener);
        duplicateScenarioButton.setEnabled(!tableEmpty);
        
        deleteScenarioButton.setActionCommand(DELETE_COMMAND);
        deleteScenarioButton.addActionListener(scenarioDescriptionActionListener);
        deleteScenarioButton.setEnabled(!tableEmpty);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addScenarioButton);
        buttonPanel.add(duplicateScenarioButton);
        buttonPanel.add(deleteScenarioButton);
        return buttonPanel;
    }
    
    private MockServerScenario getCurrentScenario() {
        return scenarioTable.getSelectedRow() != -1 ? manager.getRequestResponseAt(scenarioTable.getSelectedRow()) : null;
    }
    
    private void populateSelectedScenario() {
        MockServerScenario scenario = getCurrentScenario();
        setScenarioDescriptionEnabled(scenario != null);
        if (scenario == null) {
            httpMethodCombo.setSelectedItem("GET");
            pathContainsRadio.setSelected(true);
            expectedPathField.setText("");
            requestNoneMatchingRadio.setSelected(true);
            expectedRequestBodyField.setText("");
            responseBodyField.setText("");
        } else {
            httpMethodCombo.setSelectedItem(scenario.getExpectedHttpMethod());
            expectedPathField.setText(scenario.getExpectedPath());
            expectedRequestBodyField.setText(scenario.getExpectedRequestBody());
            responseBodyField.setText(scenario.getResponseBody());
            switch (scenario.getPathMatchType()) {
                case EQUALS : pathEqualsRadio.setSelected(true); break;
                case CONTAINS : pathContainsRadio.setSelected(true); break;
                case MATCHES : pathMatchesRadio.setSelected(true); break;
            }
            switch (scenario.getBodyMatchType()) {
                case NONE : requestNoneMatchingRadio.setSelected(true); break;
                case EQUALS : requestEqualsRadio.setSelected(true); break;
                case CONTAINS : requestContainsRadio.setSelected(true); break;
                case MATCHES : requestMatchesRadio.setSelected(true); break;
            }
        }
        requestExpressionTableModel.fireTableDataChanged();
    }
    
    public JPanel createScenarioDetailsPanel() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        VerticalPanel panel = new VerticalPanel();
        
        setScenarioDescriptionEnabled(false);
        
        httpMethodCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setTextAreaEnabled(expectedRequestBodyField, httpMethodCombo.getSelectedIndex() != 0);
                requestNoneMatchingRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0);
                requestEqualsRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0);
                requestContainsRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0);
                requestMatchesRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0);
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setExpectedHttpMethod(String.valueOf(httpMethodCombo.getSelectedItem()));
                }
            }
        });
        
        JPanel httpMethodPanel = new JPanel(new GridLayout(1, 2));
        httpMethodPanel.add(httpMethodLabel);
        httpMethodPanel.add(httpMethodCombo);
        panel.add(httpMethodPanel);
        
        JPanel pathMatchingRadioPanel = new JPanel();
        pathMatchingRadioPanel.add(pathEqualsRadio);
        pathMatchingRadioPanel.add(pathContainsRadio);
        pathMatchingRadioPanel.add(pathMatchesRadio);
        
        ActionListener pathMatchingSelectionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setPathMatchType(MatchType.valueOf(e.getActionCommand().toUpperCase()));
                }
            }
        };
        pathEqualsRadio.addActionListener(pathMatchingSelectionListener);
        pathContainsRadio.addActionListener(pathMatchingSelectionListener);
        pathMatchesRadio.addActionListener(pathMatchingSelectionListener);
        
        pathMatchingRuleGroup.add(pathEqualsRadio);
        pathMatchingRuleGroup.add(pathContainsRadio);
        pathMatchingRuleGroup.add(pathMatchesRadio);
        
        JPanel pathMatchingPanel = new JPanel(new BorderLayout());
        pathMatchingPanel.add(pathMatchingRuleLabel, BorderLayout.WEST);
        pathMatchingPanel.add(pathMatchingRadioPanel, BorderLayout.EAST);
        
        panel.add(pathMatchingPanel);
        
        JPanel expectedPathPanel = new JPanel(new GridLayout(1, 2));
        expectedPathPanel.add(expectedPathLabel);
        expectedPathPanel.add(expectedPathField);
        panel.add(expectedPathPanel);
        expectedPathField.addKeyListener(new KeyListener() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setExpectedPath(expectedPathField.getText());
                }
            }
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {}
        });
        
        JPanel requestBodyMatchingRadioPanel = new JPanel();
        requestBodyMatchingRadioPanel.add(requestNoneMatchingRadio);
        requestBodyMatchingRadioPanel.add(requestEqualsRadio);
        requestBodyMatchingRadioPanel.add(requestContainsRadio);
        requestBodyMatchingRadioPanel.add(requestMatchesRadio);
        
        ActionListener requestMatchingSelectionListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setBodyMatchType(MatchType.valueOf(e.getActionCommand().toUpperCase()));
                }
            }
        };
        requestNoneMatchingRadio.addActionListener(requestMatchingSelectionListener);
        requestEqualsRadio.addActionListener(requestMatchingSelectionListener);
        requestContainsRadio.addActionListener(requestMatchingSelectionListener);
        requestMatchesRadio.addActionListener(requestMatchingSelectionListener);
        
        requestBodyMatchingRuleGroup.add(requestNoneMatchingRadio);
        requestBodyMatchingRuleGroup.add(requestEqualsRadio);
        requestBodyMatchingRuleGroup.add(requestContainsRadio);
        requestBodyMatchingRuleGroup.add(requestMatchesRadio);
        
        JPanel requestBodyMatchingPanel = new JPanel(new BorderLayout());
        requestBodyMatchingPanel.add(requestBodyMatchingRuleLabel, BorderLayout.WEST);
        requestBodyMatchingPanel.add(requestBodyMatchingRadioPanel, BorderLayout.EAST);
        
        panel.add(requestBodyMatchingPanel);
        panel.add(expectedRequestBodyLabel);
        
        expectedRequestBodyField.setRows(NUM_REQUEST_RESPONSE_VISIBLE_ROWS);
        expectedRequestBodyField.setLineWrap(true);
        expectedRequestBodyField.setWrapStyleWord(true);
        panel.add(new JScrollPane(expectedRequestBodyField));
        
        expectedRequestBodyField.addKeyListener(new KeyListener() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setExpectedRequestBody(expectedRequestBodyField.getText());
                }
            }
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {}
        });
        
        responseBodyField.setRows(NUM_REQUEST_RESPONSE_VISIBLE_ROWS);
        responseBodyField.setLineWrap(true);
        responseBodyField.setWrapStyleWord(true);
        panel.add(responseBodyLabel);
        panel.add(new JScrollPane(responseBodyField));
        
        responseBodyField.addKeyListener(new KeyListener() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (getCurrentScenario() != null) {
                    getCurrentScenario().setResponseBody(responseBodyField.getText());
                }
            }
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {}
        });
        
        panel.add(Box.createVerticalStrut(10));
        
        requestExpressionTable = new JTable(requestExpressionTableModel);
        requestExpressionTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        requestExpressionTable.setPreferredScrollableViewportSize(new Dimension(requestExpressionTable.getPreferredScrollableViewportSize().width, 
                NUM_REQUEST_EXPR_VISIBLE_ROWS * requestExpressionTable.getRowHeight()));
        requestExpressionTable.getTableHeader().setReorderingAllowed(false);
        
        setupExpressionTargetColumn(requestExpressionTable,
                requestExpressionTable.getColumnModel().getColumn(0));
        setupExpressionTypeColumn(requestExpressionTable,
                requestExpressionTable.getColumnModel().getColumn(1));
        
        JScrollPane scroller = new JScrollPane(requestExpressionTable);
        scroller.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Request Expressions"));
        panel.add(scroller);
        
        JPanel topPanel = createTopPanel();
        
        panel.add(createRequestExpressionButtonPanel());
        
        panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Scenario Details"));
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(panel, BorderLayout.CENTER);
        
        return mainPanel;
    }
    
    private void setupExpressionTargetColumn(JTable table, TableColumn column) {
        final JComboBox comboBox = new JComboBox();
        for (ExpressionTarget target : ExpressionTarget.values()) {
            comboBox.addItem(target);
        }
        column.setCellEditor(new DefaultCellEditor(comboBox));

        final DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setToolTipText("Click for combo box");
        column.setCellRenderer(renderer);
    }
    
    private void setupExpressionTypeColumn(JTable table, TableColumn column) {
        final JComboBox comboBox = new JComboBox();
        for (ExpressionType target : ExpressionType.values()) {
            comboBox.addItem(target);
        }
        column.setCellEditor(new DefaultCellEditor(comboBox));

        final DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setToolTipText("Click for combo box");
        column.setCellRenderer(renderer);
    }
    
    private JPanel createRequestExpressionButtonPanel() {
        boolean tableEmpty = (requestExpressionTableModel.getRowCount() == 0);

        ActionListener requestExpressionActionListener = new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent e) {
                String action = e.getActionCommand();
                if (action.equals(DELETE_COMMAND)) {
                    if (requestExpressionTableModel.getRowCount() > 0) {
                        if (requestExpressionTable.isEditing()) {
                            TableCellEditor cellEditor = 
                                requestExpressionTable.getCellEditor(requestExpressionTable.getEditingRow(), requestExpressionTable.getEditingColumn());
                            cellEditor.cancelCellEditing();
                        }
                        int selectedRow = requestExpressionTable.getSelectedRow();

                        if (selectedRow != -1) {
                            if (getCurrentScenario() != null) {
                                getCurrentScenario().removeRequestExpression(selectedRow);
                            }
                            requestExpressionTableModel.fireTableDataChanged();
                            if (requestExpressionTableModel.getRowCount() == 0) {
                                deleteRequestExpressionButton.setEnabled(false);
                            } else {
                                int rowToSelect = selectedRow;
                                if (selectedRow >= requestExpressionTableModel.getRowCount()) {
                                    rowToSelect = selectedRow - 1;
                                }
                                requestExpressionTable.setRowSelectionInterval(rowToSelect, rowToSelect);
                            }
                        }
                    }
                } else if (action.equals(ADD_COMMAND)) {
                    if (requestExpressionTable.isEditing()) {
                        TableCellEditor cellEditor = 
                            requestExpressionTable.getCellEditor(requestExpressionTable.getEditingRow(), requestExpressionTable.getEditingColumn());
                        cellEditor.stopCellEditing();
                    }
                    if (getCurrentScenario() != null) {
                        getCurrentScenario().addRequestExpression();
                    }
                    requestExpressionTableModel.fireTableDataChanged();
                    if (!deleteRequestExpressionButton.isEnabled()) {
                        deleteRequestExpressionButton.setEnabled(true);
                    }
                    int rowToSelect = requestExpressionTableModel.getRowCount() - 1;
                    requestExpressionTable.setRowSelectionInterval(rowToSelect, rowToSelect);
                }
            }
        };
        addRequestExpressionButton.setActionCommand(ADD_COMMAND);
        addRequestExpressionButton.addActionListener(requestExpressionActionListener);
        
        deleteRequestExpressionButton.setActionCommand(DELETE_COMMAND);
        deleteRequestExpressionButton.addActionListener(requestExpressionActionListener);
        deleteRequestExpressionButton.setEnabled(!tableEmpty);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addRequestExpressionButton);
        buttonPanel.add(deleteRequestExpressionButton);
        return buttonPanel;
    }
    
    private void setScenarioDescriptionEnabled(boolean enabled) {
        httpMethodCombo.setEnabled(enabled);
        responseBodyField.setEnabled(enabled);
        setTextAreaEnabled(expectedRequestBodyField, httpMethodCombo.getSelectedIndex() != 0 && enabled);
        setTextAreaEnabled(responseBodyField, enabled);
        expectedPathField.setEnabled(enabled);
        pathEqualsRadio.setEnabled(enabled);
        pathContainsRadio.setEnabled(enabled);
        pathMatchesRadio.setEnabled(enabled);
        requestNoneMatchingRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0 && enabled);
        requestEqualsRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0 && enabled);
        requestContainsRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0 && enabled);
        requestMatchesRadio.setEnabled(httpMethodCombo.getSelectedIndex() != 0 && enabled);
        addRequestExpressionButton.setEnabled(enabled);
        deleteRequestExpressionButton.setEnabled(enabled && requestExpressionTableModel.getRowCount() > 0);
    }
    
    private void setTextAreaEnabled(JTextArea textArea, boolean enabled) {
        textArea.setEnabled(enabled);
        textArea.setEditable(enabled);
        textArea.setBackground(enabled ? Color.WHITE : Color.LIGHT_GRAY);
        textArea.setText(enabled ? textArea.getText() : "");
    }
    
    private class ScenarioTableModel extends AbstractTableModel {
        private static final long serialVersionUID = 4638155137475747946L;
        
        @Override
        public boolean isCellEditable(int row, int column) {
            return true;
        }
        
        @Override
        public Class<?> getColumnClass(int column) {
            return getValueAt(0, column).getClass();
        }
        
        public int getRowCount() {
            return manager.getScenarios().size();
        }
        
        public int getColumnCount() {
            return 1;
        }
        
        @Override
        public String getColumnName(int column) {
            return "Scenario Description";
        }
        
        public Object getValueAt(int row, int column) {
            MockServerScenario scenario = manager.getRequestResponseAt(row);
            return scenario.getDescription();
        }
        
        @Override
        public void setValueAt(Object value, int row, int column) {
            MockServerScenario scenario = manager.getRequestResponseAt(row);
            scenario.setDescription((String) value);
        }
    }
    
    private class RequestExpressionTableModel extends AbstractTableModel {
        private static final long serialVersionUID = 4638155137475747946L;
        
        @Override
        public boolean isCellEditable(int row, int column) {
            return true;
        }
        
        @Override
        public Class<?> getColumnClass(int column) {
            Object currentValue = getValueAt(0, column);
            return currentValue == null ? String.class : currentValue.getClass();
        }
        
        public int getRowCount() {
            return getCurrentScenario() == null ? 0 : getCurrentScenario().getRequestExpressionsSize();
        }
        
        public int getColumnCount() {
            return 4;
        }
        
        @Override
        public String getColumnName(int column) {
            switch (column) {
                case 0 : return "Expression Target";
                case 1 : return "Expression Type";
                case 2 : return "Expression";
                case 3 : return "Variable Name";
                default : return null;
            }
        }
        
        public Object getValueAt(int row, int column) {
            if (getCurrentScenario() != null) {
                List<ScenarioRequestExpression> expressions = getCurrentScenario().getRequestExpressions();
                if (expressions.size() >= row + 1) {
                    ScenarioRequestExpression expression = expressions.get(row);
                    switch (column) {
                        case 0 : return expression.getExpressionTarget();
                        case 1 : return expression.getExpressionType();
                        case 2 : return expression.getExpression();
                        case 3 : return expression.getResultingJMeterVariableName();
                        default : return null;
                    }
                }
            }
            return null;
        }
        
        @Override
        public void setValueAt(Object value, int row, int column) {
            if (getCurrentScenario() != null) {
                ScenarioRequestExpression expression = getCurrentScenario().getRequestExpressions().get(row);
                switch (column) {
                    case 0 : expression.setExpressionTarget(ExpressionTarget.valueOf(String.valueOf(value))); break;
                    case 1 : expression.setExpressionType(ExpressionType.valueOf(String.valueOf(value))); break;
                    case 2 : expression.setExpression(String.valueOf(value)); break;
                    case 3 : expression.setResultingJMeterVariableName(String.valueOf(value)); break;
                }
            }
        }
    }
}
