package org.apache.jmeter.protocol.http.control.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Models a single mock server scenario i.e. expected input, output and
 * any expressions to run on the expected input
 * 
 * @author Gerard Dougan
 */
public class MockServerScenario {

    public enum MatchType {
        EQUALS,
        MATCHES,
        CONTAINS,
        NONE;
    }
    
    private String description = "";
    
    private String expectedHttpMethod = "GET";
    
    private MatchType pathMatchType = MatchType.CONTAINS;
    private String expectedPath = "";
    
    private MatchType bodyMatchType = MatchType.NONE;
    private String expectedRequestBody = "";
    
    private List<ScenarioRequestExpression> requestExpressions = new ArrayList<ScenarioRequestExpression>();
    
    private String responseBody = "";
    
    public MockServerScenario() {}
    
    public MockServerScenario(MockServerScenario scenario) {
        this.description = scenario.getDescription();
        this.expectedHttpMethod = scenario.getExpectedHttpMethod();
        this.pathMatchType = scenario.getPathMatchType();
        this.expectedPath = scenario.getExpectedPath();
        this.bodyMatchType = scenario.getBodyMatchType();
        this.expectedRequestBody = scenario.getExpectedRequestBody();
        this.responseBody = scenario.getResponseBody();
        for (ScenarioRequestExpression expression : scenario.getRequestExpressions()) {
            this.requestExpressions.add(new ScenarioRequestExpression(expression));
        }
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getExpectedHttpMethod() {
        return expectedHttpMethod;
    }
    public void setExpectedHttpMethod(String expectedHttpMethod) {
        this.expectedHttpMethod = expectedHttpMethod;
    }
    public MatchType getPathMatchType() {
        return pathMatchType;
    }
    public void setPathMatchType(MatchType pathMatchType) {
        this.pathMatchType = pathMatchType;
    }
    public String getExpectedPath() {
        return expectedPath;
    }
    public void setExpectedPath(String expectedPath) {
        this.expectedPath = expectedPath;
    }
    public MatchType getBodyMatchType() {
        return bodyMatchType;
    }
    public void setBodyMatchType(MatchType bodyMatchType) {
        this.bodyMatchType = bodyMatchType;
    }
    public String getExpectedRequestBody() {
        return expectedRequestBody;
    }
    public void setExpectedRequestBody(String expectedRequestBody) {
        this.expectedRequestBody = expectedRequestBody;
    }
    public List<ScenarioRequestExpression> getRequestExpressions() {
        return requestExpressions;
    }
    public void setRequestExpressions(
            List<ScenarioRequestExpression> requestExpressions) {
        this.requestExpressions = requestExpressions;
    }
    public String getResponseBody() {
        return responseBody;
    }
    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }
    public void addRequestExpression() {
        requestExpressions.add(new ScenarioRequestExpression());
    }
    public void removeRequestExpression(int index) {
        requestExpressions.remove(index);
    }
    public int getRequestExpressionsSize() {
        return requestExpressions == null ? 0 : requestExpressions.size();
    }

    @Override
    public String toString() {
        return "MockServerScenario [description=" + description
                + ", expectedHttpMethod=" + expectedHttpMethod
                + ", pathMatchType=" + pathMatchType + ", expectedPath="
                + expectedPath + ", bodyMatchType=" + bodyMatchType
                + ", expectedRequestBody=" + expectedRequestBody
                + ", requestExpressions=" + requestExpressions
                + ", responseBody=" + responseBody + "]";
    }
}
