package org.apache.jmeter.protocol.http.control;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.processor.PreProcessor;
import org.apache.jmeter.protocol.http.control.bean.MockServerComponent;
import org.apache.jmeter.protocol.http.control.bean.MockServerScenario;
import org.apache.jmeter.protocol.http.control.bean.MockServerScenario.MatchType;
import org.apache.jmeter.protocol.http.control.util.ExpressionEvaluater;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestListener;
import org.apache.jmeter.testelement.property.ObjectProperty;
import org.apache.jmeter.testelement.property.StringProperty;
import org.apache.jmeter.threads.JMeterContextService;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

/**
 * Mock Http Server Control, allowing predefined inputs and outputs for HTTP requests
 * on a particular port
 * 
 * HTTP server is initialised on testStarted and destroyed on testEnded
 * 
 * @author Gerard Dougan
 */
public class HttpMockServer extends AbstractTestElement implements TestListener, PreProcessor {

    private static final Logger logger = LoggingManager.getLoggerForClass();
    
    private static final long serialVersionUID = 233L;
    
    private static Map<String, MockServerComponent> portToServer = new HashMap<String, MockServerComponent>();
    private static Map<String, String> extractedVariables = new HashMap<String, String>();
    
    private static final String DEFAULT_PORT = "8080";

    public static final String PORT = "HttpMockServer.port";
    public static final String SCENARIOS = "HttpMockServer.scenarios";
    
    public HttpMockServer() {
        setProperty(new StringProperty(PORT, DEFAULT_PORT));
        setProperty(new ObjectProperty(SCENARIOS, new ArrayList<MockServerScenario>()));
    }
    
    @Override
    public void clear() {
        super.clear();
        setProperty(new StringProperty(PORT, DEFAULT_PORT));
        setProperty(new ObjectProperty(SCENARIOS, new ArrayList<MockServerScenario>()));
    }

    public void setPort(String port) {
        stopServer();
        setProperty(PORT, port);
    }
    
    public String getPort() {
        return getPropertyAsString(PORT);
    }

    public void setScenarios(List<MockServerScenario> requestResponse) {
        setProperty(new ObjectProperty(SCENARIOS, requestResponse));
    }

    @SuppressWarnings("unchecked")
    public List<MockServerScenario> getScenarios() {
        return (List<MockServerScenario>) getProperty(SCENARIOS).getObjectValue();
    }
    
    public MockServerScenario getRequestResponseAt(int row) {
        return getScenarios().get(row);
    }
    
    public void remove(int index) {
        getScenarios().remove(index);
    }
    
    public void addRequestResponse() {
        getScenarios().add(new MockServerScenario());
    }
    
    public MockServerScenario duplicateRequestResponse(int row) {
        MockServerScenario duplicate = new MockServerScenario(getRequestResponseAt(row));
        getScenarios().add(duplicate);
        return duplicate;
    }

    public boolean isEditable() {
        return true;
    }
    
    @Override
    public boolean canRemove() {
        stopServer();
        return true;
    }

    private class MockHttpHandler implements HttpHandler {
        public void handle(HttpExchange exchange) throws IOException {
            StringBuffer out = new StringBuffer();
            byte[] b = new byte[4096];
            InputStream requestBody = exchange.getRequestBody();
            for (int n; (n = requestBody.read(b)) != -1;) {
                out.append(new String(b, 0, n));
            }
            String body = out.toString();
            
            Headers responseHeaders = exchange.getResponseHeaders();
            responseHeaders.set("Content-Type", "text/plain");
            
            String response = getResponse(exchange.getRequestURI().toString(), exchange.getRequestMethod(), body);
            
            if (response != null) {
                logger.info("Returning Response [" + response + "] for request: " + requestString(exchange, body));

                exchange.sendResponseHeaders(200, 0);
                exchange.getResponseBody().write(response.getBytes());
            } else {
                logger.warn("No mock server scenario defined for request: "  + requestString(exchange, body));
                
                logger.info("Available scenarios on port " + getPort() + " are " + getScenarios());

                exchange.sendResponseHeaders(500, 0);
                exchange.getResponseBody().write(("No mock server scenario defined for request: " 
                        + requestString(exchange, body)).getBytes());
            }
            exchange.getResponseBody().close();
        }
    }
    
    private String requestString(HttpExchange exchange, String requestBody) {
        return "Method [" + exchange.getRequestMethod() + "], Port [" + getPort() + "], Path [" 
            + exchange.getRequestURI().toString() + "], Body [" + requestBody + "]";
    }
    
    private String getResponse(String url, String method, String body) {
        List<MockServerScenario> scenarios = portToServer.get(getPort()).resolveVariables(getScenarios());
        
        for (int i = 0; i < scenarios.size(); i++) {
            MockServerScenario scenario = scenarios.get(i);
            
            if (scenario.getExpectedHttpMethod().equals(method) && matches(url, scenario.getExpectedPath(), scenario.getPathMatchType())) {
                if (method.equals("GET") || matches(body, scenario.getExpectedRequestBody(), scenario.getBodyMatchType())) {
                    
                    if (scenario.getRequestExpressionsSize() > 0) {
                        ExpressionEvaluater.evaluateExpressions(scenario.getRequestExpressions(), url, body, 
                                portToServer.get(getPort()).getContext().getVariables(), extractedVariables);
                    }
                    
                    scenarios = portToServer.get(getPort()).resolveVariables(getScenarios());
                    
                    return scenarios.get(i).getResponseBody();
                }
            }
        }
        return null;
    }
    
    private boolean matches(String string, String possibleMatch, MatchType matchType) {
        switch (matchType) {
            case MATCHES : return string.matches(possibleMatch);
            case CONTAINS : return string.contains(possibleMatch);
            case EQUALS : return string.equals(possibleMatch);
            case NONE : return true;
            default : return false;
        }
    }

    private void startServer() {
        InetSocketAddress addr = new InetSocketAddress(Integer.valueOf(getPort()));
        try {
            HttpServer server = HttpServer.create(addr, 0);
            
            ExecutorService threadPool = Executors.newCachedThreadPool();
            
            server.createContext("/", new MockHttpHandler());
            server.setExecutor(threadPool);
            server.start();
            logger.info("Mock HTTP Server started on port " + getPort());
            
            portToServer.put(getPort(), new MockServerComponent(server, threadPool, JMeterContextService.getContext()));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
        }
    }
    
    private void stopServer() {
        MockServerComponent component = portToServer.get(getPort());
        if (component != null) {
            HttpServer server = component.getServer();
            ExecutorService threadPool = component.getThreadPool();
            
            if (threadPool != null) {
                threadPool.shutdown();
                threadPool = null;
            }
            if (server != null) {
                server.stop(0);
                server = null;
                logger.info("Mock HTTP Server on port " + getPort() + " stopped");
            }
            portToServer.remove(getPort());
        }
    }
    
    /*
     * Add any extracted variables to the current sample variable stack
     */
    @Override
    public void process() {
        JMeterContextService.getContext().getVariables().putAll(extractedVariables);
    }
    
    @Override
    public void testStarted() {
        startServer();
    }

    @Override
    public void testEnded() {
       stopServer(); 
    }
    
    @Override
    public void testStarted(String paramString) {
        testStarted();
    }

    @Override
    public void testEnded(String paramString) {
        testEnded();
    }

    @Override
    public void testIterationStart(LoopIterationEvent paramLoopIterationEvent) {
    }
}
