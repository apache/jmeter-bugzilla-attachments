package org.apache.jmeter.protocol.http.control.util;

import static org.apache.jmeter.protocol.http.control.util.ExpressionEvaluater.*;
import junit.framework.Assert;

import org.junit.Test;

public class ExpressionEvaluaterTest {

    @Test
    public void testEvaluate() {
        Assert.assertEquals("content", evaluateXPath("//test", "<root><test type=\"exp\">content</test></root>"));
        Assert.assertEquals("exp", evaluateXPath("//test/@type", "<root><test type=\"exp\">content</test></root>"));
        
        Assert.assertEquals("5768467894", evaluateRegex("[^0-9]+([0-9]+)[^0-9]+", "sletgbirbggigbei5768467894hsegvuibnvilsrt"));
        
        Assert.assertEquals("cVal", evaluateJson("a.b.c", "{\"a\":{\"b\":{\"c\":\"cVal\", \"d\":\"dVal\"}}}"));
        Assert.assertEquals("dVal", evaluateJson("a.b.d", "{\"a\":{\"b\":{\"c\":\"cVal\", \"d\":\"dVal\"}}}"));
    }
}
