package mytst.tst1;

import java.nio.file.Files;
import java.nio.file.Path;

import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;


public class App 
{
    public static void main( String[] args ) throws Exception
    {    	
		String jmeterHome = "D:/tmp/goTrv/apache-jmeter-3.3";
		StandardJMeterEngine jmeter = new StandardJMeterEngine();
		JMeterUtils.setJMeterHome(jmeterHome);
		
		JMeterUtils.loadJMeterProperties(jmeterHome + "/bin/jmeter.properties");
		
//		JMeterUtils.initLogging();
		JMeterUtils.initLocale();

		
		SaveService.loadProperties();
		
		Path tempPath = Files.createTempFile("jmeter_", "");
    	Files.copy(App.class.getClassLoader().getResourceAsStream("jmeter/jmeter_functions.jmx"), tempPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
				
		HashTree testPlanTree = SaveService.loadTree(tempPath.toFile());

		Summariser summer = null;
		String summariserName = JMeterUtils.getPropDefault("summariser.name", "summary");//$NON-NLS-1$
		if (summariserName.length() > 0) {
			summer = new Summariser(summariserName);
		}		

		String logFile = jmeterHome + "/jmeter_functions.jtl";
		ResultCollector logger = new ResultCollector(summer);
		logger.setFilename(logFile);
		testPlanTree.add(testPlanTree.getArray()[0], logger);

		jmeter.configure(testPlanTree);
		jmeter.run();
    }
}
