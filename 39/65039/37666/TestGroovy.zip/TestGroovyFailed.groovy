

def testString = "Fehler beim Einrichten/�ndern java.lang.IllegalArgumentException Dokument fehlerhaft... (Georeferenz fehlt)"
if (testString) {
	log.info("test successful")
} else {
	log.info("test failed")
}
