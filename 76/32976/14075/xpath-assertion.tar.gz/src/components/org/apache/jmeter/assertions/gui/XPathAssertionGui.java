/*
 * Copyright 2001-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
*/

package org.apache.jmeter.assertions.gui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import org.apache.jmeter.assertions.XPathAssertion;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jmeter.util.gui.XMLConfPanel;
import org.apache.jmeter.util.gui.XPathPanel;
import org.apache.jorphan.gui.layout.VerticalLayout;

import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * 
 * @author <a href="mailto:jspears@astrology.com">Justin Spears </a>
 *
 */

public class XPathAssertionGui extends AbstractAssertionGui  implements FocusListener, ActionListener
{

	private XPathPanel xpath;
	private XMLConfPanel xml;
	
	/**
     * The constructor.
     */
    public XPathAssertionGui()
    {
        init();
    }

    /**
     * Returns the label to be shown within the JTree-Component.
     */
    public String getLabelResource()
    {
    	return "xpath_assertion_title";
    }
    /**
     * Create test element
     */
    public TestElement createTestElement()
    {

    	XPathAssertion el = new XPathAssertion();
        modifyTestElement(el);
        return el;
    }

    

   
	public String getXPathAttributesTitle()
	{
	    return JMeterUtils.getResString("xpath_assertion_test");
	}
	 
	
	public void focusGained(FocusEvent e)
	{
		 log.debug("XPathAssertionGui.focusGained() called");
	}

	public void focusLost(FocusEvent e)
	{
	    
	}

	private static transient Logger log = LoggingManager.getLoggerForClass();
	private static final String OPERATOR_KEY = null;
	private int execState;
	public void configure(TestElement el)
	{
	    super.configure(el);
	    XPathAssertion assertion = (XPathAssertion) el;
	    xpath.setXPath(assertion.getXPathString());
	    xpath.setNegated(assertion.isNegated());
	    
	    xml.setWhitespace(assertion.isWhitespace());
	    xml.setValidate(assertion.isValidating());
	    xml.setTolerant(assertion.isTolerant());
	    xml.setNamespace(assertion.isNamespace());
	    
	}

	private void init()
	{
	    setLayout(
	        new VerticalLayout(5, VerticalLayout.LEFT, VerticalLayout.TOP));
	    setBorder(makeBorder());
	
	    add(makeTitlePanel());
	
	    // USER_INPUT
	    JPanel sizePanel = new JPanel(new BorderLayout());
	    sizePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
	    sizePanel.setBorder(
	        BorderFactory.createTitledBorder(
	            BorderFactory.createEtchedBorder(),
	            getXPathAttributesTitle()));
	    xpath = new XPathPanel();
	    sizePanel.add(xpath);
	    
	    xml = new XMLConfPanel();
	    xpath = new XPathPanel();
	    
	    xml.setBorder(
		        BorderFactory.createTitledBorder(
		            BorderFactory.createEtchedBorder(),
		            JMeterUtils.getResString("xpath_assertion_option")));
	    add(xml);
	   
	    add(sizePanel);
	 //  add(xml);
	}

	/**
	 * Modifies a given TestElement to mirror the data in the gui components.
	 * @see org.apache.jmeter.gui.JMeterGUIComponent#modifyTestElement(TestElement)
	 */
	public void modifyTestElement(TestElement el)
	{
	    super.configureTestElement(el);
	    if (el instanceof XPathAssertion ) {
	    	XPathAssertion assertion = (XPathAssertion) el;
	    	assertion.setValidating(xml.isValidate());
	    	assertion.setWhitespace(xml.isWhitespace());
	    	assertion.setTolerant(xml.isTolerant());
	    	assertion.setNamespace(xml.isNamespace());
	    	assertion.setNegated(xpath.isNegated());
	    	assertion.setXPathString(xpath.getXPath());
	    }
	}


	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

	
}
