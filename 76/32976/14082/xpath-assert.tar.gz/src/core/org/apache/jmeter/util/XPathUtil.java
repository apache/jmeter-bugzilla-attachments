/*
 * Created on Jan 23, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.apache.jmeter.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;
import org.w3c.dom.Document;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * @author Justin Spears jspears@astrology.com
 * 
 * This class provides a few utility methods for dealing with XML/XPath.  Might
 * think about creating an interface for the setup, but, works fine now...
 * 
 */
public class XPathUtil {
	transient private static Logger log = LoggingManager.getLoggerForClass();
	private XPathUtil() {super();}
	private static DocumentBuilderFactory documentBuilderFactory;
	

	  /**
	   * Might 
	   * @return javax.xml.parsers.DocumentBuilderFactory
	   */
	  private static synchronized DocumentBuilderFactory 
	  	makeDocumentBuilderFactory(boolean validate, boolean whitespace, boolean namespace) {
	    if( XPathUtil.documentBuilderFactory == null 
	    	|| 	documentBuilderFactory.isValidating() != validate 
				|| documentBuilderFactory.isNamespaceAware() != namespace
					|| documentBuilderFactory.isIgnoringElementContentWhitespace() != whitespace
	    	) {
	      // configure the document builder factory
	      documentBuilderFactory = DocumentBuilderFactory.newInstance();
	      documentBuilderFactory.setValidating( validate );
	      documentBuilderFactory.setNamespaceAware( namespace );
	      documentBuilderFactory.setIgnoringElementContentWhitespace(whitespace);
	    }
	    return XPathUtil.documentBuilderFactory;
	  }
	 /**
	  * Create a DocumentBuilder using the makeDocumentFactory func.
	  * @param validate
	  * @param whitespace
	  * @param namespace
	  * @return
	  * @throws ParserConfigurationException
	  * @throws SAXException
	  */
	 public static synchronized DocumentBuilder makeDocumentBuilder(boolean validate,boolean whitespace,  boolean namespace) throws ParserConfigurationException, SAXException{
	 	DocumentBuilder builder = makeDocumentBuilderFactory(validate, whitespace, namespace).newDocumentBuilder();
	 	if (validate) {
	 	 	System.out.println("validate is set to true");
	 		 		
	 	builder.setErrorHandler(new ErrorHandler() {
	 		
			public void warning(SAXParseException exception) throws SAXException {
				log.info(new StringBuffer("SAXParseException.warning: ").append(exception.getLocalizedMessage()).toString());
				throw new SAXException(exception);
			}

			public void error(SAXParseException exception) throws SAXException {
				log.info(new StringBuffer("SAXParseException.error: ").append(exception.getLocalizedMessage()).toString());
				throw new SAXException(exception);
				
			}

			public void fatalError(SAXParseException exception) throws SAXException {
				log.info(new StringBuffer("SAXParseException.error: ").append(exception.getLocalizedMessage()).toString());
				throw new SAXException(exception);
			}});
	 	}
	 	return builder;
	 }
	/**
	 * Utility function to get new Document
	 * 
	 * isWhitespace(),
	 *							isValidate(),
	 *								isNamespace(), 
	 *									isTolerant()
	 * @param stream Document Input stream
	 * @param validate Validate Document
	 * @param whitespace Element Whitespace
	 * @param namespace Is Namespace aware.
	 * @param tolerant Is tolerant
	 * @return
	 * @throws ParserConfigurationException
	 * @throws IOException
	 * @throws SAXException
	 */
	public static Document makeDocument(InputStream stream, boolean validate,boolean whitespace, boolean namespace, boolean tolerant) throws ParserConfigurationException, SAXException, IOException {
		if (tolerant) {
			return new HTMLDocumentBuilder(
					new TolerantSaxDocumentBuilder(makeDocumentBuilder(false,false,false)
							)).parse(new InputStreamReader(stream));
		}else {
			return makeDocumentBuilder( validate, whitespace,namespace).parse(stream);
			
		}
	}
	private static Document makeTolerantDocument(InputStream is) throws ParserConfigurationException, SAXException, IOException {
		HTMLDocumentBuilder builder = new HTMLDocumentBuilder(
				new TolerantSaxDocumentBuilder(makeDocumentBuilder(false,false,false)
						));
		return builder.parse(new InputStreamReader(is));
		
		
	}
	public static Document makeDocument(InputStream stream) throws ParserConfigurationException, SAXException, IOException {
			return makeDocumentBuilder( false, false,false).parse(stream);
	}

}
