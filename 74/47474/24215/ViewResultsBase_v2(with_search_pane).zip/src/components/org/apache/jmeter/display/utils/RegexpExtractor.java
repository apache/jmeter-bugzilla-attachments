/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jmeter.display.utils;

import java.util.LinkedList;
import java.util.List;

import org.apache.oro.text.PatternCacheLRU;
import org.apache.oro.text.regex.MatchResult;
import org.apache.oro.text.regex.Pattern;
import org.apache.oro.text.regex.PatternMatcherInput;
import org.apache.oro.text.regex.Perl5Compiler;
import org.apache.oro.text.regex.Perl5Matcher;

/**
 * Util to parse a test with a regexp
 *
 */
public class RegexpExtractor {

    /**
     * @return Multi-line string found by regexp engine
     */
    public String process() {

        Perl5Matcher matcher = new Perl5Matcher();
        PatternMatcherInput input = new PatternMatcherInput(this.getInputString());

        PatternCacheLRU pcLRU = new PatternCacheLRU();
        Pattern pattern = pcLRU.getPattern(this.getRegex(), Perl5Compiler.READ_ONLY_MASK);
        List<MatchResult> matches = new LinkedList<MatchResult>();
        int x = 0;
        boolean done = false;
        do {
            if (matcher.contains(input, pattern)) {
                //log.debug("RegexExtractor: Match found!");
                matches.add(matcher.getMatch());
            } else {
                done = true;
            }
            x++;
        } while (!done);

        // Construct a multi-line string with all matches
        StringBuffer sb = new StringBuffer();
        for (int j = 0; j < matches.size(); j++) {
            MatchResult mr = matches.get(j);
            final int groups = mr.groups();
            for (int i = 0; i < groups; i++) {
                sb.append(" group[" + j + "][" + i + "]=" + mr.group(i) + "\n");

            }
        }
        return sb.toString();

    }
    private String inputString;
    private String regex;

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public String getInputString() {
        return inputString;
    }

    public void setInputString(String inputString) {
        this.inputString = inputString;
    }
}
