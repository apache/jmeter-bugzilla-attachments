/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *
 */
package org.apache.jmeter.display.results;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import org.apache.jmeter.display.interfaces.ResultsRender;
import org.apache.jmeter.display.utils.RegexpExtractor;
import org.apache.jmeter.display.utils.ResourceUtil;
import org.apache.jmeter.display.utils.VisualizerUtilGUI;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jorphan.gui.JLabeledTextField;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

/**
 * Implement ResultsRender for Regexp tester
 */
public class ResultsRenderRegexp implements ResultsRender, ActionListener {

    private static final Logger log = LoggingManager.getLoggerForClass();

    private static final String REGEXP_TESTER_COMMAND = "regexp_tester"; // $NON-NLS-1$

    private static String BUNDLE_RESOURCE = "org.apache.jmeter.display.resources.MessagesResultRender";

    private static ResourceUtil resource = new ResourceUtil(BUNDLE_RESOURCE);

    // set command to RegExp Tester
    private String command = REGEXP_TESTER_COMMAND;

    private JPanel regexpPane;

    private JTextArea regexpDataField;

    private JLabeledTextField regexpField;

    private JTextArea regexpResultField;

    private JTabbedPane rightSide;

    private SampleResult sampleResult = null;

    /* (non-Javadoc)
     * @see org.apache.jmeter.visualizers.interfaces.ResultsRender#clearData()
     */
    public void clearData() {
        this.clearFields();
    }

    /* (non-Javadoc)
     * @see org.apache.jmeter.visualizers.interfaces.ResultsRender#init()
     */
    public void init() {
        log.debug("init() - pass");
        // Create the panels for the regexp tab
        regexpPane = createRegexpPanel();
    }

    /**
     * Display the response as text or as rendered HTML. Change the text on the
     * button appropriate to the current display.
     *
     * @param e the ActionEvent being processed
     */
    public void actionPerformed(ActionEvent e) {
        command = e.getActionCommand();
        if ((sampleResult != null) && command != null
                && (command.equals(REGEXP_TESTER_COMMAND))) {
            String response = VisualizerUtilGUI.getResponseAsString(sampleResult);
            executeAndShowRegexpTester(response);
        }
    }

    /**
     * Launch regexp engine to parse a input text
     * @param textToParse
     */
    private void executeAndShowRegexpTester(String textToParse) {
        if (textToParse != null && textToParse.length() > 0 
                && this.regexpField.getText().length() > 0) {
            RegexpExtractor ree = new RegexpExtractor();
            log.debug("regexpField = " + this.regexpField.getText());
            ree.setRegex(this.regexpField.getText());
            ree.setInputString(textToParse);
            this.regexpResultField.setText(ree.process());
        }
    }

    public void showRender() {
        log.debug("showRender() - pass");
        this.clearFields();

        if ((SampleResult.TEXT).equals(sampleResult.getDataType())) {
            String response = VisualizerUtilGUI.getResponseAsString(sampleResult);
            regexpDataField.setText(response);
            regexpDataField.setCaretPosition(0);
        } else {
            regexpDataField.setText(resource.getResString("regexp_render_no_text"));
        }
    }

    public void setupTabPane() {
        log.debug("setupTabPane() - pass");
        // Add regexp tester pane
        if (rightSide.indexOfTab(resource.getResString("view_results_tab_regexp_tester")) < 0) { // $NON-NLS-1$
            rightSide.addTab(resource.getResString("view_results_tab_regexp_tester"), regexpPane); // $NON-NLS-1$
        }
    }

    /**
     * @return RegExp Tester panel
     */
    private JPanel createRegexpPanel() {
        regexpDataField = new JTextArea();
        regexpDataField.setEditable(false);
        regexpDataField.setLineWrap(true);
        regexpDataField.setWrapStyleWord(true);

        JScrollPane regexpDataPane = VisualizerUtilGUI.makeScrollPane(regexpDataField);
        regexpDataPane.setMinimumSize(new Dimension(0, 200));

        JPanel pane = new JPanel(new BorderLayout(0, 5));

        JSplitPane mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                regexpDataPane, createRegexpTasksPanel());
        mainSplit.setDividerLocation(300);
        pane.add(mainSplit, BorderLayout.CENTER);
        return pane;
    }

    /**
     * Create the Regexp task pane
     *
     * @return Regexp task pane
     */
    private JPanel createRegexpTasksPanel() {
        JPanel regexpActionPanel = new JPanel();
        regexpField = new JLabeledTextField(resource.getResString("regexp_tester_field"), 30); // $NON-NLS-1$
        regexpActionPanel.add(regexpField, BorderLayout.WEST);

        JButton regexpTester = new JButton(resource.getResString("regexp_tester_button_test"));
        regexpTester.setActionCommand(REGEXP_TESTER_COMMAND);
        regexpTester.addActionListener(this);
        regexpActionPanel.add(regexpTester, BorderLayout.EAST);

        regexpResultField = new JTextArea();
        regexpResultField.setEditable(false);
        regexpResultField.setLineWrap(true);
        regexpResultField.setWrapStyleWord(true);

        JPanel regexpTasksPanel = new JPanel(new BorderLayout(0, 5));
        regexpTasksPanel.add(regexpActionPanel, BorderLayout.NORTH);
        regexpTasksPanel.add(VisualizerUtilGUI.makeScrollPane(regexpResultField), BorderLayout.CENTER);

        return regexpTasksPanel;
    }

    private void clearFields() {
        regexpDataField.setText(""); // $NON-NLS-1$
        // don't set empty to keep regexp
        // regexpField.setText(""); // $NON-NLS-1$
        regexpResultField.setText(""); // $NON-NLS-1$
    }

    public synchronized void setRightSide(JTabbedPane side) {
        rightSide = side;
    }

    public synchronized void setSamplerResult(Object userObject) {
        if (userObject instanceof SampleResult) {
            sampleResult = (SampleResult) userObject;
        }
    }

    public void setLastSelectedTab(int index) {
        // nothing to do
    }

    @Override
    public String toString() {
        return resource.getResString("regexp_tester_title");
    }

}
