/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed  under the  License is distributed on an "AS IS" BASIS,
 * WITHOUT  WARRANTIES OR CONDITIONS  OF ANY KIND, either  express  or
 * implied.
 *
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.jmeter.display.utils;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.logging.LoggingManager;
import org.apache.log.Logger;

public class ResourceUtil {

    private static final Logger log = LoggingManager.getLoggerForClass();

    private ResourceBundle resources;

    private static volatile boolean ignoreResorces = false; // Special flag for use in debugging resources

    public ResourceUtil(String resourceFile) {
        init(resourceFile);
    }

    public void init(String resourceFile) {
        if (resourceFile != null && resourceFile.length() > 0) {
            // Get resource messages (I18N)
            resources = ResourceBundle.getBundle(resourceFile, JMeterUtils
                    .getLocale());
            log.debug("I18N init() - pass: " + resourceFile);
        }
    }
    /**
     * Gets the resource string for this key.
     *
     * If the resource is not found, a warning is logged
     *
     * @param key
     *            the key in the resource file
     * @return the resource string if the key is found; otherwise, return
     *         "[res_key="+key+"]"
     */
    public String getResString(String key) {
        return getResStringDefault(key, RES_KEY_PFX + key + "]"); // $NON-NLS-1$
    }

    public static final String RES_KEY_PFX = "[res_key="; // $NON-NLS-1$

    /*
     * Helper method to do the actual work of fetching resources; allows
     * getResString(S,S) to be deprecated without affecting getResString(S);
     */
    private String getResStringDefault(String key, String defaultValue) {
        if (key == null) {
            return null;
        }
        // Resource keys cannot contain spaces, and are forced to lower case
        String resKey = key.replace(' ', '_'); // $NON-NLS-1$ // $NON-NLS-2$
        resKey = resKey.toLowerCase(java.util.Locale.ENGLISH);
        String resString = null;
        try {
            resString = resources.getString(resKey);
            if (ignoreResorces ){ // Special mode for debugging resource handling
                return "["+key+"]";
            }
        } catch (MissingResourceException mre) {
            if (ignoreResorces ){ // Special mode for debugging resource handling
                return "[?"+key+"?]";
            }
            log.warn("ERROR! Resource string not found: [" + resKey + "]", mre);
            resString = defaultValue;
        }
        return resString;
    }

    /**
     * @param resources the resources to set
     */
    public synchronized void setResources(ResourceBundle resources) {
        this.resources = resources;
    }
}
