/*
 * DBReporterPanel.java
 *
 * Created on 20. September 2004, 15:53
 */

package de.roland.jmeter.reporters;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.apache.jmeter.gui.util.HorizontalPanel;

/**
 *
 * @author  kesslert
 */
public class DBReporterPanel extends HorizontalPanel implements ActionListener {
    
    JTextField drivername = new JTextField(20);
    JLabel driverlabel = new JLabel("JDBC-Treiber");
    
    JTextField url = new JTextField(20);
    JLabel urllabel = new JLabel("URL");
    
    JTextField username = new JTextField(20);
    JLabel userlabel = new JLabel("Benutzername");
    
    JTextField password = new JTextField(20);
    JLabel passwordlabel = new JLabel("Passwort");
    
    JTextField tablename = new JTextField(20);
    JLabel tablelabel = new JLabel("Tabellen-Name");
    
    List listeners = new LinkedList();
    String title;
    
    /** Creates a new instance of DBReporterPanel */
    public DBReporterPanel() {
        title = "";
        init();
    }
    
    public DBReporterPanel(String title) {
        this.title = title;
        init();
    }
    
    public void addChangeListener(ChangeListener l) {
        listeners.add(l);
    }
    
    private void fireChanged() {
        Iterator iter = listeners.iterator();
        while (iter.hasNext()) {
            ((ChangeListener) iter.next()).stateChanged(new ChangeEvent(this));
        }
    }
    
    private void init() {
        GridBagLayout layout = new GridBagLayout();
        setBorder(BorderFactory.createTitledBorder(title));
        setName(title);
        setLayout( layout );
        
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(driverlabel, c);
        
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(urllabel, c);
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(drivername, c);
        drivername.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(url, c);
        url.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 2;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(userlabel, c);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 2;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(passwordlabel, c);
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 3;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(username, c);
        username.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 3;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(password, c);
        password.addActionListener(this);

        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 4;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(tablelabel, c);

        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 5;
        c.gridheight = 1;
        c.gridwidth = 1;
        add(tablename, c);
        tablename.addActionListener(this);
    }
    
    public String getDriver() {
        return this.drivername.getText();
    }
    
    public String getURL() {
        return this.url.getText();
    }
    
    public String getUsername() {
        return this.username.getText();
    }
    
    public String getPassword() {
        return this.password.getText();
    }

    public String getTablename() {
        return this.tablename.getText();
    }
    
    public void setDriver( String value )
    {
        this.drivername.setText( value );
    }
    
    public void setURL( String value )
    {
        this.url.setText( value );
    }
    
    public void setUsername( String value )
    {
        this.username.setText( value );
    }
    
    public void setPassword ( String value )
    {
        this.password.setText( value );
    }
    
    public void setTablename ( String value )
    {
        this.tablename.setText( value );
    }

    public void actionPerformed(ActionEvent e) {
        fireChanged();
    }
    
}
