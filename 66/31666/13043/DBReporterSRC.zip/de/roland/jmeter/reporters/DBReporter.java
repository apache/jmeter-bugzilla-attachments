/*
 * DBReporter.java
 *
 * Created on 21. September 2004, 10:43
 */

package de.roland.jmeter.reporters;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.apache.jmeter.engine.event.LoopIterationEvent;
import org.apache.jmeter.engine.util.NoThreadClone;
import org.apache.jmeter.samplers.Remoteable;
import org.apache.jmeter.samplers.SampleEvent;
import org.apache.jmeter.samplers.SampleListener;
import org.apache.jmeter.samplers.SampleResult;
import org.apache.jmeter.testelement.AbstractTestElement;
import org.apache.jmeter.testelement.TestListener;

/**
 *
 * @author  kesslert
 */
public class DBReporter extends AbstractTestElement 
                        implements SampleListener, Serializable, TestListener, NoThreadClone, Remoteable {
    
    private static String PROP_URL = "DBReporter_URL";
    private static String PROP_DRIVER = "DBReporter_DRIVER";
    private static String PROP_USERNAME = "DBReporter_USERNAME";
    private static String PROP_PASSWORD = "DBReporter_PASSWORD";
    private static String PROP_TABLENAME = "DBReporter_TABLENAME";
    
    private static int SLEEPTIME = 2000;
    
    private DBReporterModel reporterModel;
    private Boolean threadsStarted;
    
    private Set hosts;
    
    private static byte THREAD_COUNT = 5;
    private static String THREAD_NAME = "DBWriter";
    private static String THREADGROUP_NAME = "DBRepoterWriters";
    
    private DBWriterThread writerThreads[];
    
    /** Creates a new instance of DBReporter */
    public DBReporter() {
        this.reporterModel = null;
        this.threadsStarted = Boolean.FALSE;
        this.hosts = new HashSet();
    }

    public Object clone() {
        DBReporter result = (DBReporter)super.clone();
        
        result.reporterModel = this.reporterModel;
        result.threadsStarted = this.threadsStarted;
        result.hosts = this.hosts;
        result.writerThreads = this.writerThreads;
        
        return result;
    }
    
    public void sampleOccurred(SampleEvent e) {
        if ( this.threadsStarted.equals(Boolean.FALSE) ) {
            initThreads();
        }
        
        SampleResult result = e.getResult();
        this.reporterModel.addEvent( result );
    }
    
    public void sampleStarted(SampleEvent e) {
    }
    
    public void sampleStopped(SampleEvent e) {
    }
    
    public void testEnded() {
        if ( this.hosts.size() == 0) {
            stopThreads();
        }
    }
    
    public void testEnded(String host) {
        this.hosts.remove( host );
        
        if ( this.hosts.size() == 0) {
            stopThreads();
        }
    }
    
    public void testIterationStart(LoopIterationEvent event) {
    }
    
    public void testStarted() {
        initThreads();
    }
    
    public void testStarted(String host) {
        this.hosts.add( host );
        
        initThreads();
    }
    
    private synchronized void initThreads() {
        if ( this.threadsStarted.equals( Boolean.FALSE ) ) {
            String threadName;
            this.reporterModel = initDBReporterModel();
            
            ThreadGroup group = new ThreadGroup( THREADGROUP_NAME );
            
            this.writerThreads = new DBWriterThread[ THREAD_COUNT ];
            
            for ( int i = 0; i < THREAD_COUNT; i++ ) {
                threadName = THREAD_NAME + i;
                
                this.writerThreads[i] = new DBWriterThread( this.reporterModel, group, threadName );
                this.writerThreads[i].start();
            }
            
            this.threadsStarted = Boolean.TRUE;
        }
    }
    
    private synchronized void stopThreads() {
        if ( this.threadsStarted.equals( Boolean.TRUE ) ) {
            while ( this.reporterModel.isEventWaiting() ) {
                try {
                    Thread.sleep( SLEEPTIME );
                } catch (InterruptedException e) {
                }
            }
            
            for ( int i = 0; i < THREAD_COUNT; i++ ) {
                this.writerThreads[i].stopWriting();
                this.writerThreads[i] = null;
            }
            
            this.writerThreads = null;
            this.reporterModel = null;
            
            this.threadsStarted = Boolean.FALSE;
        }
    }
    
    private DBReporterModel initDBReporterModel() {
        DBReporterModel result = new DBReporterModel();
        
        result.setDriver( getDriver() );
        result.setUrl( getUrl() );
        result.setUsername( getUsername() );
        result.setPassword( getPassword() );
        result.setTablename( getTablename() );
        
        return result;
    }
    
    public String getDriver() {
        return getPropertyAsString( PROP_DRIVER );
    }
    
    public void setDriver(String driver) {
        setProperty( PROP_DRIVER, driver );
    }
    
    public String getPassword() {
        return getPropertyAsString( PROP_PASSWORD );
    }
    
    public void setPassword(String password) {
        setProperty( PROP_PASSWORD, password );
    }
    
    public String getUrl() {
        return getPropertyAsString( PROP_URL );
    }
    
    public void setUrl(String url) {
        setProperty( PROP_URL, url );
    }
    
    public String getUsername() {
        return getPropertyAsString( PROP_USERNAME );
    }
    
    public void setUsername(String username) {
        setProperty( PROP_USERNAME, username);
    }
    
    public String getTablename() {
        return getPropertyAsString( PROP_TABLENAME );
    }
    
    public void setTablename(String tablename) {
        setProperty( PROP_TABLENAME, tablename);
    }
}