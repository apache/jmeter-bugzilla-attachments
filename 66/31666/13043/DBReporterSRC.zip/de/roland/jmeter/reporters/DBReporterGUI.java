/*
 * DBReporter.java
 *
 * Created on 20. September 2004, 13:20
 */

package de.roland.jmeter.reporters;

import java.awt.BorderLayout;
import java.util.Arrays;
import java.util.Collection;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.apache.jmeter.gui.AbstractJMeterGuiComponent;
import org.apache.jmeter.gui.util.MenuFactory;
import org.apache.jmeter.testelement.TestElement;
import org.apache.jmeter.testelement.property.StringProperty;

/**
 *
 * @author  kesslert
 */
public class DBReporterGUI extends AbstractJMeterGuiComponent implements ChangeListener {
    
    private static String TESTELEM_URL = "DBReporter_URL";
    private static String TESTELEM_DRIVER = "DBReporter_DRIVER";
    private static String TESTELEM_USERNAME = "DBReporter_USERNAME";
    private static String TESTELEM_PASSWORD = "DBReporter_PASSWORD";
    private static String TESTELEM_TABLENAME = "DBReporter_TABLENAME";
    
    private DBReporter reporter;
    private DBReporterPanel reporterPanel;    
    
    /** Creates a new instance of DBReporter */
    public DBReporterGUI() {
        init();
        setName(getStaticLabel());
    }
    
    private void init() {
        JPanel topPanel;
        
        reporterPanel = new DBReporterPanel("DB-Konfiguration");
        reporterPanel.addChangeListener( this );
        
        topPanel = new JPanel();
        topPanel.setLayout( new BoxLayout( topPanel, BoxLayout.Y_AXIS) );
        topPanel.add( makeTitlePanel());
        topPanel.add( reporterPanel );
        
        setLayout( new BorderLayout() );
        setBorder(makeBorder());
        
        add(topPanel, BorderLayout.NORTH);
    }

   public JPopupMenu createPopupMenu()
    {
        return MenuFactory.getDefaultVisualizerMenu();
    }    
    
    public String getDocAnchor() {
        return null;
    }
    
    public String getLabelResource() {
        return null;
    }
    
    public Collection getMenuCategories() {
        return Arrays.asList(new String[] { MenuFactory.LISTENERS });
    }
    
    public String getStaticLabel() {
        return "DBReporter";
    }
    
    public void stateChanged(ChangeEvent e) {
        DBReporterPanel panel = (DBReporterPanel)e.getSource();
        
        this.reporter.setDriver( panel.getDriver() );
        this.reporter.setUrl( panel.getURL() );
        this.reporter.setUsername( panel.getUsername() );
        this.reporter.setPassword( panel.getPassword() );
        this.reporter.setTablename( panel.getTablename() );
    }
    
    public TestElement createTestElement() {
        if (reporter == null) {
            reporter = new DBReporter();
        }
        modifyTestElement(reporter);
        return (TestElement) reporter.clone();
    }
    
    /* Implements JMeterGUIComponent.modifyTestElement(TestElement) */
    public void modifyTestElement(TestElement c) {
        configureTestElement(c);

        this.reporter.setDriver( this.reporterPanel.getDriver() );
        this.reporter.setUrl( this.reporterPanel.getURL() );
        this.reporter.setUsername( this.reporterPanel.getUsername() );
        this.reporter.setPassword( this.reporterPanel.getPassword() );
        this.reporter.setTablename( this.reporterPanel.getTablename() );
        
        c.setProperty( new StringProperty( TESTELEM_DRIVER, this.reporter.getDriver() ) );
        c.setProperty( new StringProperty( TESTELEM_URL, this.reporter.getUrl() ) );
        c.setProperty( new StringProperty( TESTELEM_USERNAME, this.reporter.getUsername() ) );
        c.setProperty( new StringProperty( TESTELEM_PASSWORD, this.reporter.getPassword() ) );
        c.setProperty( new StringProperty( TESTELEM_TABLENAME, this.reporter.getTablename() ) );
    }
    
    /* Overrides AbstractJMeterGuiComponent.configure(TestElement) */
    public void configure(TestElement el) {
        super.configure(el);

        if (reporter == null) {
            reporter = new DBReporter();
        }
       
        this.reporter.setDriver( el.getPropertyAsString( TESTELEM_DRIVER ) );
        this.reporter.setUrl( el.getPropertyAsString( TESTELEM_URL ) );
        this.reporter.setUsername( el.getPropertyAsString( TESTELEM_USERNAME ) );
        this.reporter.setPassword( el.getPropertyAsString( TESTELEM_PASSWORD ) );
        this.reporter.setTablename( el.getPropertyAsString( TESTELEM_TABLENAME ) );
        
        if ( this.reporterPanel != null )
        {
            this.reporterPanel.setDriver( this.reporter.getDriver() );
            this.reporterPanel.setURL( this.reporter.getUrl() );
            this.reporterPanel.setUsername( this.reporter.getUsername() );
            this.reporterPanel.setPassword( this.reporter.getPassword() );
            this.reporterPanel.setTablename( this.reporter.getTablename() );
        }
    }
}
