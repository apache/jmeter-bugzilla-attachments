/*
 * DBWriterThread.java
 *
 * Created on 27. September 2004, 07:12
 */

package de.roland.jmeter.reporters;

import java.sql.*;
import org.apache.jmeter.samplers.SampleResult;

/**
 *
 * @author  kesslert
 */
public class DBWriterThread extends Thread {

    private DBReporterModel reporterModel;
    
    private boolean testEnded;
    
    private boolean dbInitialized;
    private Object DBAccessLock = new Object();
    private Connection dbConnection;
    private PreparedStatement insertStatement;
    private static String SQL_INSERTROW_1 = "insert into "; 
    private static String SQL_INSERTROW_2 = "(LABEL, THREADNAME, RESPONSECODE, CONTENTTYPE, CONTENTLENGTH, STARTTIME, ENDTIME, SAMPLETIME) values (?,?,?,?,?,?,?,?)";
    
    private static int SLEEPTIME = 2000;
    
    /** Creates a new instance of DBWriterThread */
    public DBWriterThread( DBReporterModel model, ThreadGroup group, String name ) {
        super(group, name);
        
        this.dbInitialized = false;
        this.reporterModel = model;
        this.testEnded = false;
    }
    
    public void run() {
        System.out.println("DBWriterThread.run");
        try {
            initDB();
            SampleResult result = null;
            while ( ! this.testEnded ) {
                result = this.reporterModel.getEvent();
                if ( result != null ) {
                    storeSampleResult( result );
                } else {
                    sleep( SLEEPTIME );
                }
            }
        } catch ( Exception e )
        {
            e.printStackTrace();
        }
        finally {
            try {
                closeDBConnection();
            } catch (SQLException e )
            {
                System.out.println("could not close connection to DB");
                e.printStackTrace();
            }
        }
    }
    
    public void stopWriting() {
        this.testEnded = true;
    }
    
    private void initDB() throws SQLException, ClassNotFoundException {
        synchronized ( this.DBAccessLock ) {
            if ( ! this.dbInitialized ) {
                System.out.println(this.reporterModel.getDriver());
                Class.forName( this.reporterModel.getDriver().trim() );
                
                Connection con = DriverManager.getConnection( this.reporterModel.getUrl(), 
                        this.reporterModel.getUsername(), this.reporterModel.getPassword() );
                con.setAutoCommit( false );
                
                printDBInfo( con );
                
                this.dbConnection = con;
                this.insertStatement = con.prepareStatement( 
                    SQL_INSERTROW_1 + this.reporterModel.getTablename() + SQL_INSERTROW_2 );
                
                this.dbInitialized = true;
            }
        }
    }
    
    private void printDBInfo( Connection connection ) throws SQLException {
        DatabaseMetaData dma = connection.getMetaData();
        
        System.out.println("Database\t" + dma.getDatabaseProductVersion());
        System.out.println("Driver\t\t" + dma.getDriverVersion());
        System.out.println("URL\t\t" + dma.getURL() + ", user '" + dma.getUserName() + "'");
        System.out.println("-------------------------------------");
    }
    
    private void storeSampleResult( SampleResult result ) throws SQLException {
        synchronized ( this.DBAccessLock ) {
            this.insertStatement.setString(1, result.getSampleLabel() );
            this.insertStatement.setString(2, result.getThreadName() );
            this.insertStatement.setString(3, result.getResponseCode() );
            this.insertStatement.setString(4, result.getContentType() );
            this.insertStatement.setLong(5, result.getResponseData().length);
            this.insertStatement.setTimestamp(6, new Timestamp(result.getStartTime()) );
            this.insertStatement.setTimestamp(7, new Timestamp(result.getEndTime()) );
            this.insertStatement.setLong(8, result.getTime() );
            
            this.insertStatement.executeUpdate();
            
            this.dbConnection.commit();
        }
    }
    
    private void closeDBConnection() throws SQLException {
        synchronized ( this.DBAccessLock ) {
            if ( this.insertStatement != null ) {
                this.insertStatement.close();
                this.insertStatement = null;
            }
            
            if ( this.dbConnection != null ) {
                this.dbConnection.close();
                this.dbConnection = null;
            }
        }
    }
}
