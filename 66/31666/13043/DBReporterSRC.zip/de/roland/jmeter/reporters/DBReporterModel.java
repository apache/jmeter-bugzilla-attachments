/*
 * DBReporterModel.java
 *
 * Created on 27. September 2004, 07:15
 */

package de.roland.jmeter.reporters;

import java.util.LinkedList;
import java.util.NoSuchElementException;
import org.apache.jmeter.samplers.SampleResult;

/**
 *
 * @author  kesslert
 */
public class DBReporterModel {
    
    private String url;
    private String driver;
    private String username;
    private String password;
    private String tablename;
    
    private LinkedList sampleEvents;
    private Object listLock;
    
    
    /** Creates a new instance of DBReporterModel */
    public DBReporterModel() {
        this.sampleEvents = new LinkedList();
        this.listLock = new Object();
    }
    
    public void addEvent( SampleResult result ) {
        synchronized ( this.listLock ) {
            this.sampleEvents.addLast( result );
        }
    }
    
    public boolean isEventWaiting() {
        synchronized ( this.listLock ) {
            return ! this.sampleEvents.isEmpty();
        }
    }
    
    public SampleResult getEvent() {
        SampleResult result = null;
        
        synchronized ( this.listLock ) {
            if ( !this.sampleEvents.isEmpty() ) {
                try {
                    result = (SampleResult)this.sampleEvents.getFirst();
                    this.sampleEvents.remove( result );
                } catch (NoSuchElementException e) {
                    result = null;
                }
            }
        }
        
        return result;
    }
    
    /**
     * Getter for property driver.
     * @return Value of property driver.
     */
    public java.lang.String getDriver() {
        return driver;
    }
    
    /**
     * Setter for property driver.
     * @param driver New value of property driver.
     */
    public void setDriver(java.lang.String driver) {
        this.driver = driver;
    }
    
    /**
     * Getter for property password.
     * @return Value of property password.
     */
    public java.lang.String getPassword() {
        return password;
    }
    
    /**
     * Setter for property password.
     * @param password New value of property password.
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }
    
    /**
     * Getter for property url.
     * @return Value of property url.
     */
    public java.lang.String getUrl() {
        return url;
    }
    
    /**
     * Setter for property url.
     * @param url New value of property url.
     */
    public void setUrl(java.lang.String url) {
        this.url = url;
    }
    
    /**
     * Getter for property username.
     * @return Value of property username.
     */
    public java.lang.String getUsername() {
        return username;
    }
    
    /**
     * Setter for property username.
     * @param username New value of property username.
     */
    public void setUsername(java.lang.String username) {
        this.username = username;
    }
    
    /**
     * Getter for property tablename.
     * @return Value of property tablename.
     */
    public java.lang.String getTablename() {
        return tablename;
    }
    
    /**
     * Setter for property tablename.
     * @param tablename New value of property tablename.
     */
    public void setTablename(java.lang.String tablename) {
        this.tablename = tablename;
    }
    
}
