/**
 * Copyright (c) 2014 Motive, Inc.
 * All rights reserved.
 *
 * Motive, Inc. Proprietary/Trade Secret ; Information
 * Not to be disclosed or used except in accordance with applicable agreements.
 */
package com.hemerasoftware;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Zach Calvert
 */
public class Servlet extends HttpServlet {

    /**
     *
     */
    private static final long serialVersionUID = 2798160674583335426L;
    /**
     * Copyright 2014
     */
    public static final String COPYRIGHT = "Copyright (c) Motive 2014.  All rights reserved.";

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // we will set a header based on the parameters specified
        StringBuilder sb = new StringBuilder();

        String name = req.getParameter("cookieName");
        String value = req.getParameter("value");

        sb.append(name + "=" + value);

        String maxAge = req.getParameter("age");
        if (maxAge != null) {
            sb.append(";Max-Age=");
            sb.append(Integer.parseInt(maxAge));
        }

        String path = req.getParameter("path");
        if (path != null) {
            sb.append(";Path=");
            sb.append(path);
        }

        String version = req.getParameter("version");
        if (version != null) {
            sb.append(";Version=");
            sb.append(version);
        }



        resp.addHeader("Set-Cookie", sb.toString());
        resp.setStatus(200);
        resp.getWriter().write("Response complete");
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // do nothing
    }

}
