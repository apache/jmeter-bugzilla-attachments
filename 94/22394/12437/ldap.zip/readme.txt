This zip file contains the java source files for the extended LDAP sampler

they are zipped from the src/protocol/ldap level and can be extracted from there
the patch file contains the chnages to the message.properties file in 
src/core/org/apache/jmeter/resources

they are only made for the messag.properties, but the same lines can be added to the translator files as well