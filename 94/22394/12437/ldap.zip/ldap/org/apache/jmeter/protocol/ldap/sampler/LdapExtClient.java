/*
 * ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in
 * the documentation and/or other materials provided with the
 * distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 * if any, must include the following acknowledgment:
 * "This product includes software developed by the
 * Apache Software Foundation (http://www.apache.org/)."
 * Alternately, this acknowledgment may appear in the software itself,
 * if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 * "Apache JMeter" must not be used to endorse or promote products
 * derived from this software without prior written permission. For
 * written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 * "Apache JMeter", nor may "Apache" appear in their name, without
 * prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */
package org.apache.jmeter.protocol.ldap.sampler;

import java.util.Hashtable;
import  java.lang.Exception;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.NoPermissionException;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;

import org.apache.log.Hierarchy;
import org.apache.log.Logger;


/****************************************
 * Title: JMeter Description: Copyright: Copyright (c) 2000 Company: Apache
 *
 *@author    Dolf Smits(Dolf.Smits@Siemens.com)
 *@created    Aug 09 2003 11:00 AM
 *@company    Siemens Netherlands N.V..
 *@version   1.0
 * Based on the work of:
 *@author    T.Elanjchezhiyan(chezhiyan@siptech.co.in)
 *@created    Apr 29 2003 11:00 AM
 *@company    Sip Technologies and Exports Ltd.
 *@version   1.0
 ***************************************/


/*****************************************************
 *Ldap Client class is main class to create ,modify,
 *search and delete all the LDAP functionality available
 *****************************************************/
public class LdapExtClient
{
    transient private static Logger log = Hierarchy.getDefaultHierarchy()
    .getLoggerFor("jmeter.protocol.ldap");
   public final static String CONNECTOR = "ldap_con";
   public NamingEnumeration answer;
    /**
     *  Constructor for the LdapClient object
     */
    public LdapExtClient() {
     }

    /**
     *  connect to server
     *
     *@param  host           Description of Parameter
     *@param  username       Description of Parameter
     *@param  password       Description of Parameter
     *@exception  Exception  Description of Exception
     */
    public DirContext connect(String host,String port,String rootdn,String username,
                        String password) throws Exception{
        DirContext dirContext;
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL,"ldap://"+host +":"+port+"/"+rootdn);
        log.info("prov_url= "+env.get(Context.PROVIDER_URL));
        env.put(Context.REFERRAL,"throw"); 
        env.put("java.naming.batchsize", "0");
        env.put(Context.SECURITY_CREDENTIALS,password);
        env.put(Context.SECURITY_PRINCIPAL,username);
        dirContext = new InitialDirContext(env);
        return dirContext;
    }

    public void sbind(String host,String port,String rootdn,String username,
                        String password) throws Exception{
        DirContext dirContext;
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL,"ldap://"+host +":"+port+"/"+rootdn);
        env.put(Context.REFERRAL,"throw"); 
        env.put("java.naming.batchsize", "0");
        env.put(Context.SECURITY_CREDENTIALS,password);
        env.put(Context.SECURITY_PRINCIPAL,username);
        dirContext = new InitialDirContext(env);
    }

    /**
     *  disconnect from the server
     */
    public void disconnect(DirContext dirContext) {
        try {
            dirContext.close();
        } catch (Exception e) {
            log.error("Ldap client disconnect - ",e);
        }
    }

   /************************************************************
     * Filter  the data in the ldap directory for the given
     * search base 
     *@param  search base  where the search should start
     *@param  search filter filter this value from the base  
     ***********************************************************/
    public void searchTest(DirContext dirContext, String searchBase, String searchFilter, int scope, long countlim, int timelim, String[] attrs, boolean retobj, boolean deref )
        throws Exception{
        SearchControls searchcontrols= null;
        searchcontrols = new SearchControls(scope, countlim, timelim, attrs, retobj, deref); 
        answer=dirContext.search(searchBase, searchFilter, searchcontrols);
    }

   /************************************************************
     * Filter  the data in the ldap directory for the given
     * search base 
     *@param  search base  where the search should start
     *@param  search filter filter this value from the base  
     ***********************************************************/
   public void compare(DirContext dirContext, String filter, String entrydn) throws Exception{
       SearchControls searchcontrols = new SearchControls(0, 1, 0, new String[0], false, false); 
       dirContext.search(entrydn, filter, searchcontrols);
    }

   /************************************************************
     * ModDN  the data in the ldap directory for the given
     * search base 
     *@param  search base  where the search should start
     *@param  search filter filter this value from the base  
     ***********************************************************/
   public void moddnOp(DirContext dirContext, String ddn, String newdn) throws Exception{
       dirContext.rename(ddn, newdn);
    }

   /************************************************************
     * Modify  the attribute in the ldap directory for the given
     * string
     *@param  ModificationItem  add all the entry in to the 
     *                          ModificationItem
     *@param  string  The  string (dn) value 
     ***********************************************************/
    public void modifyTest(DirContext dirContext, ModificationItem[] mods, String string)
        throws NamingException{
        dirContext.modifyAttributes(string, mods);
        
     }

    /************************************************************
     * Create the attribute in the ldap directory for the given
     * string
     *@param  basicattributes  add all the entry in to the 
     *                          basicattribute
     *@param  string  The  string (dn) value 
     ***********************************************************/
    public void createTest(DirContext dirContext, BasicAttributes basicattributes, String string) 
        throws NamingException{
        dirContext.createSubcontext(string, basicattributes);
    }
        
    /************************************************************
     * Delete the attribute from the ldap directory
     *@param  value  The  string (dn) value 
     ***********************************************************/
    public void deleteTest(DirContext dirContext, String string) throws Exception{
        dirContext.destroySubcontext(string);
    }
}