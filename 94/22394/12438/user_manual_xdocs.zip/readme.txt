This zip file contains three xml files and two patch files/

the xml files should be dropped in xdocs/usermanual
the patches should be applied to the already existing xml files in that same directory