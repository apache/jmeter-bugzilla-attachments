This zip file contains the screenshot for the ldap extended sampler manuals.

they should be dropped in the xdocs/images/screenshots/ldaptest directory